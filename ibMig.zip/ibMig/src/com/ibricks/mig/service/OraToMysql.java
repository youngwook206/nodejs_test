package com.ibricks.mig.service;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class OraToMysql {
	
	public void runMigration() {
		
		PreparedStatement pstmtOra = null;      
        ResultSet rs = null;
        Connection connOra = null;
        
        PreparedStatement pstmtMy = null;
        Connection connMy = null;
        
        try {
        	// 1. Oracle conn
			connOra = getOraConnection();
			String oraQuery=
	        		"select "
				  + "appl_no"
				  + ",spec_content"
				  + ",cnlk_stt_se"
				  + ",cnlk_trs_dt"
				  + ",cnlk_rcv_dt"
				  + ",cnlk_err_cn"
				  + " from "
				  + "  patent_specification "
				  + "where "
				  + "rownum < 3 "
				  + "order by appl_no asc"
				  ;
			pstmtOra = connOra.prepareStatement(oraQuery);
	        rs = pstmtOra.executeQuery();
	        
	        // 2. Mysql conn
	        connMy = getMyConnection();
	        String myQuery = "";
	        myQuery = "INSERT INTO patent_specification_dev " + 
	    			"( appl_no, spec_content, cnlk_stt_se, cnlk_err_cn ) "
	    			+"VALUES"
	    			+	"(?, ?, ?, ?)"
	    			+ "ON DUPLICATE KEY UPDATE "
	    			+ "appl_no=?, "
	    			+ "spec_content=?, "
	    			+ "cnlk_stt_se=?, "
//	    			+ "cnlk_trs_dt=?, "
//	    			+ "cnlk_rcv_dt=?, "
	    			+ "cnlk_err_cn=?"
	    			;
	        pstmtMy = connMy.prepareStatement(myQuery);
	        
	        int checkIdx=0;
	        int[] testVal = null;
	        int exeCount=0;
	        
	        while(rs.next()) {
	        	checkIdx++;
	        	String appl_no = rs.getString("appl_no");
	        	String spec_content = rs.getString("spec_content");
	        	spec_content = removeTag(spec_content);
	        	String cnlk_stt_se = rs.getString("cnlk_stt_se");
//	        	String cnlk_trs_dt = rs.getString("cnlk_trs_dt");
//	        	String cnlk_rcv_dt = rs.getString("cnlk_rcv_dt");
	        	String cnlk_err_cn = rs.getString("cnlk_err_cn");
	        	
	        	pstmtMy.setString(1, appl_no);	
	        	pstmtMy.setString(2, spec_content);	
	        	pstmtMy.setString(3, cnlk_stt_se);	
	        	pstmtMy.setString(4, cnlk_err_cn);	
	        	pstmtMy.setString(5, appl_no);	
	        	pstmtMy.setString(6, spec_content);	
	        	pstmtMy.setString(7, cnlk_stt_se);	
	        	pstmtMy.setString(8, cnlk_err_cn);	
	        	
	        	pstmtMy.addBatch();
	        	pstmtMy.clearParameters();
	        	
	        	if(checkIdx % 100 == 0) {
	        		testVal = pstmtMy.executeBatch();
	        		exeCount += testVal.length;
	        		System.out.println("exeCount : " + exeCount);
	        	}
	        }
	        testVal = pstmtMy.executeBatch();
	        exeCount += testVal.length;
			System.out.println("exeCount : " + exeCount);
	        
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally{
	         if(pstmtOra != null) try{ pstmtOra.close();} catch(SQLException e){};                   
	         if(rs != null) try{ rs.close();} catch(SQLException e){};
	         if(connOra != null) try{ connOra.close();} catch(SQLException e){};
	         
	         if(pstmtMy != null) try{ pstmtMy.close();} catch(SQLException e){};                   
	         if(connMy != null) try{ connMy.close();} catch(SQLException e){};
	         
		}
	}
	
	public String removeTag(String str){		
		Matcher mat;  

		// script ó�� 
		Pattern script = Pattern.compile("<(no)?script[^>]*>.*?</(no)?script>",Pattern.DOTALL);  
		mat = script.matcher(str);  
		str = mat.replaceAll("");  

		// style ó��
		Pattern style = Pattern.compile("<style[^>]*>.*</style>",Pattern.DOTALL);  
		mat = style.matcher(str);  
		str = mat.replaceAll("");  

		// tag ó�� 
		Pattern tag = Pattern.compile("<(\"[^\"]*\"|\'[^\']*\'|[^\'\">])*>");  
		mat = tag.matcher(str);  
		str = mat.replaceAll("");  

		// ntag ó�� 
		Pattern ntag = Pattern.compile("<\\w+\\s+[^<]*\\s*>");  
		mat = ntag.matcher(str);  
		str = mat.replaceAll("");  

		// entity ref ó��
		Pattern Eentity = Pattern.compile("&[^;]+;");  
		mat = Eentity.matcher(str);  
		str = mat.replaceAll("");

		// whitespace ó�� 
		Pattern wspace = Pattern.compile("\\s\\s+");  
		mat = wspace.matcher(str); 
		str = mat.replaceAll(""); 	          

		return str ;		
	}
	

	public Connection getOraConnection() throws SQLException {
		Connection conn;

		final String URL = "jdbc:oracle:thin:@211.239.150.101:1521:keit";	//ibricks idc 
		final String ID = "nx_kipris"; // 
		final String PW = "kipris123"; // 
		conn = DriverManager.getConnection(URL, ID, PW);
		conn.setAutoCommit(true);
		return conn;
	}
	
	public Connection getMyConnection() throws SQLException {
		Connection conn;

		final String URL = "jdbc:mariadb://localhost:3306/study_db";	//local mysql
		final String ID = "study_user"; //
		final String PW = "study1!"; // 

		conn = DriverManager.getConnection(URL, ID, PW);
		conn.setAutoCommit(true);
		return conn;
	}
	
	public void closeMyConnection(Connection conn, PreparedStatement pstmt){
		try{
//			rs.close();
			pstmt.close();
			conn.close();
		}catch(Exception e){
			e.printStackTrace();
		}
	}
}
