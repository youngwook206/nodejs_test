package com.ibricks.mig.main;

import com.ibricks.mig.service.OraToMysql;

public class ApplicantRun {
	public static void main(String[] args) {
		OraToMysql oraToMysql = new OraToMysql();
		oraToMysql.runMigration();
	}
}
