//user.js
var approot = require('app-root-path');
// elasticsearch
var es = require(approot + '/util/es');

module.exports = {
    uMatch : function(user_id) {

        return es.client1.search({
            "query" : {
                "match_phrase" : { "user_id" : user_id }
            }
        },function(err, resp){
            if (err){
                return false;
            }else {
                var total = resp.total;
                if(total > 0){
                    return true;
                }else{
                    return false;
                }
            }
        });
    }
};
