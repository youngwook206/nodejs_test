var approot = require('app-root-path');
var config = require(approot + '/config/config');

// elasticsearch
var elasticsearch = require('elasticsearch');

var elasticclient1 = new elasticsearch.Client({
    host: config.elastic_host,
    requestTimeout: config.elastic_timeout
});

var elasticclient2 = new elasticsearch.Client({
    host: config.elastic_host,
    requestTimeout: config.elastic_timeout
});

var es = {};
es.client1 = elasticclient1;
es.client2 = elasticclient2;

module.exports = es;
