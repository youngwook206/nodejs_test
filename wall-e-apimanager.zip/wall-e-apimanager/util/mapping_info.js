var approot = require('app-root-path');


var mapping_info = {};

var mapping_list = {
    "전관해설 (대표소장품)":"Whole",
    "선사/고대관":"Prehistory_Ancient",
    "중/근세과":"Medieval_Modern",
    "기증관":"Donated_Works",
    "서회관":"Calligraphy_Painting",
    "아시아관":"Asian_Arts",
    "조각/공예관":"Sculpture_Crafts",
    "어린이 박물관":"Children_Museum",
    "특별전시실":"Special_Gallery",
    "테마전시실":"Thematic_Gallery",
    "기획전시실":"Exhibition_Gallery",
    "극장용":"Theater_Yong",
    "으뜸홀 카페":"Greathall_Cafe",


    /*
    전관해설 (대표소장품)	Whole
    선사/고대관	Prehistory_Ancient
    중/근세과	Medieval_Modern
    기증관	Donated_Works
    서회관	Calligraphy_Painting
    아시아관	Asian_Arts
    조각/공예관	Sculpture_Crafts
    */
};
mapping_info = mapping_list;

module.exports = mapping_info;
