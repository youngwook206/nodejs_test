var approot = require('app-root-path');
var config = require(approot + '/config/config');

// redis
var redis = require('redis');
var option1 = {
    host : config.redis_host,
    port : config.redis_port,
    db : 1
};
var redisClient1 = redis.createClient(option1);

/*
var Redis = require('ioredis');
var redis = new Redis({
    port: config.redis_port,
    host: config.redis_host,
    family: 4
});
*/


/*
redisClient.auth({password}, function (err) {
    if (err) throw err;
});
*/


redisClient1.on('error', function(err) {
    console.log('Redis meta error: ' + err);
});

module.exports = redisClient1;

