//util.js
var approot = require('app-root-path');
var config = require(approot + '/config/config');
var moment = require('moment');
var uc = require(approot + '/util/unit_changer');
var clonedeep = require('lodash.clonedeep');

module.exports.res_err = function(req, err, msg) {
    if( req === undefined );
    else {
        // control
    }

    //return { "status": err, "reason": msg };
    return { "status" : {"code":err, "message": msg } };
};


module.exports.res_ok = function(req, body, elapsed) {
    elapsed = (elapsed !== undefined) ?  elapsed : {};
    if( req === undefined );
    else {
        // control
    }

    console.trace("[send body] "+JSON.stringify(body));

    //var ret = { "status": 200, "reason": "OK", "_elapsed": elapsed };
    var ret = { "status": {"code":200, "message": "OK" }, "_elapsed": elapsed };
    for(var key in body)
        ret[key] = body[key];

    return ret;
};

module.exports.res_error = function(req, body, elapsed) {
    elapsed = (elapsed !== undefined) ?  elapsed : {};
    if( req === undefined );
    else {
        // control
    }

    console.trace("[send body] "+JSON.stringify(body));

    //var ret = { "status": 200, "reason": "OK", "_elapsed": elapsed };
    var ret = { "status": {"code":500, "message": "Internal Server Error" }, "_elapsed": elapsed };
    for(var key in body)
        ret[key] = body[key];

    return ret;
};


module.exports.req_param = function(urlname, req, filename) {
	console.debug('---------------------------------------', filename);
	console.debug(urlname+' / (method:'+req.method+')', filename);
	console.debug('GET  parameter : '+JSON.stringify(req.query), filename);
	console.debug('POST parameter : '+JSON.stringify(req.body), filename);
	console.debug('---------------------------------------', filename);
};


module.exports.getDate = function(){
	var configfile = require(approot + '/config/config.json');
	var date = new Date(Date.now() - new Date().getTimezoneOffset() * configfile.timezoneoffset_value).toISOString();
	return date;
}

module.exports.getThisMonth = function() {
    let today = '';
    let thisYear = `${moment().year()}`;
    let thisMonth = `${(moment().month()+1)}`;
    if(thisMonth<10) thisMonth='0'+thisMonth;
    today = thisYear + thisMonth;
    return today;
}

module.exports.newMap = function() {
    var map = {};
    map.value = {};
    map.getKey = function(id) {
      return "k_"+id;
    };
    map.put = function(id, value) {
      var key = map.getKey(id);
      map.value[key] = value;
    };
    map.contains = function(id) {
      var key = map.getKey(id);
      if(map.value[key]) {
        return true;
      } else {
        return false;
      }
    };
    map.get = function(id) {
      var key = map.getKey(id);
      if(map.value[key]) {
        return map.value[key];
      }
      return null;
    };
    map.remove = function(id) {
      var key = map.getKey(id);
      if(map.contains(id)){
        map.value[key] = undefined;
      }
    };

    return map;
  }

module.exports.replaceFieldToLang = function(field, lang) {
    let termList = ['_ko', '_zh', '_ja', '_en'];
    let repl = chkTermInString(termList, field);
    let replacedField = "";
    if(repl != "") {
        replacedField = field.replace(repl, lang);
    } else {
        replacedField = field;
    }
    return replacedField;
}

module.exports.sliceLastSC = function(strValue, s_char) {
    if(strValue.charAt( strValue.length-1 ) == s_char) {
        strValue = strValue.replace(s_char+s_char, s_char);
        strValue = strValue.slice(0, -1);
    }
    return strValue;
}

module.exports.getRealSalary = function( salary, payGubun, readJustYn) {
	let retSalary = "";
    let isWonPattern = false;

	if( salary!="" && salary!="undefined" && salary!=undefined ) {
        let re = new RegExp('^[0-9]+원');
        if(re.test(salary)) {
            isWonPattern = true;
        }

        if( uc(salary) != '-1' ) {
            if(isNumber(salary)) {
                retSalary = salary;
            } else {
                if( isWonPattern ) {
                    retSalary = salary.replace('원','');
                } else {
                    retSalary = uc(salary);
                }
            }
        }
	}
	if( readJustYn=='Y' ) retSalary="0";
    return retSalary;
}

module.exports.getApiSalary = function( salaryMin, payGubun, readJustYn) {
    console.debug('[getApiSalary] 희망임금(원):"'+salaryMin + '", 연봉구분:"'+payGubun + '", 면접후결정파라미터:"' +readJustYn+ '"');

    let retSalary = "";
    let isWonPattern = false;

    let re = new RegExp('^[0-9]+원');
    if(re.test(salaryMin) || checkLastSC(salaryMin, '원')) {
        isWonPattern = true;
    }
    salaryMin = salaryMin.toString();
    salaryMin = salaryMin.replace('원','');

    salaryMin = uc(salaryMin);
    salaryMin = salaryMin.toString();

	if( salaryMin != "" ) {
        if(payGubun == 'Y') {
            if(isWonPattern) {
                retSalary = salaryMin/10000+'';
            } else {
                if(salaryMin>99999) {
                    retSalary = salaryMin/10000+'';
                } else {
                    retSalary = salaryMin.toString();
                }
            }

        } else if(payGubun == 'M') {
            if(isWonPattern) {
                retSalary = salaryMin/10000+'';
            } else {
                if(salaryMin>9999) {
                    retSalary = salaryMin/10000+'';
                } else {
                    retSalary = salaryMin.toString();
                }
            }

        } else if(payGubun == 'D') {
            if(isWonPattern) {
                retSalary = salaryMin.toString();
            } else {
                if(salaryMin>999) {
                    retSalary = salaryMin.toString();
                } else {
                    retSalary = salaryMin*10000+'';
                }
            }


        } else if(payGubun == 'H') {
            if(isWonPattern) {
                retSalary = salaryMin.toString();
            } else {
                if(salaryMin>99) {
                    retSalary = salaryMin.toString();
                } else {
                    retSalary = salaryMin*10000+'';
                }
            }

        } else {
            retSalary = "";
        }

	} else {
         retSalary="";
    }

    if(retSalary<1) retSalary='0';
	if( readJustYn=='Y' ) retSalary="0";

    return retSalary;
}

module.exports.chkDigitNumber = function(digitCode, len) {
    if(digitCode.length==len) {
        return true;
    } else {
        return false;
    }
}

module.exports.numberFormatType = function numberFormatType(str) {
	var retVal = 0;
	if(str != undefined){
		str = String(str);
		retVal =  str.replace(/(\d)(?=(?:\d{3})+(?!\d))/g, '$1,');
	}
	return retVal;
}

function checkLastSC(strValue, s_char) {
    let retBool = false;
    if(strValue.charAt( strValue.length-1 ) == s_char) {
        retBool = true;
    }
    return retBool;
}

function chkTermInString(termList, str) {
    let detect_term = "";
    let temp = "";
    termList.forEach( el => {
        re = new RegExp(`^.*${el}$`);
        re.test(str)? detect_term=el : temp='1';
    });
    return detect_term;
}

function isNumber(s) {
	s += ''; // 문자열로 변환
	s = s.replace(/^\s*|\s*$/g, ''); // 좌우 공백 제거
	if (s == '' || isNaN(s)) return false;
	return true;
}
