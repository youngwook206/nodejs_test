
var num_kr = [ '', '일', '이', '삼', '사', '오', '육', '칠', '팔', '구' ];
var unit_kr1 = [ '', '십', '백', '천' ];
var unit_kr2 = [ '', '만', '억', '조', '경', '해' ];

function num2hannum(str) {
    var result = '';

    var count = 0;
    var length = str.length;
    var target;
    for (var i = 0; i < length; i++) {
        target = str.charAt(i) - '0';
        result += num_kr[target];
        if (target > 0) {
            result += unit_kr1[(length -1 -i % 4)];
        }
        else {
            count++;
        }
        if ((length -1 - i) % 4 === 0) {
            if (count !== 4) {
                result += unit_kr2[(length -1 - i) / 4];
            }
            count = 0;

        }
    }
    return result;
}

var unit_num = { '십':10, '백':100, '천':1000, '만':10000, '억':100000000, '조':1000000000000 };

function hannum2num(str) {
    var result = 0, tmp = 0, num = 0;

    for (var i = 0; i < str.length; i++) {
        var token = str.charAt(i);
        var check = '영일이삼사오육칠팔구'.indexOf(token);
        if (check === -1) {
            if ('만억조'.indexOf(token) === -1) {
                tmp += (num !== 0 ? num : 1) * unit_num[token];
            }
            else {
                tmp += num;
                result += (tmp !== 0 ? tmp : 1) * unit_num[token];
                tmp = 0;
            }
            num = 0;
        }
        else {
            num = check;
        }
    }

    result = result + tmp + num;
    return result;
}

module.exports = function(str) {

    if(!isNaN(str)) return str;
    if (str === undefined || str === null || str.length === 0) {
        return -1;
    }
    if (str.match(/[^0-9일이삼사오육칠팔구십백천만십억조경해원,]/) !== null) {
        return -1;
    }
    str = str.replace(/원$/, '').replace(/,/g, '');

    // 숫자, 한글 분리
    var arr = [];
    var ptype;
    for (var i = 0; i < str.length; i++) {
        var code = str.charAt(i);
        var type = (code >= '0' && code <= '9') ? 0 : 1;

        if (ptype !== type) {
            arr.push('');
        }

        arr[arr.length-1] += code;
        ptype = type;
    }

    // 숫자를 한글 숫자로 변환
    for (var i = 0; i < arr.length; i++) {
        if (arr[i].match(/^[0-9]+$/) !== null) {
            arr[i] = num2hannum(arr[i]);
        }
    }

    // 병합
    var hannumber = arr.join('');
    // 한글숫자를 숫자로 변환
    var number = hannum2num(hannumber);
    return number;
}
