var approot = require('app-root-path');
var config = require(approot + '/config/config');

// redis
var redis = require('redis');
var option = {
    host : config.redis_host,
    port : config.redis_port,
    db : 0
};
var redisClient = redis.createClient(option);

/*
var Redis = require('ioredis');
var redis = new Redis({
    port: config.redis_port,
    host: config.redis_host,
    family: 4
});
*/


/*
redisClient.auth({password}, function (err) {
    if (err) throw err;
});
*/


redisClient.on('error', function(err) {
    console.log('Redis error: ' + err);
});

module.exports = redisClient;

