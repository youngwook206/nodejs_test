//routesHandler.js

var routes = require('./routes/index');
var users = require('./routes/users');
var express_validator = require('express-validator');
var url = require('url');
var approot = require('app-root-path');
var config = require(approot + '/config/config');

module.exports = function(app){
   app.use(express_validator());

   app.use('/', routes);
   app.use('/users', users);

   app.use('/session', require('./routes/session'));

   //-- RESTFul API Management KCISA (S) ----------------------------------------------------------
   //api 개발 목록 확인.
   app.use('/ap/apilistdev', require('./routes/api/kcisa/apilistdev'));
   app.use('/ap/sampleinputparam', require('./routes/api/kcisa/sampleinputparam'));
   app.use('/ap/sampleoutputparam', require('./routes/api/kcisa/sampleoutputparam'));
   //
   app.use('/chatbot', require('./routes/api/kcisa/v1/chatbot'));

   // app.use('/fn/getImgAndDescInItemList', require('./routes/api/kcisa/fn/item/itemList__img_desc'));
   // app.use('/fn/getButtonImgInItemList', require('./routes/api/kcisa/fn/item/itemList__buttonImg'));
   // app.use('/fn/getButtonTextInItemList', require('./routes/api/kcisa/fn/item/itemList__buttonText'));
   // app.use('/fn/getImgInItemList', require('./routes/api/kcisa/fn/item/itemList__img'));
   // app.use('/fn/getHtmlInItemList', require('./routes/api/kcisa/fn/item/itemList__html'));
   // app.use('/fn/getApi/facil', require('./routes/api/kcisa/fn/facil/tp2'));

   app.use('/fn/getApi/showroom/', require('./routes/api/kcisa/fn/item/showroomFunction'));
   app.use('/fn/getApi/reliclist_prompt', require('./routes/api/kcisa/fn/item/reliclistPromptFunction'));
   app.use('/fn/getApi/cultureRelic', require('./routes/api/kcisa/fn/item/cultureRelic'));
   app.use('/fn/getApi/relic', require('./routes/api/kcisa/fn/item/relicFunction'));
   app.use('/fn/getApi/reliclist', require('./routes/api/kcisa/fn/item/reliclistFunction'));
   app.use('/fn/getApi/notmatch', require('./routes/api/kcisa/fn/item/notmatch'));
   app.use('/fn/getApi/event', require('./routes/api/kcisa/fn/item/event'));
   app.use('/fn/getApi/multi_intent', require('./routes/api/kcisa/fn/item/multiIntent'));
   //-- RESTFul API Management KCISA (E) ----------------------------------------------------------


   //-- RESTFul API Management WORKNET (S) ----------------------------------------------------------
   //api 개발 목록 확인.
   app.use('/ap/worknet/apilistdev', require('./routes/api/worknet/apilistdev'));
   app.use('/ap/worknet/sampleinputparam', require('./routes/api/worknet/sampleinputparam'));
   app.use('/ap/worknet/sampleoutputparam', require('./routes/api/worknet/sampleoutputparam'));
   app.use('/ap/worknet/searchsimilar', require('./routes/api/worknet/fn/searchsimilar'));
   app.use('/ap/worknet/menusearch', require('./routes/api/worknet/fn/menusearch'));
   app.use('/ap/worknet/menumatch', require('./routes/api/worknet/fn/menumatch'));
   app.use('/ap/worknet/wanted', require('./routes/api/worknet/fn/wanted'));
   app.use('/ap/worknet/policy', require('./routes/api/worknet/fn/policy'));
   app.use('/ap/worknet/recommend', require('./routes/api/worknet/fn/recommend'));
   app.use('/ap/worknet/center', require('./routes/api/worknet/fn/center'));
   app.use('/worknet/chatbot', require('./routes/api/worknet/v1/chatbot'));

   //mobile
   app.use('/ap/worknet/m/wanted', require('./routes/api/worknet/fn/mobile/wanted'));
   app.use('/ap/worknet/m/policy', require('./routes/api/worknet/fn/mobile/policy'));
   app.use('/ap/worknet/m/recommend', require('./routes/api/worknet/fn/mobile/recommend'));
   app.use('/ap/worknet/m/menumatch', require('./routes/api/worknet/fn/mobile/menumatch'));

   //-- RESTFul API Management WORKNET (E) ----------------------------------------------------------

   app.use('/ap/worknet/fnTest', require('./routes/api/worknet/fn/test1210'));
   app.use('/ap/worknet/josaTest', require('./routes/api/worknet/fn/josa'));
   app.use('/ap/worknet/sample', require('./routes/api/worknet/fn/sample'));
   app.use('/ap/worknet/copy', require('./routes/api/worknet/fn/copy_index'));
   app.use('/ap/worknet/copy_blank', require('./routes/api/worknet/fn/copy_blank_index'));
   app.use('/test', require('./routes/test'));
   app.use('/els', require('./routes/api/kcisa/fn/item/els_search'));
   app.use('/get_dupl', require('./routes/api/sample'));

   app.use('/get_new_line', require('./routes/api/worknet/fn/new_line'));
   app.use('/get_new_line_up', require('./routes/api/worknet/fn/new_line_upsert'));
};
