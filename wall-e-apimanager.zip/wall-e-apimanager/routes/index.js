var express = require('express');
var router = express.Router();

/* GET home page. */
router.get('/', function(req, res) {
	res.render('index', { 
		title: 'wall-e RESTFul API Service' , 
		apilisturl : '<a href=\"www.naver.com\"/>' 
	});
  //res.send('단추-머신러닝 연계 API');
});

// ignore request favicon
router.get('/favicon.ico', function ignoreFavicon(req, res) {
	res.send(204);
});

module.exports = router;
