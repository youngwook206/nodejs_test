const express = require('express');
const router = express.Router();
const path = require('path');
const fs = require('fs');
const EventEmitter=require('events').EventEmitter
const filename = path.basename(__filename);
const approot = require('app-root-path');
const util = require(approot + '/util/util');
const es = require(approot + '/util/es');


// elapsed time
let elapsed = {};
let start, end;

let s_result = [];
let request_set = [];
let response_set = [];
let add_parameter = [];
let param_obj = [];
let sce_param_obj = [];
let recall_parameters = [];

let ywFiles = [];
let hrFiles = [];

//***********************************************************************************************************
//  Process Logic : 메뉴 보기
//***********************************************************************************************************
/* GET users listing. */
router.get('/', function(req, res) {
	sample_handler(req, res);
});

/* POST users listing. */
router.post('/', function(req, res) {
	sample_handler(req, res);
});


// -- promiss handler
let sample_handler = function(req,res){
	util.req_param('사진 중복체크',req,filename);
	elapsed = {};
	start = new Date();
	if(req.method == "POST") req.query = req.body;

	Promise
	.all([sample_paramcheck(req,res)])
	.then(function(){return _promise_checktime('paramcheck');})
	.then(function(){return sample_work(req,res);})
	.then(function(){return _promise_checktime('menu_view');})
	.then(function(){return sample_sendresult(req,res);})
	.catch(function(err){return _promise_errhandler(req,res,err);})
	;
};

let sample_work = async(req,res)=>{
	console.debug('[menumatch] sample_work - start');

	let filelist1 = [];
	let filelist2 = [];
	let goal_list = [];
	let finalFiles = [];
	let sf_folder = "/mnt/d/SF_FINAL";
	let yw_folder = "/mnt/d/photo_test/yw";
	let hr_folder = "/mnt/d/photo_test/hr";
	let goal_folder = "/mnt/d/photo_test/goal";
	let hr_etc_folder = "/mnt/d/photo_test/hr_etc";


	let getFinalFileList =()=> {
		return new Promise(function(resolve,reject) {
			console.log('getSourceFileList');


			fs.readdir(sf_folder, function(error, filelist){
				console.log('final filelist length : ' + filelist.length);
				filelist.forEach( el=> {
					console.log(el);
					finalFiles.push( el );
				});
				resolve();
			});
		});
	}

	let getSourceFileList =()=> {
		return new Promise(function(resolve,reject) {
			console.log('getSourceFileList');

			fs.readdir(yw_folder, function(error, filelist){
				console.log('yw filelist length : ' + filelist.length);
				filelist.forEach( el=> {
					ywFiles.push( el );
				});
				resolve();
			});
		});
	}

	let getTargetFileList =()=> {
		return new Promise(function(resolve,reject) {
			console.log('getTargetFileList');
			fs.readdir(hr_folder, function(error, filelist){
				console.log('hr filelist length : ' + filelist.length);

				filelist.forEach( el=> {
					hrFiles.push( el );
				});
				console.log('getTargetFileList end');
				resolve();
			});
		});
	}

	let checkDupl =()=> {
		return new Promise(function(resolve,reject) {

			console.log('checkFileList');

			// console.log('1- ywFiles:'+JSON.stringify(ywFiles));
			// console.log('2- hrFiles:'+JSON.stringify(hrFiles));
			console.log('ywFiles length : ' + ywFiles);
			console.log('hrFiles length : ' + hrFiles);

			hrFiles.forEach( el => {
				ywFiles.forEach( s_el => {
					if(el.toLowerCase() == s_el.toLowerCase()) {
						console.log('same : ' + el + ' / ' + s_el);
						//fs.rename(oldpath, newpath, callback);
						goal_list.push(el);
						/*
						let source = hr_folder + '/' + el;
						let destination = goal_folder + '/' + el;
						fs.copyFile(source, destination, (err) => {
							if (err) throw err;
							console.log(source+'==> '+destination);
						});
						*/
					}
				});
			});

			resolve();
		});
	}

	let delDupl =()=> {
		return new Promise(function(resolve,reject) {
			console.log('delDupl');

			hrFiles.forEach( el => {
				goal_list.forEach( s_el => {
					if(el.toLowerCase() == s_el.toLowerCase()) {
						let source = hr_etc_folder + '/' + el;
						fs.unlinkSync(source);
					}
				});
			});
			resolve();
		});
	}


	await getFinalFileList();
	// await getSourceFileList();
	// await getTargetFileList();
	// await checkDupl();
	// await delDupl();
}

let sample_paramcheck = function(req,res){
	return new Promise(function(resolve, reject){
		console.debug('[menumatch] sample_paramcheck - start');
		let err = req.validationErrors();
		if(err) {
			err.status = 400;
			res.status(400).send(util.res_err(req, 400, err[0].msg));
			console.error(err[0].msg,filename);
			return reject();
		}else{
			req.query.domain_id = req.query.domain_id || "";
			console.debug('[sample_paramcheck] req.query.domain_id : ' + req.query.domain_id);
			return resolve();
        }
	});
};

let sample_sendresult = async(req,res)=>{
	console.debug('[sample] sample_sendresult - start');
    const response_set =
	[
        {"name":"질의어","field":"req_in_str","value":[],"type":"string"},
		{"name":"매칭인텐트","field":"res_intent","value":[],"type":"string"},
		{"name":"질의시간","field":"timestamp","value":[],"type":"string"}
    ];
    let request_set = [];

    let getSendResult =()=>{
		return new Promise(function(resolve, reject){
			console.debug('sample_sendresult > getSendResult - start');

			res.set({'Content-Type': 'text/json; charset=utf-8'});
			let messageObj =
			{
                recall_inform : {
    				recall_parameters : recall_parameters,
    				scenario_parameters : sce_param_obj,
    				recall_type : req.query.recall_type,
    				response_type : "answer"
    			},
				id : "sample",
				name : "api sample",
				description : "api sample",
				request :request_set,
				mapping_info:response_set,
				response :
						{
							items:response_set
						},
				script: {
							type : "url",
							script_code: ""
				  		},
                add_parameter: add_parameter
			}

			if( req.query.condition != 'init' ) {
				let response_item_set = {"items":[]};
				response_set.forEach(v_item=>{
					v_item.value = [];
				});

				let setData = (v_item,element)=>{
					let rs_item={};
					let v_field = v_item.field;
					let set_value = "";
					for(let in_field in element){
						if(in_field == v_field){
							set_value = element[in_field];
						}
					}
					v_item.value.push(set_value);
				}

				s_result.forEach(element => {
                    response_set.forEach((v_item)=>{
						setData(v_item,element._source);
					});
				});
			}
            //console.check("messageObj:::::::",JSON.stringify(messageObj,null,2));

			res.send(messageObj);
			return resolve();
		});
	}

	await getSendResult();
};


//***********************************************************************************************************
//  Process Logic Area (E)
//***********************************************************************************************************

let _promise_checktime = function(name){
	return new Promise(function(resolve, reject){
        // elapsed time
        end = new Date();
        elapsed[name] = (end - start) + ' ms';
        console.debug('_promise_checktime ! - '+name+' ['+elapsed[name]+']');
        return resolve();
    });
};

let _promise_errhandler = function(req,res,err){
	return new Promise(function(resolve, reject){
		if(typeof(err) != 'undefined'){
			console.error(err,filename);
		    //res.status(500).send(util.res_err(req, 500, err.message));

		    res.status(err.status || 500);
		    res.render('error', {
		    	message: err.message,
		    	error: err
		    });
		    return resolve();
		}else{
			return resolve();
		}
	});
};

module.exports = router;
