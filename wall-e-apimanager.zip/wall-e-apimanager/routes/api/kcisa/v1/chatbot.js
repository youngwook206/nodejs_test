var express = require('express');
var router = express.Router();
var path = require('path');
var filename = path.basename(__filename);
var approot = require('app-root-path');
var util = require(approot + '/util/util');
var urlencode = require('urlencode');
var elapsed = {};
var start, end;
var body = {};
var site_id = "kcisa";

/* GET users listing. */
router.get('/', function(req, res) {
	promisshandler(req, res);
});

/* POST users listing. */
router.post('/', function(req, res) {
	promisshandler(req, res);
});


//***********************************************************************************************************
//  Process Logic Area (S)
//***********************************************************************************************************
var site_name = 'kcisa';

var config = require(approot + '/config/config');

// elasticsearch
var es = require(approot + '/util/es');

// redis
var redis = require(approot + '/util/redis');
var redis_meta = require(approot + '/util/redis_meta');

// uuid
const uuidv1 = require('uuid/v1');
const uuidv4 = require('uuid/v4');

// -- promiss handler
var promisshandler = function(req,res){
	util.req_param('[API] chatbot',req,filename);

	elapsed = {};
	body = {};
	start = new Date();
	if(req.method == "POST") req.query = req.body;

	Promise
	.all([_promise_paramcheck(req,res)])
	.then(function(){return _promise_checktime('paramcheck');})
	.then(function(){return _promise_work_insert(req,res);})
	.then(function(){return _promise_checktime('work insert');})
	.then(function(){return _promise_work_process(req,res);})
	.then(function(){return _promise_checktime('work process');})
	.then(function(){return _promise_work_select(req,res);})
	.then(function(){return _promise_checktime('work select');})
	.then(function(){return _promise_work_meta(req,res);})
	.then(function(){return _promise_checktime('work meta insert');})

	.then(function(){return _promise_sync_message(req,res);})
	.then(function(){return _promise_lang_Translation_speech(req,res);})
	.then(function(){return _promise_lang_Translation_display_message(req,res);})
	.then(function(){return _promise_lang_Translation_message(req,res);})
	.then(function(){return _promise_checktime('work lang Translation');})
	.then(function(){return _promise_sendresult(req,res);})
	.catch(function(err){return _promise_errhandler(req,res,err);})
	;

};

var _promise_paramcheck = function(req,res){
	return new Promise(function(resolve, reject){

		req.query.output = req.query.output || '';
		req.query.template = req.query.template || '';
		if(req.query.output == 'sample' && req.query.template != ''){
			//sample일 경우 파라미터 체크 안함.
		}else{
			req.checkQuery('user_id', 'user_id required').notEmpty();
			req.checkQuery('domain_id', 'domain_id required').notEmpty();
			req.checkQuery('in_str', 'in_str required').notEmpty();
		}
		var err = req.validationErrors();

		if(err) {
			err.status = 400;
			res.status(400).send(util.res_err(req, 400, err[0].msg));
			console.error(err[0].msg,filename);
			return reject();
		}else{
			//init parameter
			req.query = req.query || '{}';
			req.query.output = req.query.output || '';
			req.query.template = req.query.template || '';
			req.query.lang = req.query.lang || '';

			req.query.rediskey = req.query.rediskey || '';
			req.query.body = req.query.body || {};
			req.query.user_id = req.query.user_id || '';
			req.query.domain_id = req.query.domain_id || '';
			req.query.in_str = req.query.in_str || '';
			req.query.meta_before = req.query.meta_before || '{}';
			req.query.response_type = req.query.response_type || '';
			req.query.req_dialogue_id = req.query.dialogue_id || '';//화면에서 강제적으로 dialogue_id 넘어온 경우. ex)뒤로가기 - 아직 미구현
			req.query.debug = req.query.debug || 'false';
			req.query.session_id = req.query.session_id || '';//세션값이 비어 있을 경우 강제적으로 초기대화셋팅

			req.query.action = req.query.action || '{}';
			req.query.chatflow_run_check = req.query.chatflow_run_check || undefined;

			return resolve();
		}

	});
};

var _promise_work_insert = function(req,res){
	return new Promise(function(resolve, reject){
		req.query.rediskey = req.query.rediskey || '';
		var fs = require('fs');
		var result = fs.readFileSync(approot+'/routes/api/'+site_name+'/sampleoutputparam.json', 'utf8');
		result = JSON.parse(result);
		req.query.body = result;

		if(req.query.output == 'sample' && req.query.template != ''){
			result = fs.readFileSync(approot+'/routes/api/'+site_name+'/sampleoutputparam.'+req.query.template+'.json', 'utf8');
			result = JSON.parse(result);
			req.query.body = result;
			return resolve();
		}else{
			if(req.method == "GET"){
				var errStatus = 400;
				res.status(errStatus).send(util.res_err(req, errStatus, "Please send to POST"));
				return reject();
			}else if(req.method == "POST"){
				//redis query insert !
				redis_meta.hgetall(req.query.user_id,function(err, obj){
					if(obj == null) {
						if(err != null) console.error(err);
						req.query.meta_before = '{}';
						req.query.dialogue_id = uuidv4();
						req.query.action = '{}';
					}else{
						req.query.action = obj.action;
						req.query.meta_before = obj.meta_before;
						req.query.dialogue_id = obj.dialogue_id;
						if(obj.response_type == 'answer' && !obj.chatflow_run_check) req.query.dialogue_id = uuidv4();

						if(req.query.session_id == '' ){
							console.debug("redis session id empty !! - setting chatflow_run_check is false");
							req.query.meta_before = '{}';
							req.query.dialogue_id = uuidv4();
						}
					}

					var rediskey = redisDataInsert(req);
					req.query.rediskey = rediskey;
					req.query.body = {};
					return resolve();
				});
			}
		}

	});
};

var _promise_work_process = function(req,res){
	return new Promise(function(resolve, reject){

		if(req.query.output == 'sample' && req.query.template != ''){
			return resolve();
		}else{
			if(req.query.rediskey != ''){
				console.debug("run datamanager !!");

				let datamanagerUrl = config.datamanager_url;
				datamanagerUrl = datamanagerUrl + '?rediskey='+req.query.rediskey+"&site_id="+site_id;
				console.debug("datamanagerUrl : "+datamanagerUrl);
				let request = require('request');
				let headerVal = {'Content-Type': 'application/json'};

				let options = {
					method: 'GET',
					//headers: headerVal,
					url : datamanagerUrl,
					//body: JSON.stringify({rediskey: req.query.rediskey}),
					//body: 'rediskey='+req.query.rediskey,
					timeout : config.datamanager_timeout
				}

				request(options, function (error, response, body) {
					if(error != null){
						console.error("datamanagerUrl : "+datamanagerUrl);
						console.error(error);
					}else{
						console.trace('statusCode : ' + response.statusCode);
						console.trace('body : ' + body);
					}
					if(error == null){
						req.query.body = (JSON.parse(body)).data;
					}
					return resolve();
				});

			}else{
				console.debug("pass datamanager !!");
				var errStatus = 400;
				res.status(errStatus).send(util.res_err(req, errStatus, "Pass DataManager - empty rediskey !"));
				return reject();
			}
		}

	});
};

var _promise_work_select = function(req,res){
	return new Promise(function(resolve, reject){

		if(req.query.output == 'sample' && req.query.template != ''){
			return resolve();
		}else{
			if(req.query.rediskey != ''){

				console.trace("rediskey : "+ req.query.rediskey);
				redis.hgetall(req.query.rediskey,function(err, obj){
					if(typeof(obj.res_body) == 'undefined'){
						console.warn('redis hgetall res_body value : '+obj.res_body);
						req.query.body = JSON.parse('{}');
					}else{
						req.query.body = JSON.parse(obj.res_body);
						req.query.user_id = obj.user_id;
						req.query.response_type = obj.response_type;
						req.query.dialogue_id = obj.dialogue_id;
						req.query.response = obj.response;
						req.query.lang = obj.lang;
						req.query.action = obj.action;
					}
					return resolve();
				});

			}else{
				console.debug("pass redis data !!");
				var errStatus = 400;
				res.status(errStatus).send(util.res_err(req, errStatus, "Pass DataManager - empty rediskey !"));
				return reject();
			}
		}

	});
};

var _promise_work_meta = async(req,res) =>{

	if(req.query.output == 'sample' && req.query.template != ''){
		// return resolve();
	}else{
		if(req.query.rediskey != ''){
			await redisDataInsertMeta(req);
		}else{
			// console.debug("pass redis data !!");
			// var errStatus = 400;
			// res.status(errStatus).send(util.res_err(req, errStatus, "empty rediskey !"));
		}
	}
	// return new Promise(function(resolve, reject){
	//
	// 	if(req.query.output == 'sample' && req.query.template != ''){
	// 		return resolve();
	// 	}else{
	// 		if(req.query.rediskey != ''){
	// 			redisDataInsertMeta(req);
	// 			return resolve();
	// 		}else{
	// 			console.debug("pass redis data !!");
	// 			var errStatus = 400;
	// 			res.status(errStatus).send(util.res_err(req, errStatus, "empty rediskey !"));
	// 			return reject();
	// 		}
	// 	}
	// });
};

var _promise_change_speech_parameters = function(req,res){
	return new Promise(function(resolve, reject){

		if(req.query.output == 'sample' && req.query.template != ''){
			return resolve();
		}else{
			if(req.query.rediskey != ''){
				let parameters = [];
				try{parameters = req.query.body.result.meta.parameters;}catch(err){parameters = []; console.error('parameters []');}

				let speech = '';
				console.trace(req.query.body.result.fulfillment);
				try{speech = req.query.body.result.fulfillment.speech;}catch(err){speech = '';}

				if(parameters != null){
					for(let i=0;i<Object.keys(parameters).length;i++){
						let key = parameters[i].key;
						let value = parameters[i].value;
						//speech = speech.replace(/\$\{"+key+"\}/g, value);

						console.error('[trans] speech :' + speech);
						if(speech.indexOf("$") != -1){
							speech = speech.replace(new RegExp("\\$\\{"+key+"\\}","g"), value);
							req.query.body.result.fulfillment.speech = speech;
						}
					}
					return resolve();
				}else{
					console.error('[trans] speech :' + speech);
					return resolve();
				}
			}else{
				console.debug("pass redis data !!");
				var errStatus = 400;
				res.status(errStatus).send(util.res_err(req, errStatus, "empty rediskey !"));
				return reject();
			}
		}

	});
};


var _promise_change_speech_response = function(req,res){
	return new Promise(function(resolve, reject){

		if(req.query.output == 'sample' && req.query.template != ''){
			return resolve();
		}else{
			if(req.query.rediskey != ''){
				let response = [];
				try{response = req.query.response.response.items;}catch(err){response = [];}

				let speech = '';
				// console.trace(req.query.body.result.fulfillment);
				try{speech = req.query.body.result.fulfillment.speech;}catch(err){speech = '';}

				if(response != null){
					for(let i=0;i<Object.keys(response).length;i++){
						let key = response[i].name;
						let value = '';
						try{value = response[i].value[0];}catch(err){value = '';}
						//speech = speech.replace(/\$\{"+key+"\}/g, value);

						if(speech.indexOf("@") != -1){
							speech = speech.replace(new RegExp("\\@\\{"+key+"\\}","g"), value);
							req.query.body.result.fulfillment.speech = speech;
						}
					}
					return resolve();
				}else{
					return resolve();
				}
			}else{
				console.debug("pass redis data !!");
				var errStatus = 400;
				res.status(errStatus).send(util.res_err(req, errStatus, "empty rediskey !"));
				return reject();
			}
		}

	});
};


var _promise_change_display_message_parameters = function(req,res){
	return new Promise(function(resolve, reject){

		if(req.query.output == 'sample' && req.query.template != ''){
			return resolve();
		}else{
			if(req.query.rediskey != ''){
				let parameters = [];
				try{parameters = req.query.body.result.meta.parameters;}catch(err){parameters = [];}

				let display_message = '';
				try{display_message = req.query.body.result.fulfillment.display_message;}catch(err){display_message = '';}

				if(parameters != null){
					for(let i=0;i<Object.keys(parameters).length;i++){
						let key = parameters[i].key;
						let value = parameters[i].value;
						//display_message = display_message.replace(/\$\{"+key+"\}/g, value);
						if(display_message.indexOf("$") != -1){
							display_message = display_message.replace(new RegExp("\\$\\{"+key+"\\}","g"), value);
							req.query.body.result.fulfillment.display_message = display_message;
						}
					}
					return resolve();
				}else{
					return resolve();
				}
			}else{
				console.debug("pass redis data !!");
				var errStatus = 400;
				res.status(errStatus).send(util.res_err(req, errStatus, "empty rediskey !"));
				return reject();
			}
		}

	});
};

var _promise_change_display_message_response = function(req,res){
	return new Promise(function(resolve, reject){

		if(req.query.output == 'sample' && req.query.template != ''){
			return resolve();
		}else{
			if(req.query.rediskey != ''){
				let response = [];
				try{response = req.query.response.response.items;}catch(err){response = [];}

				let display_message = '';
				try{display_message = req.query.body.result.fulfillment.display_message;}catch(err){display_message = '';}

				if(response != null){
					for(let i=0;i<Object.keys(response).length;i++){
						let key = response[i].key;
						let value = '';
						try{value = response[i].value[0];}catch(err){value = '';}
						//display_message = display_message.replace(/\$\{"+key+"\}/g, value);
						if(display_message.indexOf("@") != -1){
							display_message = display_message.replace(new RegExp("\\@\\{"+key+"\\}","g"), value);
							req.query.body.result.fulfillment.display_message = display_message;
						}
					}
					return resolve();
				}else{
					return resolve();
				}
			}else{
				console.debug("pass redis data !!");
				var errStatus = 400;
				res.status(errStatus).send(util.res_err(req, errStatus, "empty rediskey !"));
				return reject();
			}
		}

	});
};

var _promise_lang_Translation_speech = function(req,res){
	return new Promise(function(resolve, reject){

		if(req.query.output == 'sample' && req.query.template != ''){
			return resolve();
		}else{
			if(req.query.rediskey != ''){

				let check = /[ㄱ-ㅎ|ㅏ-ㅣ|가-힝]/;
				let speech = req.query.body.result.fulfillment.speech;
				//req.query.lang = 'en';
				if(req.query.lang != 'ko' && check.test(speech)){

					let translation_url = config.translation_url;
					let translation_key = config.translation_key;
					translation_url = translation_url + '?key=' +translation_key+ '&text='+speech;

					let error_message = 'Sorry. Translation failed with transient errors.';
					let trans_lang = '&source=KOR&target=ENG';
					if(req.query.lang == 'en') {
						trans_lang = '&source=KOR&target=ENG';
                        error_message = 'Sorry. Translation failed with transient errors.';
                    }
					if(req.query.lang == 'zh') {
						trans_lang = '&source=KOR&target=CHN';
                        error_message = '抱歉。 翻译因瞬态错误而失败。';
                    }
					if(req.query.lang == 'ja') {
						trans_lang = '&source=KOR&target=JPN';
                        error_message = '申し訳ありません。一時的なエラーの翻訳に失敗しました。';
                    }

					translation_url = translation_url + trans_lang;
					console.debug("translation_url : "+translation_url);
					let request = require('request');
					let urlencode = require('urlencode');

					let options = {
						method: 'GET',
						url: config.translation_url+'?key=' +translation_key+'&text='+urlencode(speech)+trans_lang,
						body: '',
						timeout : config.translation_timeout
						//,
						//headers: {
						//	'content-type': 'application/x-www-form-urlencoded'
						//}
					};

					request(options, function (error, response, body) {
						if(error != null){
							console.error("translation_url : "+translation_url);
							console.error(error);
						}else{
							console.trace('statusCode : ' + response.statusCode);
							console.trace('body : ' + body);
						}
						if(error == null){
							//req.query.body = (JSON.parse(body)).data;
							try{
								req.query.body.result.fulfillment.speech = (JSON.parse(body)).result;
								if( req.query.body.result.fulfillment.speech == null ){
									req.query.body.result.fulfillment.speech = error_message;
								}
							}catch(e){
								console.error("translation_url : "+translation_url);
								console.error('statusCode : ' + response.statusCode);
								console.error('body : ' + body);
								req.query.body.result.fulfillment.speech = "response statusCode : " + response.statusCode;
							}
						}
						return resolve();
					});

				}else{
					return resolve();
				}
			}else{
				console.debug("pass redis data !!");
				var errStatus = 400;
				res.status(errStatus).send(util.res_err(req, errStatus, "empty rediskey !"));
				return reject();
			}
		}

	});
};

var _promise_lang_Translation_display_message = function(req,res){
	return new Promise(function(resolve, reject){

		let speech = req.query.body.result.fulfillment.speech;

		if(req.query.output == 'sample' && req.query.template != ''){
			return resolve();
		}else{
			if(req.query.rediskey != ''){

				let check = /[ㄱ-ㅎ|ㅏ-ㅣ|가-힝]/;
				let display_message = req.query.body.result.fulfillment.display_message;
				//req.query.lang = 'en';
				if(req.query.lang != 'ko' && check.test(display_message)){

					let translation_url = config.translation_url;
					let translation_key = config.translation_key;
					translation_url = translation_url + '?key=' +translation_key+ '&text='+speech;

                    let error_message = 'Sorry. Translation failed with transient errors.';
                    let trans_lang = '&source=KOR&target=ENG';
                    if(req.query.lang == 'en') {
                        trans_lang = '&source=KOR&target=ENG';
                        error_message = 'Sorry. Translation failed with transient errors.';
                    }
                    if(req.query.lang == 'zh') {
                        trans_lang = '&source=KOR&target=CHN';
                        error_message = '抱歉。 翻译因瞬态错误而失败。';
                    }
                    if(req.query.lang == 'ja') {
                        trans_lang = '&source=KOR&target=JPN';
                        error_message = '申し訳ありません。一時的なエラーの翻訳に失敗しました。';
                    }

					translation_url = translation_url + trans_lang;
					console.debug("translation_url : "+translation_url);
					let request = require('request');
					let urlencode = require('urlencode');

					let options = {
						method: 'GET',
						url: config.translation_url+'?key=' +translation_key+'&text='+urlencode(speech)+trans_lang,
						body: '',
						timeout : config.translation_timeout
						//,
						//headers: {
						//	'content-type': 'application/x-www-form-urlencoded'
						//}
					};

					request(options, function (error, response, body) {
						if(error != null){
							console.error("translation_url : "+translation_url);
							console.error(error);
						}else{
							console.trace('statusCode : ' + response.statusCode);
							console.trace('body : ' + body);
						}
						if(error == null){
							//req.query.body = (JSON.parse(body)).data;
							req.query.body.result.fulfillment.display_message = (JSON.parse(body)).result;
							if( req.query.body.result.fulfillment.display_message == null ){
								req.query.body.result.fulfillment.display_message = error_message;
							}
						}
						return resolve();
					});

				}else{
					return resolve();
				}
			}else{
				console.debug("pass redis data !!");
				var errStatus = 400;
				res.status(errStatus).send(util.res_err(req, errStatus, "empty rediskey !"));
				return reject();
			}
		}

	});
};

// html 값이 비어 있으면 speech 와 동일한 값을 세팅
var _promise_sync_message = function(req, res) {
    return new Promise(function(resolve, reject){
        if(req.query.output == 'sample' && req.query.template != ''){
            return resolve();
        }else{
            let fulfillment = req.query.body.result.fulfillment;
            let speech = fulfillment.speech;

            let messages = [];
            try{messages = fulfillment.messages;}catch(err){messages = [];}

			for (let i = 0; i < messages.length; i++) {
				let messagesKey = Object.keys(messages[i]);

            	if(messagesKey.indexOf("html") !== -1) {

            		if(messages[i].html.length > 0) {
                        for (let j = 0; j < messages[i].html.length; j++) {
                            let htmlKeys = Object.keys(messages[i].html[j]);
                            if (htmlKeys.indexOf("content") !== -1) {
                                if (messages[i].html[j].content === "" && speech !== "") {
                                    messages[i].html[j].content = speech;
                                }
                            }
                        }
					} else {
                        messages[i].html[0] = {
                            'content': speech
                        };
					}
                }
			}

            return resolve();
        }

    });

};

var _promise_lang_Translation_message = function(req,res){
	return new Promise(function(resolve, reject){

		if(req.query.output == 'sample' && req.query.template != ''){
			return resolve();
		}else{
			if(req.query.rediskey != ''){
				let sync_exec = require('sync-exec');
				let urlencode = require('urlencode');

				let translation_url = config.translation_url;
				let translation_key = config.translation_key;
				translation_url = translation_url + '?key=' +translation_key;

                let error_message = '(traslation error)';
                let trans_lang = '&source=KOR&target=ENG';
                if(req.query.lang == 'en') {
                    trans_lang = '&source=KOR&target=ENG';
                    error_message = '(traslation error)';
                }
                if(req.query.lang == 'zh') {
                    trans_lang = '&source=KOR&target=CHN';
                    error_message = '(翻译错误)';
                }
                if(req.query.lang == 'ja') {
                    trans_lang = '&source=KOR&target=JPN';
                    error_message = '(翻訳エラー)';
                }

				translation_url = translation_url + trans_lang;
				//console.check("translation_url : "+translation_url);

				let fulfillment = req.query.body.result.fulfillment;

				// TEST SOURCE (S)
				//fulfillment = "{\"messages\":[{\"image\":[{\"url\":\"http://cdn.museum.go.kr/attach_files/THUMB_H_20180201182242311_002.jpg\",\"title\":\"톱니날석기\"}]},{\"description\":[{\"text\":\"톱니날은 몸돌에서 떼어 낸 격지의 가장자리에 작은 홈날이 연속으로 두 개 이상 있는 석기로, 마치 톱니처럼 보입니다. 홈의 크기는 홈날에 비해 작은 편입니다. 홈날은 몇 차례 손질하여 오목한 날로 만들며, 톱니날은 연속적인 가공으로 만드는 것이 특징입니다. 날의 반대편은 상대적으로 뭉툭하여 손으로 잡거나 나무 등에 장착할 수 있습니다.\"}]},{\"custom\":[{\"exhibition_code\":\"DT0001\",\"showroom_code\":\"DM0002\",\"floor_num\":\"1\"}]},{\"html\":[{\"content\":\"<div class='ib_temp_div'>\\n<div class='ib_temp_t_layout'>\\n<ul class='t_cont'>\\n<li class='c_mk'><div class='s_tit_tp2'>박물관 관람 시 유의사항</div></li>\\n<li class='c_cont'>박물관의 모든 공간은 금연구역입니다.</li>\\n<li class='c_cont'>음식물 반입과 안내견 이외의 애완동물의 출입은 금지되어 있습니다.</li>\\n<li class='c_cont'>전시실 입장 전에, 휴대전화는 전원을 꺼주시거나 진동으로 전환하여 주십시오.</li></li>\\n<li class='c_cont'>전시관에서는 정숙해 주시고 뛰어다니는 행위는 삼가시길 바랍니다.</li>\\n<li class='c_cont'>전시관에서는 바퀴달린 신발을 신은 고객은 입장이 불가합니다.</li>\\n<li class='c_cont'>전시물에 손을 대거나 손상을 입힐 수 있는 행위는 절대 삼가 주십시오.</li>\\n<li class='c_cont'>플래시/삼각대 등을 이용한 촬영과 상업적 용도를 위한 촬영은 금지되어 있습니다.</li>\\n<li class='c_cont'>야외 관람로에서는 자전거, 킥보드, 인라인스케이트, 스케이트보드 등을 이용할 수 없습니다.</li>\\n<li class='c_cont'>슬리퍼 등 정숙한 관람을 해치는 복장은 자제하여 주시기 바랍니다.</li>\\n</ul>\\n</div>\\n</div>\"}]}],\"response_type\":\"answer\",\"speech\":\"${유물}에 대한 안내입니다.\",\"display_message\":\"${유물}에 대한 안내입니다.\",\"page_id\":\"J_Answer_Relic\",\"default_id\":\"\",\"template_id\":\"template_01\",\"dialogue_id\":\"0fe4df84-465b-46cd-9e86-a055871c1376\"}";
				//fulfillment = JSON.parse(fulfillment);
				//console.check(fulfillment);
				// TEST SOURCE (E)

				let messages = [];
				try{messages = fulfillment.messages;}catch(err){messages = [];}
				//console.check(messages);

				let check = /[ㄱ-ㅎ|ㅏ-ㅣ|가-힝]/;
				let timeout = config.translation_timeout / 1000;

				if(req.query.lang != 'ko'){ //if(req.query.lang != 'ko' && check.test(display_message)){
					for(let i=0;i<messages.length;i++){
						let messagesKey = Object.keys(messages[i]);
						if(messagesKey.indexOf("image") != -1){
							for(let j=0;j<messages[i].image.length;j++){
								let imageKeys = Object.keys(messages[i].image[j]);
								if(imageKeys.indexOf("title") != -1){
									let value = messages[i].image[j].title;
									if(!check.test(value)) continue;
									// console.check(translation_url+"&text="+value);
									let curlstring = "curl -XGET -G \'"+translation_url+"\' --connect-timeout "+timeout+" --data-urlencode \'text="+value+"\'";
									let curlresult = sync_exec(curlstring);
									//console.check(JSON.stringify(curlresult));
									if(curlresult.stdout != ""){
										messages[i].image[j].title = (JSON.parse(curlresult.stdout)).result;
                                        if( messages[i].image[j].title === null ){
                                            messages[i].image[j].title = error_message;
                                        }
									}else{
										console.error(translation_url+"&text="+value + " \nstderr : " + curlresult.stderr);
									}
								}
							}
						}else if(messagesKey.indexOf("description") != -1 && false){
							for(let j=0;j<messages[i].description.length;j++){
								let descriptionKeys = Object.keys(messages[i].description[j]);
								if(descriptionKeys.indexOf("text") != -1){
									let value = messages[i].description[j].text;
									if(!check.test(value)) continue;
									// console.check(translation_url+"&text="+value);
									let curlstring = "curl -XGET -G \'"+translation_url+"\' --connect-timeout "+timeout+" --data-urlencode \'text="+value+"\'";
									let curlresult = sync_exec(curlstring);
									//console.check(JSON.stringify(curlresult));
									if(curlresult.stdout != ""){
										messages[i].description[j].text = (JSON.parse(curlresult.stdout)).result;
                                        if( messages[i].description[j].text === null ){
                                            messages[i].description[j].text = error_message;
                                        }
									}else{
										console.error(translation_url+"&text="+value + " \nstderr : " + curlresult.stderr);
									}
								}
							}
						}else if(messagesKey.indexOf("button") != -1){
							for(let j=0;j<messages[i].button.length;j++){
								let buttonKeys = Object.keys(messages[i].button[j]);
								if(buttonKeys.indexOf("text") != -1){
									let value = messages[i].button[j].text;
									if(!check.test(value)) continue;
									// console.check(translation_url+"&text="+value);
									let curlstring = "curl -XGET -G \'"+translation_url+"\' --connect-timeout "+timeout+" --data-urlencode \'text="+value+"\'";
									let curlresult = sync_exec(curlstring);
									/*
									console.check(typeof curlresult);
									console.check(curlresult);
									console.check(JSON.stringify(curlresult));
									*/
									if(curlresult.stdout != ""){
										messages[i].button[j].text = (JSON.parse(curlresult.stdout)).result;
										if( messages[i].button[j].text === null ){
											messages[i].button[j].text = error_message;
										}
									}else{
										console.error(translation_url+"&text="+value + " \nstderr : " + curlresult.stderr);
									}
								}
							}
						}else if(messagesKey.indexOf("html") != -1){
							for(let j=0;j<messages[i].html.length;j++){
								let htmlKeys = Object.keys(messages[i].html[j]);
								if(htmlKeys.indexOf("content") != -1){

                                    let value = messages[i].html[j].content;

									if(!check.test(value)) continue;
									if(value.indexOf("<") != -1 && value.indexOf(">") != -1) continue;
									// console.check(translation_url+"&text="+value);
									let curlstring = "curl -XGET -G \'"+translation_url+"\' --connect-timeout "+timeout+" --data-urlencode \'text="+value+"\'";
									let curlresult = sync_exec(curlstring);
									//console.check(JSON.stringify(curlresult));
									if(curlresult.stdout != ""){
										messages[i].html[j].content = (JSON.parse(curlresult.stdout)).result;
                                        if( messages[i].html[j].content === null ){
                                            messages[i].html[j].content = error_message;
                                        }
									}else{
										console.error(translation_url+"&text="+value + " \nstderr : " + curlresult.stderr);
									}
								}
							}
						}
					}// end for
				}//end if
				console.check("end message transrate !!");
				try{req.query.body.result.fulfillment.messages = messages;}catch(err){}
				return resolve();

			}else{
				console.debug("pass redis data !!");
				var errStatus = 400;
				res.status(errStatus).send(util.res_err(req, errStatus, "empty rediskey !"));
				return reject();
			}
		}

	});
};

var _promise_debug_check = function(req,res){
	return new Promise(function(resolve, reject){

		if(req.query.debug != 'true'){
			let body = req.query.body;
			try{
				//console.log(body);
				//console.log(body.result.meta);
				body.result.meta = '{}';
				delete body.result.meta;
				req.query.body = body;
			}catch(err){
				//console.log(err);
			}
			return resolve();
		}else{
			return resolve();
		}


	});
};

var _promise_sendresult = function(req,res){
	return new Promise(function(resolve, reject){

		res.set({'Content-Type': 'text/json; charset=utf-8'});
		//res.send('');

		end = new Date();
		elapsed['sendresult'] = (end - start) + ' ms';
		res.send(util.res_ok(req, {data:req.query.body}, elapsed));

		console.debug('_promise_sendresult !');
		return resolve();
	});
};

function redisDataInsert(req){
	let key = uuidv1();
	let value = [];

	value.push("req_date");
	value.push(util.getDate() || '');

	value.push("channel_id");
	value.push(req.query.channel_id || '');

	value.push("domain_id");
	value.push(req.query.domain_id || '');

	value.push("raw_str");
	value.push(req.query.raw_str || '');

	value.push("in_str");
	value.push(req.query.in_str || '');

	value.push("user_id");
	value.push(req.query.user_id || '');

	value.push("session_id");
	//value.push(req.query.session_id || key);
	value.push(req.sessionID);

	//value.push("parameters_lang");
	value.push("lang");
	value.push(req.query.parameters.lang || '');

	//value.push("parameters_dialogue_id");
	value.push("dialogue_id");
	//value.push(req.query.parameters.dialogue_id || uuidv4());
	value.push(req.query.dialogue_id);

	value.push("parameters");
	value.push(JSON.stringify(req.query.parameters) || '{}');

	value.push("req_body");
	value.push(JSON.stringify(req.query) || '{}');

	value.push("dialogue_status");
	value.push('request');

	value.push("meta_before");
	value.push(req.query.meta_before);

	value.push("response_type");
	value.push('');

	value.push("action");
	value.push(req.query.action);

	redis.hmset(key, value);
	redis.expire(key, config.redis_0_session_ttl);

	return key;
}


var redisDataInsertMeta = async(req)=>{

	var queryAction = JSON.parse(req.query.action);

	var nextIntent = "";
	var getNextIntent =()=>{

	}

	var setRedisMeta =()=>{
		let key = req.query.user_id;
		let value = [];
		value.push("response_type");
		value.push(req.query.response_type);
		value.push("dialogue_id");
		value.push(req.query.dialogue_id);

		let chatflow_run_check = false;
		let step = req.query.body.result.meta.step || {};
		step.current = req.query.body.result.meta.step.current || 0;
		step.total = req.query.body.result.meta.step.total || 0;

		if(req.query.response_type == 'answer' && step.current != step.total){
			chatflow_run_check = true;
			var link_intent_id = queryAction.link_intent_id;
			if(link_intent_id == ""){
				// console.debug("link:::::SSIDHJIUSDHISAHDIASUHDIAWSUHD:::::",link_intent_id);
				chatflow_run_check = false;
			}
		}

		if(req.query.response_type == 'prompt' || chatflow_run_check){
			value.push("meta_before");
			value.push(JSON.stringify(req.query.body.result.meta) || '{}');
			value.push("action");
			value.push(req.query.action || '{}');
		}else{
			value.push("meta_before");
			value.push('{}');
			value.push("action");
			value.push('{}');
		}

		value.push("chatflow_run_check");
		value.push(chatflow_run_check);
		value.push("step_current");
		value.push(step.current);
		value.push("step_total");
		value.push(step.total);

		redis_meta.hmset(key, value);
		redis_meta.expire(key, config.redis_1_session_ttl);
		// return key;
	}

	await getNextIntent();
	await setRedisMeta();

}

//***********************************************************************************************************
//  Process Logic Area (E)
//***********************************************************************************************************

var _promise_checktime = function(name){
	return new Promise(function(resolve, reject){
        // elapsed time
        end = new Date();
        elapsed[name] = (end - start) + ' ms';
        console.debug('_promise_checktime ! - '+name+' ['+elapsed[name]+']');
        return resolve();
    });
};

var _promise_errhandler = function(req,res,err){
	return new Promise(function(resolve, reject){
		if(typeof(err) != 'undefined'){

			console.error(err,filename);

			/*
			//res.status(500).send(util.res_err(req, 500, err.message));
		    res.status(err.status || 500);
		    res.render('error', {
		    	message: err.message,
		    	error: err
		    });
			return resolve();
			*/

			res.set({'Content-Type': 'text/json; charset=utf-8'});
			//res.send('');

			end = new Date();
			elapsed['sendresult'] = (end - start) + ' ms';

			let data = {data:{result:{meta:{},fulfillment:{}}}};
			res.send(util.res_error(req, data, elapsed));

			return resolve();

		}else{
			return resolve();
		}
	});
};

module.exports = router;
