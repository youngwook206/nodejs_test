var express = require('express');
var router = express.Router();
var path = require('path');
var filename = path.basename(__filename);
var approot = require('app-root-path');
var util = require(approot + '/util/util');

// elapsed time
var elapsed = {};
var start, end;

var match_list = [];

// result
var s_result = [];
// elasticsearch
var es = require(approot + '/util/es');
var request_list = [];
var request_set = [

]
var response_set = [
	{"name":"행사명","field":"itemTitle","value":[],"type":"string"},
	{"name":"썸네일이미지","field":"itemThumbImg","value":[],"type":"string"},
	{"name":"행사설명","field":"itemContent","value":[],"type":"string"}
]
var add_parameter = [];



//***********************************************************************************************************
//  Process Logic : 행사 조회
//***********************************************************************************************************
/* GET users listing. */
router.get('/eventAll', function(req, res) {
    event_all_handler(req, res);
});

/* POST users listing. */
router.post('/eventAll', function(req, res) {
    event_all_handler(req, res);
});


// -- promiss handler
var event_all_handler = function(req,res){
    util.req_param('[조회] 행사 전체',req,filename);

    elapsed = {};
    s_result = [];
    start = new Date();
    if(req.method == "POST") req.query = req.body;

    Promise
        .all([event_all_paramcheck(req,res)])
        .then(function(){return _promise_checktime('paramcheck');})
        .then(function(){return event_all_work(req,res);})
        .then(function(){return _promise_checktime('work');})
        .then(function(){return event_all_sendresult(req,res);})
        .catch(function(err){return _promise_errhandler(req,res,err);})
    ;
};

var event_all_paramcheck = function(req,res){
    return new Promise(function(resolve, reject){
        var err = req.validationErrors();
        if(err) {
            err.status = 400;
            res.status(400).send(util.res_err(req, 400, err[0].msg));
            console.error(err[0].msg,filename);
            return reject();
        }else{
            req.query.size = req.query.size || 10;
            req.query.lang = req.query.lang || "ko";
            return resolve();
        }
    });
};

var event_all_work = async(req,res)=>{

    let rs_obj = [];
    let lang = req.query.lang;

    //console.deubg('[event_work] lang : ' + lang);

    let getEventData = ()=>{
        return new Promise(function(resolve, reject){

            //전체 파라미터
            let p_param_obj = req.query.c_param;
            let ret_param = req.query.sce_param;
            if( req.query.condition == 'init' ) {
                return resolve();
            }
            match_list = [];

            let status_value = '현재';
            let gubun = '특별전시';
            if(p_param_obj != undefined){
                let paramChecked = 'N';
                p_param_obj.forEach(function(item){
                    if(item.key == '시점' && item.value != "")  {
                        status_value = item.value;
                        paramChecked = 'Y';
                    } else if(item.key == '행사' && item.value != "")  {
                        gubun = item.value;
                        paramChecked = 'Y';
                    }
                });

                if(paramChecked == 'N') {
                    ret_param.forEach( el_1 => {
                        sub_param = el_1.params;
                        sub_param.forEach( el_2 => {
                            if(el_2.key == '시점' && el_2.value != "")  {
                                status_value = el_2.value;
                            } else if(el_2.key == '행사' && el_2.value != "")  {
                                gubun = el_2.value;
                                paramChecked = 'Y';
                            }
                        });
                    });
                }
            }

            match_list.push( { "match": {  [ "gubun" ] : gubun } } );
            let status_code = '';
            if(gubun == '특별전시') {
				if(status_value == '현재') status_code = 'current';
				if(status_value == '미래') status_code = 'upcomming';
				if(status_value == '과거') status_code = 'past';

                if(lang == 'ja') lang = 'jp';
                match_list.push( { "match": {  [ "lang" ] : lang } } );
			} else if(gubun == '공연') {

                if(status_value == '현재') status_code = '1';
				if(status_value == '미래') status_code = '2';
				if(status_value == '과거') status_code = '3';

            } else if(gubun == '일반행사') {

                if(status_value == '현재') status_code = '1';
            	if(status_value == '미래') status_code = '2';
                if(status_value == '과거') status_code = '3';

            }

            match_list.push( { "match": {  [ "itemStatusCd" ] : status_code } } );
            match_list.push( { "exists": {  [ "field" ] : "itemTitle" } } );

            response_set.forEach(v_item=>{
                rs_obj.push( util.replaceFieldToLang(v_item.field, lang) );
            });

            let response_source = rs_obj;

            /*
            if(status_value == 'past') {
                req.query.size = 10;
            } else {
                req.query.size = 200;
            }
            */

            let s_body =
                {
                    "size": req.query.size,
                    "query": {
                        "bool": {
                            "must": match_list
                        }
                    },
					"sort": [
					     {
					       "regDate.keyword": {
					         "order": "asc"
					       }
					     }
					 ],
                    "_source":response_source
                };

            //console.warn("[event_work_all] s_body : " + JSON.stringify(s_body,null,2));

            es.client1.search({
                index: "tr_event",
                body: s_body
            }).then(function (resp) {
                s_result = resp.hits.hits;
                //console.warn('[event.js] EVENT TOTAL : ' + resp.hits.total);
                return resolve();
            }, function (err) {
                err.status = 400;
                res.status(400).send(util.res_err(req, 400, err.message));
                console.error(err.message,filename);
                return resolve();
            });
        });
    }

    await getEventData();

};

var event_all_sendresult = async(req,res)=>{
    let getSendResult =()=>{
        return new Promise(function(resolve, reject){
            res.set({'Content-Type': 'text/json; charset=utf-8'});
            //console.check('[event_all_sendresult] response_set : '+JSON.stringify(response_set));

            let messageObj =
                {
                    id : "event_message",
                    name : "행사 목록 조회",
                    description : "행사 목록 조회",
                    request :request_set,
                    mapping_info:response_set,
                    response :
                        {
                            items:response_set
                        },
                    script: {
                        type : "url",
                        script_code: ""
                    },
                    add_parameter: add_parameter
                }

            if( req.query.condition != 'init' ) {
                let result = s_result;
                let response_item_set = {"items":[]};
                response_set.forEach(v_item=>{
                    v_item.value = [];
                });

                let setData = (v_item,element)=>{
                    let rs_item={};
                    let req_lang =  "_"+req.query.lang;
                    let v_field= util.replaceFieldToLang(v_item.field, req_lang);
                    let set_value = "";
                    for(let in_field in element){
                        if(in_field == v_field){
                            set_value = element[in_field];
                        }
                    }
                    v_item.value.push(set_value);
                }
                result.forEach(element => {
                    response_set.forEach((v_item)=>{
                        setData(v_item,element._source);
                    });
                });
            }

            res.send(messageObj);
            //console.check('[event_all_sendresult] messageObj : ' + JSON.stringify(messageObj));
            return resolve();
        });
    }
    await getSendResult();
};







//***********************************************************************************************************
//  Process Logic : 특별전시 조회
//***********************************************************************************************************
/* GET users listing. */
router.get('/special', function(req, res) {
	event_special_handler(req, res);
});

/* POST users listing. */
router.post('/special', function(req, res) {
	event_special_handler(req, res);
});


// -- promiss handler
var event_special_handler = function(req,res){
	util.req_param('[조회] 특별전시 전체',req,filename);

	elapsed = {};
	s_result = [];
	start = new Date();
	if(req.method == "POST") req.query = req.body;

	Promise
	.all([event_paramcheck(req,res)])
	.then(function(){return _promise_checktime('paramcheck');})
	.then(function(){return event_special_work(req,res);})
	.then(function(){return _promise_checktime('work');})
	.then(function(){return event_special_sendresult(req,res);})
	.catch(function(err){return _promise_errhandler(req,res,err);})
	;
};

var event_paramcheck = function(req,res){
	return new Promise(function(resolve, reject){
		var err = req.validationErrors();
		if(err) {
			err.status = 400;
			res.status(400).send(util.res_err(req, 400, err[0].msg));
			console.error(err[0].msg,filename);
			return reject();
		}else{
			req.query.size = req.query.size || 200;
			req.query.lang = req.query.lang || "ko";
			return resolve();
        }
	});
};

var event_special_work = async(req,res)=>{

    let rs_obj = [];
	let lang = req.query.lang;
	let gubun = '특별전시';
	if(lang == 'ja') lang = 'jp';

	//console.warn('[event_work] lang : ' + lang);

	response_set.forEach(v_item=>{
		rs_obj.push( util.replaceFieldToLang(v_item.field, lang) );
	});

	let response_source = rs_obj;
	let getEventData = ()=>{
		return new Promise(function(resolve, reject){

            //전체 파라미터
            let p_param_obj = req.query.c_param;
            let ret_param = req.query.sce_param;
			if( req.query.condition == 'init' ) {
				return resolve();
			}
            match_list = [];
			match_list.push( { "match": {  [ "lang" ] : lang } } );
			match_list.push( { "match": {  [ "gubun" ] : gubun } } );

			let status_value = 'current';
            if(p_param_obj != undefined){
				let paramChecked = 'N';
                p_param_obj.forEach(function(item){
					if(item.key == '시점' && item.value != "")  {
						if(item.value == '미래') status_value = 'upcomming';
						if(item.value == '과거') status_value = 'past';
						paramChecked = 'Y';
					}
                });

				if(paramChecked == 'N') {
					ret_param.forEach( el_1 => {
						sub_param = el_1.params;
						sub_param.forEach( el_2 => {
							if(el_2.key == '시점' && el_2.value != "")  {
								if(el_2.value == '미래') status_value = 'upcomming';
								if(el_2.value == '과거') status_value = 'past';
							}
						});
					});
				}
            }

			match_list.push( { "match": {  [ "itemStatusCd" ] : status_value } } );
			match_list.push( { "exists": {  [ "field" ] : "itemTitle" } } );

			/*
			if(status_value == 'past') {
				req.query.size = 10;
			} else {
				req.query.size = 200;
			}
			*/

			let s_body =
			{
			  "size": req.query.size,
			  "query": {
				  "bool": {
					  "must": match_list
					  }
			  },
			  "_source":response_source
			}

            //console.warn("[event_work] s_body : " + JSON.stringify(s_body));

	        es.client1.search({
				index: "tr_event",
	            body: s_body
	        }).then(function (resp) {
	            s_result = resp.hits.hits;
				//console.warn('[event.js] EVENT TOTAL : ' + resp.hits.total);
	            return resolve();
	        }, function (err) {
				err.status = 400;
				res.status(400).send(util.res_err(req, 400, err.message));
				console.error(err.message,filename);
				return resolve();
			});
		});
	}

	await getEventData();

};

var event_special_sendresult = async(req,res)=>{
	let getSendResult =()=>{
		return new Promise(function(resolve, reject){
			res.set({'Content-Type': 'text/json; charset=utf-8'});
			//console.check('[event_special_sendresult] response_set : '+JSON.stringify(response_set));

			let messageObj =
			{
				id : "event_message",
				name : "특별전시 목록 조회",
				description : "특별전시 목록 조회",
				request :request_set,
				mapping_info:response_set,
				response :
						{
							items:response_set
						},
				script: {
							type : "url",
							script_code: ""
				  		},
                add_parameter: add_parameter
			}

			if( req.query.condition != 'init' ) {
                let result = s_result;
				let response_item_set = {"items":[]};
				response_set.forEach(v_item=>{
					v_item.value = [];
				});

				let setData = (v_item,element)=>{
					let rs_item={};
					let req_lang =  "_"+req.query.lang;
					let v_field= util.replaceFieldToLang(v_item.field, req_lang);
					let set_value = "";
					for(let in_field in element){
						if(in_field == v_field){
							set_value = element[in_field];
						}
					}
					v_item.value.push(set_value);
				}
				result.forEach(element => {
					response_set.forEach((v_item)=>{
						setData(v_item,element._source);
					});
				});
			}

			res.send(messageObj);
			//console.check('[event_special_sendresult] messageObj : ' + JSON.stringify(messageObj));
			return resolve();
		});
	}
	await getSendResult();
};

//***********************************************************************************************************
//  Process Logic : 공연 조회
//***********************************************************************************************************
/* GET performance listing. */
router.get('/performance', function(req, res) {
	event_performance_handler(req, res);
});

/* POST performance listing. */
router.post('/performance', function(req, res) {
	event_performance_handler(req, res);
});


// -- promiss handler
var event_performance_handler = function(req,res){
	util.req_param('[조회] 공연 전체',req,filename);


	elapsed = {};
	s_result = [];
	start = new Date();
	if(req.method == "POST") req.query = req.body;

	Promise
	.all([event_paramcheck(req,res)])
	.then(function(){return _promise_checktime('paramcheck');})
	.then(function(){return event_performance_work(req,res);})
	.then(function(){return _promise_checktime('work');})
	.then(function(){return event_performance_sendresult(req,res);})
	.catch(function(err){return _promise_errhandler(req,res,err);})
	;
};

var event_performance_work = async(req,res)=>{

    let rs_obj = [];
	let lang = req.query.lang;
	let gubun = '공연';
	if(lang == 'ja') lang = 'jp';

	//console.warn('[event_performance_work] lang : ' + lang);

	response_set.forEach(v_item=>{
		rs_obj.push( util.replaceFieldToLang(v_item.field, lang) );
	});

	let response_source = rs_obj;
	let getEventData = ()=>{
		return new Promise(function(resolve, reject){

            //전체 파라미터
            let p_param_obj = req.query.c_param;
            let ret_param = req.query.sce_param;
			if( req.query.condition == 'init' ) {
				return resolve();
			}
            match_list = [];
			match_list.push( { "match": {  [ "gubun" ] : gubun } } );

			let status_value = '1';
            if(p_param_obj != undefined){
				let paramChecked = 'N';
                p_param_obj.forEach(function(item){
					if(item.key == '시점' && item.value != "")  {
						if(item.value == '미래') status_value = '2';
						if(item.value == '과거') status_value = '3';
						paramChecked = 'Y';
					}
                });

				if(paramChecked == 'N') {
					ret_param.forEach( el_1 => {
						sub_param = el_1.params;
						sub_param.forEach( el_2 => {
							if(el_2.key == '시점' && el_2.value != "")  {
								if(el_2.value == '미래') status_value = '2';
								if(el_2.value == '과거') status_value = '3';
							}
						});
					});
				}
            }
			match_list.push( { "match": {  [ "itemStatusCd" ] : status_value } } );
			match_list.push( { "exists": {  [ "field" ] : "itemTitle" } } );

			if(status_value == '3') {
				req.query.size = 10;
			} else {
				req.query.size = 200;
			}

			let s_body =
			{
			  "size": req.query.size,
			  "query": {
				  "bool": {
					  "must": match_list
					  }
			  },
			  "_source":response_source
			}

            //console.warn("[event_performance_work] s_body : " + JSON.stringify(s_body));

	        es.client1.search({
				index: "tr_event",
	            body: s_body
	        }).then(function (resp) {
	            s_result = resp.hits.hits;
				// console.warn('[event.js] EVENT TOTAL : ' + resp.hits.total);
	            return resolve();
	        }, function (err) {
				err.status = 400;
				res.status(400).send(util.res_err(req, 400, err.message));
				console.error(err.message,filename);
				return resolve();
			});
		});
	}

	await getEventData();

};

var event_performance_sendresult = async(req,res)=>{
	let getSendResult =()=>{
		return new Promise(function(resolve, reject){
			res.set({'Content-Type': 'text/json; charset=utf-8'});
			let messageObj =
			{
				id : "event_message",
				name : "공연 목록 조회",
				description : "공연 목록 조회",
				request :request_set,
				mapping_info:response_set,
				response :
						{
							items:response_set
						},
				script: {
							type : "url",
							script_code: ""
				  		},
                add_parameter: add_parameter
			}

			if( req.query.condition != 'init' ) {
                let result = s_result;
				let response_item_set = {"items":[]};
				response_set.forEach(v_item=>{
					v_item.value = [];
				});

				let setData = (v_item,element)=>{
					let rs_item={};
					let req_lang =  "_"+req.query.lang;
					let v_field= util.replaceFieldToLang(v_item.field, req_lang);
					let set_value = "";
					for(let in_field in element){
						if(in_field == v_field){
							set_value = element[in_field];
						}
					}
					v_item.value.push(set_value);
				}
				result.forEach(element => {
					response_set.forEach((v_item)=>{
						setData(v_item,element._source);
					});
				});
			}

			res.send(messageObj);
			return resolve();
		});
	}
	await getSendResult();
};

//***********************************************************************************************************
//  Process Logic : 행사 조회
//***********************************************************************************************************
/* GET ceremony listing. */
router.get('/ceremony', function(req, res) {
	event_ceremony_handler(req, res);
});

/* POST ceremony listing. */
router.post('/ceremony', function(req, res) {
	event_ceremony_handler(req, res);
});


// -- promiss handler
var event_ceremony_handler = function(req,res){
	util.req_param('[조회] 행사 전체',req,filename);


	elapsed = {};
	s_result = [];
	start = new Date();
	if(req.method == "POST") req.query = req.body;

	Promise
	.all([event_paramcheck(req,res)])
	.then(function(){return _promise_checktime('paramcheck');})
	.then(function(){return event_ceremony_work(req,res);})
	.then(function(){return _promise_checktime('work');})
	.then(function(){return event_ceremony_sendresult(req,res);})
	.catch(function(err){return _promise_errhandler(req,res,err);})
	;
};

var event_ceremony_work = async(req,res)=>{

    let rs_obj = [];
	let lang = req.query.lang;
	let gubun = '행사';
	if(lang == 'ja') lang = 'jp';

	//console.warn('[event_ceremony_work] lang : ' + lang);

	response_set.forEach(v_item=>{
		rs_obj.push( util.replaceFieldToLang(v_item.field, lang) );
	});

	let response_source = rs_obj;
	let getEventData = ()=>{
		return new Promise(function(resolve, reject){

            //전체 파라미터
            let p_param_obj = req.query.c_param;
            let ret_param = req.query.sce_param;
			if( req.query.condition == 'init' ) {
				return resolve();
			}
            match_list = [];
			match_list.push( { "match": {  [ "gubun" ] : gubun } } );
			let status_value = '1';
			let paramChecked = 'N';
            if(p_param_obj != undefined){
                p_param_obj.forEach(function(item){
					if(item.key == '시점' && item.value != "")  {
						if(item.value == '미래') status_value = '2';
						if(item.value == '과거') status_value = '3';
						paramChecked = 'Y';
					}
                });
            }
			if(ret_param == undefined ) { ret_param = [];}
			//console.check('ret_param : '+ret_param);
			if(paramChecked == 'N') {
				ret_param.forEach( el_1 => {
					sub_param = el_1.params;
					sub_param.forEach( el_2 => {
						if(el_2.key == '시점' && el_2.value != "")  {
							if(el_2.value == '미래') status_value = '2';
							if(el_2.value == '과거') status_value = '3';
						}
					});
				});
			}
			match_list.push( { "match": {  [ "itemStatusCd" ] : status_value } } );
			match_list.push( { "exists": {  [ "field" ] : "itemTitle" } } );

			if(status_value == '3') {
				req.query.size = 10;
			} else {
				req.query.size = 200;
			}

			let s_body =
			{
			  "size": req.query.size,
			  "query": {
				  "bool": {
					  "must": match_list
					  }
			  },
			  "_source":response_source
			}

            //console.error("[event_performance_work] s_body : " + JSON.stringify(s_body));

	        es.client1.search({
				index: "tr_event",
	            body: s_body
	        }).then(function (resp) {
	            s_result = resp.hits.hits;
				//console.warn('[event.js] EVENT TOTAL : ' + resp.hits.total);
	            return resolve();
	        }, function (err) {
				err.status = 400;
				res.status(400).send(util.res_err(req, 400, err.message));
				console.error(err.message,filename);
				return resolve();
			});
		});
	}

	await getEventData();

};

var event_ceremony_sendresult = async(req,res)=>{
	let getSendResult =()=>{
		return new Promise(function(resolve, reject){
			res.set({'Content-Type': 'text/json; charset=utf-8'});
			let messageObj =
			{
				id : "event_ceremony",
				name : "행사 목록 조회",
				description : "행사 목록 조회",
				request :request_set,
				mapping_info:response_set,
				response :
						{
							items:response_set
						},
				script: {
							type : "url",
							script_code: ""
				  		},
                add_parameter: add_parameter
			}

			if( req.query.condition != 'init' ) {
                let result = s_result;
				let response_item_set = {"items":[]};
				response_set.forEach(v_item=>{
					v_item.value = [];
				});

				let setData = (v_item,element)=>{
					let rs_item={};
					let req_lang =  "_"+req.query.lang;
					let v_field= util.replaceFieldToLang(v_item.field, req_lang);
					let set_value = "";
					for(let in_field in element){
						if(in_field == v_field){
							set_value = element[in_field];
						}
					}
					v_item.value.push(set_value);
				}
				result.forEach(element => {
					response_set.forEach((v_item)=>{
						setData(v_item,element._source);
					});
				});
			}

			res.send(messageObj);
			return resolve();
		});
	}
	await getSendResult();
};

//***********************************************************************************************************
//  Process Logic : 극장용 공연 조회
//***********************************************************************************************************
/* GET ceremony listing. */
router.get('/theater_yong', function(req, res) {
	event_theater_yong_handler(req, res);
});

/* POST ceremony listing. */
router.post('/theater_yong', function(req, res) {
	event_theater_yong_handler(req, res);
});


// -- promiss handler
var event_theater_yong_handler = function(req,res){
	util.req_param('[조회] 공연-극장용 전체',req,filename);

	elapsed = {};
	s_result = [];
	start = new Date();
	if(req.method == "POST") req.query = req.body;

	Promise
	.all([event_paramcheck(req,res)])
	.then(function(){return _promise_checktime('paramcheck');})
	.then(function(){return event_theater_yong_work(req,res);})
	.then(function(){return _promise_checktime('work');})
	.then(function(){return event_theater_yong_sendresult(req,res);})
	.catch(function(err){return _promise_errhandler(req,res,err);})
	;
};

var event_theater_yong_work = async(req,res)=>{

    let rs_obj = [];
	let lang = req.query.lang;
	let gubun = '공연';
	let location = '극장 용';
	if(lang == 'ja') lang = 'jp';

	//console.warn('[event_performance_work] lang : ' + lang);

	response_set.forEach(v_item=>{
		rs_obj.push( util.replaceFieldToLang(v_item.field, lang) );
	});

	let response_source = rs_obj;
	let getEventData = ()=>{
		return new Promise(function(resolve, reject){

            //전체 파라미터
            let p_param_obj = req.query.c_param;
			if( req.query.condition == 'init' ) {
				return resolve();
			}
            term_list = [];
			term_list.push( { "match": {  [ "gubun" ] : gubun } } );
			term_list.push( { "match": {  [ "itemLocation.keyword" ] : location } } );
			term_list.push( { "exists": {  [ "field" ] : "itemTitle" } } );
			/*
			if(p_param_obj != undefined){
                p_param_obj.forEach(function(item){
                });
            }
			*/

			let s_body =
			{
			  "size": req.query.size,
			  "query": {
				  "bool": {
					  "must": term_list
					  }
			  },
			  "_source":response_source
			}

            //console.warn("[event_performance_work] s_body : " + JSON.stringify(s_body));

	        es.client1.search({
				index: "tr_event",
	            body: s_body
	        }).then(function (resp) {
	            s_result = resp.hits.hits;
				//console.warn('[event.js] EVENT TOTAL : ' + resp.hits.total);
	            return resolve();
	        }, function (err) {
				err.status = 400;
				res.status(400).send(util.res_err(req, 400, err.message));
				console.error(err.message,filename);
				return resolve();
			});
		});
	}

	await getEventData();

};

var event_theater_yong_sendresult = async(req,res)=>{
	let getSendResult =()=>{
		return new Promise(function(resolve, reject){
			res.set({'Content-Type': 'text/json; charset=utf-8'});
			let messageObj =
			{
				id : "event_message",
				name : "극장용공연 목록 조회",
				description : "극장용공연 목록 조회",
				request :request_set,
				mapping_info:response_set,
				response :
						{
							items:response_set
						},
				script: {
							type : "url",
							script_code: ""
				  		},
                add_parameter: add_parameter
			}

			if( req.query.condition != 'init' ) {
                let result = s_result;
				let response_item_set = {"items":[]};
				response_set.forEach(v_item=>{
					v_item.value = [];
				});

				let setData = (v_item,element)=>{
					let rs_item={};
					let req_lang =  "_"+req.query.lang;
					let v_field= util.replaceFieldToLang(v_item.field, req_lang);
					let set_value = "";
					for(let in_field in element){
						if(in_field == v_field){
							set_value = element[in_field];
						}
					}
					v_item.value.push(set_value);
				}
				result.forEach(element => {
					response_set.forEach((v_item)=>{
						setData(v_item,element._source);
					});
				});
			}

			res.send(messageObj);
			return resolve();
		});
	}
	await getSendResult();
};


//***********************************************************************************************************
//  Process Logic : 교육 조회
//***********************************************************************************************************
/* GET education listing. */
router.get('/education', function(req, res) {
	event_education_handler(req, res);
});

/* POST education listing. */
router.post('/education', function(req, res) {
	event_education_handler(req, res);
});


// -- promiss handler
var event_education_handler = function(req,res){
	util.req_param('[조회] 교육 전체',req,filename);

	elapsed = {};
	s_result = [];
	start = new Date();
	if(req.method == "POST") req.query = req.body;

	Promise
	.all([event_paramcheck(req,res)])
	.then(function(){return _promise_checktime('paramcheck');})
	.then(function(){return event_education_work(req,res);})
	.then(function(){return _promise_checktime('work');})
	.then(function(){return event_education_sendresult(req,res);})
	.catch(function(err){return _promise_errhandler(req,res,err);})
	;
};

var event_education_work = async(req,res)=>{

    let rs_obj = [];
	let lang = req.query.lang;
	let gubun = '교육';
	if(lang == 'ja') lang = 'jp';

	//console.warn('[event_education_work] lang : ' + lang);

	response_set.forEach(v_item=>{
		rs_obj.push( util.replaceFieldToLang(v_item.field, lang) );
	});

	let response_source = rs_obj;
	let getEventData = ()=>{
		return new Promise(function(resolve, reject){

            //전체 파라미터
            let p_param_obj = req.query.c_param;
            let ret_param = req.query.sce_param;
			//console.error('ret_param =====> ' + JSON.stringify(ret_param));
			if( req.query.condition == 'init' ) {
				return resolve();
			}
            match_list = [];
			match_list.push( { "match": {  [ "gubun" ] : gubun } } );

			let status_value = 'open';

			if(p_param_obj != undefined){
				let paramChecked = 'N';
                p_param_obj.forEach(function(item){
					if(item.key == '접수상태' && item.value != "")  {
						if(item.value == '접수예정') status_value = 'soon';
						if(item.value == '접수마감') status_value = 'close';
						if(item.value == '그외') status_value = 'max';
						if(item.value == '접수불가') status_value = 'impossible';
						//console.error('item.key : ' + item.key + ' / paramChecked-11 : ' + paramChecked);
						paramChecked = 'Y';
						//console.error('item.key : ' + item.key + ' / paramChecked-22 : ' + paramChecked);
					}
                });

				if(paramChecked == 'N') {
					ret_param.forEach( el_1 => {
						sub_param = el_1.params;
						sub_param.forEach( el_2 => {
							if(el_2.key == '접수상태' && el_2.value != "")  {
								if(el_2.value == '접수예정') status_value = 'soon';
								if(el_2.value == '접수마감') status_value = 'close';
								if(el_2.value == '그외') status_value = 'max';
								if(el_2.value == '접수불가') status_value = 'impossible';
							}
						});
					});
				}
            }

			match_list.push( { "match": {  [ "itemStatusCd" ] : status_value } } );
			match_list.push( { "exists": {  [ "field" ] : "itemTitle" } } );

			if(status_value == 'close') {
				req.query.size = 10;
			} else {
				req.query.size = 200;
			}

			let s_body =
			{
			  "size": req.query.size,
			  "query": {
				  "bool": {
					  "must": match_list
					  }
			  },
			  "_source":response_source
			}
			//console.warn('[s_body] : ' + JSON.stringify(s_body));

	        es.client1.search({
				index: "tr_event",
	            body: s_body
	        }).then(function (resp) {
	            s_result = resp.hits.hits;
				//console.warn('[event.js] EVENT TOTAL : ' + resp.hits.total);
	            return resolve();
	        }, function (err) {
				err.status = 400;
				res.status(400).send(util.res_err(req, 400, err.message));
				console.error(err.message,filename);
				return resolve();
			});
		});
	}

	await getEventData();

};

var event_education_sendresult = async(req,res)=>{
	let getSendResult =()=>{
		return new Promise(function(resolve, reject){
			res.set({'Content-Type': 'text/json; charset=utf-8'});
			let messageObj =
			{
				id : "event_message",
				name : "교육 목록 조회",
				description : "교육 목록 조회",
				request :request_set,
				mapping_info:response_set,
				response :
						{
							items:response_set
						},
				script: {
							type : "url",
							script_code: ""
				  		},
                add_parameter: add_parameter
			}

			if( req.query.condition != 'init' ) {
                let result = s_result;
				let response_item_set = {"items":[]};
				response_set.forEach(v_item=>{
					v_item.value = [];
				});

				let setData = (v_item,element)=>{
					let rs_item={};
					let req_lang =  "_"+req.query.lang;
					let v_field= util.replaceFieldToLang(v_item.field, req_lang);
					let set_value = "";
					for(let in_field in element){
						if(in_field == v_field){
							set_value = element[in_field];
						}
					}
					v_item.value.push(set_value);
				}
				result.forEach(element => {
					response_set.forEach((v_item)=>{
						setData(v_item,element._source);
					});
				});
			}

			res.send(messageObj);
			return resolve();
		});
	}
	await getSendResult();
};



//***********************************************************************************************************
//  Process Logic : 특별전시 상세
//***********************************************************************************************************
/* GET users listing. */
router.get('/special_detail', function(req, res) {
	event_special_detail_handler(req, res);
});

/* POST users listing. */
router.post('/special_detail', function(req, res) {
	event_special_detail_handler(req, res);
});


// -- promiss handler
var event_special_detail_handler = function(req,res){
	util.req_param('[상세] 특별전시 상세',req,filename);


	elapsed = {};
	s_result = [];
	start = new Date();
	if(req.method == "POST") req.query = req.body;

	Promise
	.all([event_paramcheck(req,res)])
	.then(function(){return _promise_checktime('paramcheck');})
	.then(function(){return event_special_detail_work(req,res);})
	.then(function(){return _promise_checktime('work');})
	.then(function(){return event_special_detail_sendresult(req,res);})
	.catch(function(err){return _promise_errhandler(req,res,err);})
	;
};

var event_special_detail_work = async(req,res)=>{

    let rs_obj = [];
	let lang = req.query.lang;
	let gubun = '특별전시';
	if(lang == 'ja') lang = 'jp';

	//console.warn('[event_special_detail_work] lang : ' + lang);

	response_set.forEach(v_item=>{
		rs_obj.push( util.replaceFieldToLang(v_item.field, lang) );
	});

	let response_source = rs_obj;
	let getEventData = ()=>{
		return new Promise(function(resolve, reject){

            //전체 파라미터
            let p_param_obj = req.query.c_param;
            let ret_param = req.query.sce_param;
			if( req.query.condition == 'init' ) {
				return resolve();
			}
			// console.warn('ret_param : ' + JSON.stringify(ret_param));
            match_list = [];
			match_list.push( { "match": {  [ "lang" ] : lang } } );
			match_list.push( { "match": {  [ "gubun" ] : gubun } } );

			let status_value = 'current';
            if(p_param_obj != undefined){
				let paramChecked = 'N';
                p_param_obj.forEach(function(item){
					if(item.key == '시점' && item.value != "")  {
						if(item.value == '미래') status_value = 'upcomming';
						if(item.value == '과거') status_value = 'past';
						paramChecked = 'Y';
					}

					if(item.key == '특별전시명' && item.value != "")  {
						let item_title = item.value;
						// match_list.push( { "match": {  [ "itemTitle" ] : item_title } } );
						match_list.push( {
										  "simple_query_string": {
							              "query": item_title,
							              "fields": ["itemTitle"],
							              "default_operator": "AND"
							            } } );
					}
                });

				if(paramChecked == 'N') {
					ret_param.forEach( el_1 => {
						sub_param = el_1.params;
						sub_param.forEach( el_2 => {
							if(el_2.key == '시점' && el_2.value != "")  {
								if(el_2.value == '미래') status_value = 'upcomming';
								if(el_2.value == '과거') status_value = 'past';
							}
						});
					});
				}
            }

			if(ret_param.length > 1) {
				match_list.push( { "match": {  [ "itemStatusCd" ] : status_value } } );
			}
			match_list.push( { "exists": {  [ "field" ] : "itemTitle" } } );



			if(status_value == 'past') {
				req.query.size = 10;
			} else {
				req.query.size = 200;
			}

			let s_body =
			{
			  "size": req.query.size,
			  "query": {
				  "bool": {
					  "must": match_list
					  }
			  },
			  "_source":response_source
			}

            //console.warn("[event_special_detail_work] s_body => " + JSON.stringify(s_body,null,2));

	        es.client1.search({
				index: "tr_event",
	            body: s_body
	        }).then(function (resp) {
	            s_result = resp.hits.hits;
				//console.warn('[event.js] EVENT TOTAL : ' + resp.hits.total);
	            return resolve();
	        }, function (err) {
				err.status = 400;
				res.status(400).send(util.res_err(req, 400, err.message));
				console.error(err.message,filename);
				return resolve();
			});




		});
	}

	await getEventData();

};

var event_special_detail_sendresult = async(req,res)=>{
	let getSendResult =()=>{
		return new Promise(function(resolve, reject){
			res.set({'Content-Type': 'text/json; charset=utf-8'});
			let messageObj =
			{
				id : "event_message",
				name : "특별전시 상세 조회",
				description : "특별전시 상세 조회",
				request :request_set,
				mapping_info:response_set,
				response :
						{
							items:response_set
						},
				script: {
							type : "url",
							script_code: ""
				  		},
                add_parameter: add_parameter
			}

			if( req.query.condition != 'init' ) {
                let result = s_result;
				let response_item_set = {"items":[]};
				response_set.forEach(v_item=>{
					v_item.value = [];
				});

				let setData = (v_item,element)=>{
					let rs_item={};
					let req_lang =  "_"+req.query.lang;
					let v_field= util.replaceFieldToLang(v_item.field, req_lang);
					let set_value = "";
					for(let in_field in element){
						if(in_field == v_field){
							set_value = element[in_field];
						}
					}
					v_item.value.push(set_value);
				}
				result.forEach(element => {
					response_set.forEach((v_item)=>{
						setData(v_item,element._source);
					});
				});
			}

			res.send(messageObj);
			return resolve();
		});
	}
	await getSendResult();
};




//***********************************************************************************************************
//  Process Logic : 공연 상세
//***********************************************************************************************************
/* GET performance detail. */
router.get('/performance_detail', function(req, res) {
	event_performance_detail_handler(req, res);
});

/* POST performance detail. */
router.post('/performance_detail', function(req, res) {
	event_performance_detail_handler(req, res);
});


// -- promiss handler
var event_performance_detail_handler = function(req,res){
	util.req_param('[상세] 공연 상세',req,filename);

	elapsed = {};
	s_result = [];
	start = new Date();
	if(req.method == "POST") req.query = req.body;

	Promise
	.all([event_paramcheck(req,res)])
	.then(function(){return _promise_checktime('paramcheck');})
	.then(function(){return event_performance_detail_work(req,res);})
	.then(function(){return _promise_checktime('work');})
	.then(function(){return event_performance_detail_sendresult(req,res);})
	.catch(function(err){return _promise_errhandler(req,res,err);})
	;
};

var event_performance_detail_work = async(req,res)=>{

    let rs_obj = [];
	let lang = req.query.lang;
	let gubun = '공연';
	if(lang == 'ja') lang = 'jp';

	//console.warn('[event_performance_detail_work] lang : ' + lang);

	response_set.forEach(v_item=>{
		rs_obj.push( util.replaceFieldToLang(v_item.field, lang) );
	});

	console.trace(JSON.stringify(req.query.c_param,2,null));

	let response_source = rs_obj;
	let getEventData = ()=>{
		return new Promise(function(resolve, reject){

            //전체 파라미터
            let p_param_obj = req.query.c_param;
            let ret_param = req.query.sce_param;
			if( req.query.condition == 'init' ) {
				return resolve();
			}
			// console.warn('ret_param : ' + JSON.stringify(ret_param));
            match_list = [];
			match_list.push( { "match": {  [ "gubun" ] : gubun } } );

			let status_value = '1';
            if(p_param_obj != undefined){
				let paramChecked = 'N';
                p_param_obj.forEach(function(item){
					if(item.key == '시점' && item.value != "")  {
						if(item.value == '미래') status_value = '2';
						if(item.value == '과거') status_value = '3';
						paramChecked = 'Y';
					}

					if(item.key == '공연명' && item.value != "")  {
						let item_title = item.value;
						match_list.push( { "match": {  [ "itemTitle" ] : item_title } } );
					}
                });

				if(paramChecked == 'N') {
					ret_param.forEach( el_1 => {
						sub_param = el_1.params;
						sub_param.forEach( el_2 => {
							if(el_2.key == '시점' && el_2.value != "")  {
								if(el_2.value == '미래') status_value = '2';
								if(el_2.value == '과거') status_value = '3';
							}
						});
					});
				}
            }
			if(ret_param.length > 1) {
				match_list.push( { "match": {  [ "itemStatusCd" ] : status_value } } );
			}
			match_list.push( { "exists": {  [ "field" ] : "itemTitle" } } );

			let s_body =
			{
			  "size": 1,
			  "query": {
				  "bool": {
					  "must": match_list
					  }
			  },
			  "_source":response_source
			}

	        es.client1.search({
				index: "tr_event",
	            body: s_body
	        }).then(function (resp) {
	            s_result = resp.hits.hits;
				//console.warn('[event.js] EVENT TOTAL : ' + resp.hits.total);
	            return resolve();
	        }, function (err) {
				err.status = 400;
				res.status(400).send(util.res_err(req, 400, err.message));
				console.error(err.message,filename);
				return resolve();
			});
		});
	}

	await getEventData();

};

var event_performance_detail_sendresult = async(req,res)=>{
	let getSendResult =()=>{
		return new Promise(function(resolve, reject){
			res.set({'Content-Type': 'text/json; charset=utf-8'});
			let messageObj =
			{
				id : "event_message",
				name : "공연 상세 조회",
				description : "공연 상세 조회",
				request :request_set,
				mapping_info:response_set,
				response :
						{
							items:response_set
						},
				script: {
							type : "url",
							script_code: ""
				  		},
                add_parameter: add_parameter
			}

			if( req.query.condition != 'init' ) {
                let result = s_result;
				let response_item_set = {"items":[]};
				response_set.forEach(v_item=>{
					v_item.value = [];
				});

				let setData = (v_item,element)=>{
					let rs_item={};
					let req_lang =  "_"+req.query.lang;
					let v_field= util.replaceFieldToLang(v_item.field, req_lang);
					let set_value = "";
					for(let in_field in element){
						if(in_field == v_field){
							set_value = element[in_field];
						}
					}
					v_item.value.push(set_value);
				}
				result.forEach(element => {
					response_set.forEach((v_item)=>{
						setData(v_item,element._source);
					});
				});
			}

			res.send(messageObj);
			return resolve();
		});
	}
	await getSendResult();
};



//***********************************************************************************************************
//  Process Logic : 행사 상세
//***********************************************************************************************************
/* GET ceremony detail. */
router.get('/ceremony_detail', function(req, res) {
	event_ceremony_detail_handler(req, res);
});

/* POST ceremony detail. */
router.post('/ceremony_detail', function(req, res) {
	event_ceremony_detail_handler(req, res);
});


// -- promiss handler
var event_ceremony_detail_handler = function(req,res){
	util.req_param('[상세] 행사 상세',req,filename);

	elapsed = {};
	s_result = [];
	start = new Date();
	if(req.method == "POST") req.query = req.body;

	Promise
	.all([event_paramcheck(req,res)])
	.then(function(){return _promise_checktime('paramcheck');})
	.then(function(){return event_ceremony_detail_work(req,res);})
	.then(function(){return _promise_checktime('work');})
	.then(function(){return event_ceremony_detail_sendresult(req,res);})
	.catch(function(err){return _promise_errhandler(req,res,err);})
	;
};

var event_ceremony_detail_work = async(req,res)=>{

    let rs_obj = [];
	let lang = req.query.lang;
	let gubun = '행사';
	if(lang == 'ja') lang = 'jp';

	//console.warn('[event_performance_detail_work] lang : ' + lang);

	response_set.forEach(v_item=>{
		rs_obj.push( util.replaceFieldToLang(v_item.field, lang) );
	});

	let response_source = rs_obj;
	let getEventData = ()=>{
		return new Promise(function(resolve, reject){

            //전체 파라미터
            let p_param_obj = req.query.c_param;
            let ret_param = req.query.sce_param;
			if( req.query.condition == 'init' ) {
				return resolve();
			}
			// console.warn('ret_param : ' + JSON.stringify(ret_param));
            match_list = [];
			match_list.push( { "match": {  [ "gubun" ] : gubun } } );

			let status_value = '1';

            if(p_param_obj != undefined){
				let paramChecked = 'N';
                p_param_obj.forEach(function(item){
					if(item.key == '시점' && item.value != "")  {
						if(item.value == '미래') status_value = '2';
						if(item.value == '과거') status_value = '3';
						paramChecked = 'Y';
					}

					if(item.key == '행사명' && item.value != "")  {
						let item_title = item.value;
						match_list.push( { "match": {  [ "itemTitle" ] : item_title } } );
					}
                });

				if(paramChecked == 'N') {
					ret_param.forEach( el_1 => {
						sub_param = el_1.params;
						sub_param.forEach( el_2 => {
							if(el_2.key == '시점' && el_2.value != "")  {
								if(el_2.value == '미래') status_value = '2';
								if(el_2.value == '과거') status_value = '3';
							}
						});
					});
				}
		   }

		   if(ret_param.length > 1) {
			   match_list.push( { "match": {  [ "itemStatusCd" ] : status_value } } );
		   }

			match_list.push( { "exists": {  [ "field" ] : "itemTitle" } } );

			let s_body =
			{
			  "size": 1,
			  "query": {
				  "bool": {
					  "must": match_list
					  }
			  },
			  "_source":response_source
			}

            //console.warn("[event_ceremony_detail_work] s_body => " + JSON.stringify(s_body));

	        es.client1.search({
				index: "tr_event",
	            body: s_body
	        }).then(function (resp) {
	            s_result = resp.hits.hits;
				//console.warn('[event.js] EVENT TOTAL : ' + resp.hits.total);
	            return resolve();
	        }, function (err) {
				err.status = 400;
				res.status(400).send(util.res_err(req, 400, err.message));
				console.error(err.message,filename);
				return resolve();
			});
		});
	}

	await getEventData();

};

var event_ceremony_detail_sendresult = async(req,res)=>{
	let getSendResult =()=>{
		return new Promise(function(resolve, reject){
			res.set({'Content-Type': 'text/json; charset=utf-8'});
			let messageObj =
			{
				id : "event_ceremony",
				name : "행사 상세 조회",
				description : "행사 상세 조회",
				request :request_set,
				mapping_info:response_set,
				response :
						{
							items:response_set
						},
				script: {
							type : "url",
							script_code: ""
				  		},
                add_parameter: add_parameter
			}

			if( req.query.condition != 'init' ) {
                let result = s_result;
				let response_item_set = {"items":[]};
				response_set.forEach(v_item=>{
					v_item.value = [];
				});

				let setData = (v_item,element)=>{
					let rs_item={};
					let req_lang =  "_"+req.query.lang;
					let v_field= util.replaceFieldToLang(v_item.field, req_lang);
					let set_value = "";
					for(let in_field in element){
						if(in_field == v_field){
							set_value = element[in_field];
						}
					}
					v_item.value.push(set_value);
				}
				result.forEach(element => {
					response_set.forEach((v_item)=>{
						setData(v_item,element._source);
					});
				});
			}

			res.send(messageObj);
			return resolve();
		});
	}
	await getSendResult();
};



//***********************************************************************************************************
//  Process Logic : 교육 상세
//***********************************************************************************************************
/* GET education detail. */
router.get('/education_detail', function(req, res) {
	event_education_detail_handler(req, res);
});

/* POST education detail. */
router.post('/education_detail', function(req, res) {
	event_education_detail_handler(req, res);
});


// -- promiss handler
var event_education_detail_handler = function(req,res){
	util.req_param('[상세] 교육 상세',req,filename);

	elapsed = {};
	s_result = [];
	start = new Date();
	if(req.method == "POST") req.query = req.body;

	Promise
	.all([event_paramcheck(req,res)])
	.then(function(){return _promise_checktime('paramcheck');})
	.then(function(){return event_education_detail_work(req,res);})
	.then(function(){return _promise_checktime('work');})
	.then(function(){return event_education_detail_sendresult(req,res);})
	.catch(function(err){return _promise_errhandler(req,res,err);})
	;
};

var event_education_detail_work = async(req,res)=>{

    let rs_obj = [];
	let lang = req.query.lang;
	let gubun = '교육';
	if(lang == 'ja') lang = 'jp';

	//console.warn('[event_education_detail_work] lang : ' + lang);

	response_set.forEach(v_item=>{
		rs_obj.push( util.replaceFieldToLang(v_item.field, lang) );
	});

	let response_source = rs_obj;
	let getEventData = ()=>{
		return new Promise(function(resolve, reject){

            //전체 파라미터
            let p_param_obj = req.query.c_param;
            let ret_param = req.query.sce_param;
			if( req.query.condition == 'init' ) {
				return resolve();
			}
			// console.warn('ret_param : ' + JSON.stringify(ret_param));
            match_list = [];
			match_list.push( { "match": {  [ "gubun" ] : gubun } } );

			let status_value = 'open';

			if(p_param_obj != undefined){
				let paramChecked = 'N';
                p_param_obj.forEach(function(item){
					if(item.key == '접수상태' && item.value != "")  {
						if(item.value == '접수예정') status_value = 'soon';
						if(item.value == '접수마감') status_value = 'close';
						if(item.value == '그외') status_value = 'max';
						if(item.value == '접수불가') status_value = 'impossible';
						paramChecked = 'Y';
					}

					if(item.key == '교육명' && item.value != "")  {
						let item_title = item.value;
						match_list.push( { "match": {  [ "itemTitle" ] : item_title } } );
					}
                });

				if(paramChecked == 'N') {
					ret_param.forEach( el_1 => {
						sub_param = el_1.params;
						sub_param.forEach( el_2 => {
							if(el_2.key == '접수상태' && el_2.value != "")  {
								if(el_2.value == '접수예정') status_value = 'soon';
								if(el_2.value == '접수마감') status_value = 'close';
								if(el_2.value == '그외') status_value = 'max';
								if(el_2.value == '접수불가') status_value = 'impossible';
							}
						});
					});
				}
            }

			if(ret_param.length > 1) {
				match_list.push( { "match": {  [ "itemStatusCd" ] : status_value } } );
			}
			match_list.push( { "exists": {  [ "field" ] : "itemTitle" } } );

			let s_body =
			{
			  "size": 1,
			  "query": {
				  "bool": {
					  "must": match_list
					  }
			  },
			  "_source":response_source
			}

            //console.warn("[event_education_detail_work] s_body => " + JSON.stringify(s_body));

	        es.client1.search({
				index: "tr_event",
	            body: s_body
	        }).then(function (resp) {
	            s_result = resp.hits.hits;
				//console.warn('[event.js] EVENT TOTAL : ' + resp.hits.total);
	            return resolve();
	        }, function (err) {
				err.status = 400;
				res.status(400).send(util.res_err(req, 400, err.message));
				console.error(err.message,filename);
				return resolve();
			});
		});
	}

	await getEventData();

};

var event_education_detail_sendresult = async(req,res)=>{
	let getSendResult =()=>{
		return new Promise(function(resolve, reject){
			res.set({'Content-Type': 'text/json; charset=utf-8'});
			let messageObj =
			{
				id : "event_education",
				name : "교육 상세 조회",
				description : "교육 상세 조회",
				request :request_set,
				mapping_info:response_set,
				response :
						{
							items:response_set
						},
				script: {
							type : "url",
							script_code: ""
				  		},
                add_parameter: add_parameter
			}

			if( req.query.condition != 'init' ) {
                let result = s_result;
				let response_item_set = {"items":[]};
				response_set.forEach(v_item=>{
					v_item.value = [];
				});

				let setData = (v_item,element)=>{
					let rs_item={};
					let req_lang =  "_"+req.query.lang;
					let v_field= util.replaceFieldToLang(v_item.field, req_lang);
					let set_value = "";
					for(let in_field in element){
						if(in_field == v_field){
							set_value = element[in_field];
						}
					}
					v_item.value.push(set_value);
				}
				result.forEach(element => {
					response_set.forEach((v_item)=>{
						setData(v_item,element._source);
					});
				});
			}

			res.send(messageObj);
			return resolve();
		});
	}
	await getSendResult();
};



//***********************************************************************************************************
//  Process Logic Area (E)
//***********************************************************************************************************

var _promise_checktime = function(name){
	return new Promise(function(resolve, reject){
        // elapsed time
        end = new Date();
        elapsed[name] = (end - start) + ' ms';
        console.debug('_promise_checktime ! - '+name+' ['+elapsed[name]+']');
        return resolve();
    });
};

var _promise_errhandler = function(req,res,err){
	return new Promise(function(resolve, reject){
		if(typeof(err) != 'undefined'){
			console.error(err,filename);
		    //res.status(500).send(util.res_err(req, 500, err.message));

		    res.status(err.status || 500);
		    res.render('error', {
		    	message: err.message,
		    	error: err
		    });
		    return resolve();
		}else{
			return resolve();
		}
	});
};

module.exports = router;
