var express = require('express');
var router = express.Router();
var path = require('path');
var filename = path.basename(__filename);
var approot = require('app-root-path');
var util = require(approot + '/util/util');

// elapsed time
var elapsed = {};
var start, end;

var match_list = [];

// result
var v_result = [];
// elasticsearch
var es = require(approot + '/util/es');
var request_list = [];
var request_set = [
	{"name":"유물명","field":"title_ko","value":[],"type":"string"}
]
var response_set = [
	{"name":"박물관_카운트","field":"collectionDb","value":[],"type":"string"},
	{"name":"박물관","field":"collectionDb","value":[],"type":"string"}
]
var add_parameter = [];

//***********************************************************************************************************
//  Process Logic : 재질의 - 박물관정보 조회
//***********************************************************************************************************
/* GET users listing. */
router.get('/search', function(req, res) {
	info_relic_handler(req, res);
});

/* POST users listing. */
router.post('/prompt_culture_exhibit', function(req, res) {
	info_relic_handler(req, res);
});


// -- promiss handler
var info_relic_handler = function(req,res){
	util.req_param('[조회] els_search',req,filename);
    request_set = [
    	{"name":"유물명","field":"title_ko","value":[],"type":"string"}
    ]
    response_set = [
		{"name":"박물관_카운트","field":"collectionDb","value":[],"type":"string","code_data":"text"},
		{"name":"박물관","field":"collectionDb","value":[],"type":"string","code_data":"value"}
    ]

	elapsed = {};
	s_result = [];
	start = new Date();
	if(req.method == "POST") req.query = req.body;

	Promise
	.all([info_relic_paramcheck(req,res)])
	.then(function(){return _promise_checktime('paramcheck');})
	.then(function(){return info_relic_work(req,res);})
	.then(function(){return _promise_checktime('work');})
	.then(function(){return info_relic_sendresult(req,res);})
	.catch(function(err){return _promise_errhandler(req,res,err);})
	;
};

var info_relic_paramcheck = function(req,res){
	return new Promise(function(resolve, reject){
		var err = req.validationErrors();
		if(err) {
			err.status = 400;
			res.status(400).send(util.res_err(req, 400, err[0].msg));
			console.error(err[0].msg,filename);
			return reject();
		}else{
			req.query.value = req.query.value || "";
			req.query.field = req.query.field || "title_ko";
			req.query.size = req.query.size || 100;
			req.query.lang = req.query.lang || "ko";
			return resolve();
        }
	});
};

var info_relic_work = async(req,res)=>{
	var rs_obj = [];
	var getRelicData = ()=>{
		return new Promise(function(resolve, reject){

            match_list = [];

			var s_body =
			{
			  "size": req.query.size,
			  "query": {
				  "bool": {
					  "must": match_list
					  }
			  },
			  "_source":["title_ko","title_en"]
			}
	        es.client1.search({
				index: "tr_relic",
	            body: s_body
	        }).then(function (resp) {
	            v_result = resp.hits.hits;
	            return resolve();
	        }, function (err) {
				err.status = 400;
				res.status(400).send(util.res_err(req, 400, err.message));
				console.error(err.message,filename);
				return resolve();
			});
		});
	}

	await getRelicData();
};

var info_relic_sendresult = async(req,res)=>{
    return new Promise(function(resolve, reject){
        var messageObj = [];
        v_result.forEach((v_item)=>{
            var textArg = [];
            for(var in_val in v_item._source){
                textArg.push(v_item._source[in_val]);
            }
            messageObj.push(textArg);
        });
        res.set({'Content-Type': 'text/json; charset=utf-8'});
        res.send(messageObj);
        return resolve();
    });
};




//***********************************************************************************************************
//  Process Logic Area (E)
//***********************************************************************************************************

var _promise_checktime = function(name){
	return new Promise(function(resolve, reject){
        // elapsed time
        end = new Date();
        elapsed[name] = (end - start) + ' ms';
        console.debug('_promise_checktime ! - '+name+' ['+elapsed[name]+']');
        return resolve();
    });
};

var _promise_errhandler = function(req,res,err){
	return new Promise(function(resolve, reject){
		if(typeof(err) != 'undefined'){
			console.error(err,filename);
		    //res.status(500).send(util.res_err(req, 500, err.message));

		    res.status(err.status || 500);
		    res.render('error', {
		    	message: err.message,
		    	error: err
		    });
		    return resolve();
		}else{
			return resolve();
		}
	});
};

module.exports = router;
