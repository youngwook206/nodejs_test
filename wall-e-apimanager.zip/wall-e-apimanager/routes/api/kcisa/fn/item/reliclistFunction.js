var express = require('express');
var router = express.Router();
var path = require('path');
var filename = path.basename(__filename);
var approot = require('app-root-path');
var util = require(approot + '/util/util');

// elapsed time
var elapsed = {};
var start, end;

var match_list = [];

// result
var body = {};
var title_ = "";
var explain_ = "";
var audioURL_ = "";
// elasticsearch
var es = require(approot + '/util/es');
var request_list = [];
var response_set = [];
var request_set = [];
//var index_name = "tr_showroom";
var exhibit_index = "crawl-contents-exhibithall";
var showroom_index = "tr_showroom";
var relic_index = "tr_relic";
var reponse_type = "";
var locale = "ko";


//***********************************************************************************************************
//  Process Logic : 주요 유물 리스트
//***********************************************************************************************************
/* GET users listing. */
router.get('/', function(req, res) {
	reliclist_handler(req, res);
});

/* POST users listing. */
router.post('/', function(req, res) {
    reliclist_handler(req, res);
});

// -- promiss handler
var reliclist_handler = function(req,res){
	util.req_param('[조회] 주요 유물 리스트 정보',req,filename);
	elapsed = {};
	body = {};
	start = new Date();
	if(req.method == "POST") req.query = req.body;

	Promise
	.all([reliclist_paramcheck(req,res)])
	.then(function(){return _promise_checktime('paramcheck');})
	.then(function(){return reliclist_work(req,res);})
	.then(function(){return _promise_checktime('work');})
	.then(function(){return reliclist_sendresult(req,res);})
	.catch(function(err){return _promise_errhandler(req,res,err);});
};

var reliclist_paramcheck = function(req,res){
	return new Promise(function(resolve, reject){
		var err = req.validationErrors();
		if(err) {
			err.status = 400;
			res.status(400).send(util.res_err(req, 400, err[0].msg));
			console.error(err[0].msg,filename);
			return reject();
		}else{
			req.query.index_nm = req.query.index_nm || "tr_showroom";
			req.query.lang = req.query.lang || "ko";
			req.query.from = req.query.from || 0;
			req.query.size = req.query.size || 1;
			return resolve();
        }

	});
};

var reliclist_work = function(req,res){

	//param - elasticsearch 반영
	title_ = `title_${req.query.lang}`;
	explain_ = `explain_${req.query.lang}`;

	var index_name = "";

	request_set = [
		{"name":"전시실명","field":"title_ko","value":[],"type":"string"},
	]

	response_set = [
		{"name":"유물명","field":"title_ko","value":[],"type":"string","code_data":"text"},
		{"name":"유물이미지_URL","field":"relicImageURL","value":[],"type":"string","code_data":"img_url"},
		{"name":"유물질의","field":"title_ko","value":[],"type":"string","code_data":"value"}
	]


	var rs_obj = [];
	let req_lang = "_"+req.query.lang;

	response_set.forEach(v_item=>{
		rs_obj.push( util.replaceFieldToLang(v_item.field, req_lang) );
	});
	var response_source = rs_obj;

	return new Promise(function(resolve, reject){
		var param_obj = req.query;
		var req_obj = request_set[0];

        match_list = [];
        //prompt 일 경우. get exhibithall code
		var showroom_query = "";
		var showroom_fields = [];
        var v_param = param_obj.v_param;
        var c_param = param_obj.c_param

        if(v_param != undefined){
        	v_param.forEach((v_item) => {
				// console.debug(v_item.name+"______"+req_obj.name,"XXXXX");
        		if(v_item.name == req_obj.name){
                    showroom_fields.push(req_obj.field);
                    showroom_query = v_item.value
				}
			});
		}
        // if(c_param != undefined){
        	// c_param.forEach((c_item) => {
        	// 	var param_key = c_item.key;
        	// 	if(param_key.indexOf("전시실_") >= 0){
		// 			showroom_fields.push('title_ko');
		// 			showroom_query = c_item.value
		// 		}
		// 	});
		// }


		//일반 param - elasticsearch 반영
		if( req.query.condition == 'init' ) {
			return resolve();
		}else if( req.query.condition == 'result' ) {
		}

		var s_body = {
		  "size": req.query.size,
		  "query": {
              "bool": {
                  "must": [
                      {
                          "match": {
                              "displayYN": "Y"
                          }
                      },
                      {
                          "simple_query_string": {
                              "query": showroom_query,
                              "fields": showroom_fields
                          }
                      }
                  ]
              }
		  },
		  "_source":["title_ko","exhibitCode","showroomCode"]
		}

        es.client1.search({
			index: showroom_index,
            body: s_body
        }).then(function (resp) {
            body = resp;
            return resolve();
        }, function (err) {
			err.status = 400;
			res.status(400).send(util.res_err(req, 400, err.message));
			console.error(err.message,filename);
			return resolve();
		});
	});
};

var reliclist_sendresult  = async(req,res)=>{
	var field_arr = [];


    var getRelicList =()=>{

        var res_body = body.hits.hits;
        var domain_id = req.query.domain_id;
        var museumCode = "PS01001001";
        if(domain_id == "naju_nm") museumCode = "PS01001013";

		if(res_body.length > 0){
			var req_lang =  "_"+req.query.lang;
			var showroomCode = body.hits.hits[0]._source.showroomCode;
	    	var match_list = [];
	    	var body_query;

			if(showroomCode === "DM0008" || showroomCode == "DM0009"){
				body_query = {
                    "bool": {
                        "should": [
                            {
                                "bool": {
                                    "must": [
                                        {"match_phrase": {
                                            "showroomCode": "DM0008"
                                        }},
                                        {"match_phrase": {
                                            "displayYN": "Y"
                                        }},
                                        {"match_phrase": {
                                            "museumCode": museumCode
                                        }}
                                    ]
                                }
                            },
                            {
                                "bool": {
                                    "must": [
                                        {"match_phrase": {
                                            "showroomCode": "DM0009"
                                        }},
                                        {"match_phrase": {
                                            "displayYN": "Y"
                                        }},
                                        {"match_phrase": {
                                            "museumCode": museumCode
                                        }}
                                    ]
                                }
                            }
                        ]

                    }
                }


			}else if(showroomCode === "DM0004" || showroomCode === "DM0011"){
                body_query = {
                    "bool": {
                        "should": [
                            {
                                "bool": {
                                    "must": [
                                        {"match_phrase": {
                                            "showroomCode": "DM0004"
                                        }},
                                        {"match_phrase": {
                                            "displayYN": "Y"
                                        }},
                                        {"match_phrase": {
                                            "museumCode": museumCode
                                        }}
                                    ]
                                }
                            },
                            {
                                "bool": {
                                    "must": [
                                        {"match_phrase": {
                                            "showroomCode": "DM0011"
                                        }},
                                        {"match_phrase": {
                                            "displayYN": "Y"
                                        }},
                                        {"match_phrase": {
                                            "museumCode": museumCode
                                        }}
                                    ]
                                }
                            }
                        ]

                    }
                }

			}else{
                match_list.push( { "match_phrase": {  [ "displayYN"] : "Y"} } );
                if(showroomCode != ""){
                    match_list.push( { "match_phrase": {  [ "showroomCode"] : showroomCode} } );
                }
                if(museumCode != ""){
                    match_list.push( { "match_phrase": { ["museumCode"]: museumCode}} );
                }
                // 조회 조건 추가
                var explainField = util.replaceFieldToLang("explain_ko", req_lang) + ".keyword";
                var not_match_list = [
					{
						"match": {}
                    }
                ];
                not_match_list[0].match[explainField] = "";

				body_query = {
                    "bool": {
                        "must": match_list,
						"must_not": not_match_list
                    }
				};

			}

			var s_field = util.replaceFieldToLang("title_ko", req_lang);
	        var s_body = {
	            "size": 900,
	            "query": body_query,
	            "_source":[s_field,"relicImageURL","title_ko"]
	        };

	        return es.client1.search({
	            index: relic_index,
	            body: s_body
	        }).then(function (resp) {
				// console.log("respresprespresp:::",JSON.stringify(resp,null,2));
	            body = resp;
	        }, function (err) {
	            err.status = 400;
	            res.status(400).send(util.res_err(req, 400, err.message));
	            console.error(err.message,filename);
	        });
		}else{
			body = [];
		}
    }


	var getSendResult =()=>{
		return new Promise(function(resolve, reject){

			if(body.length == 0) req.query.condition = "init";
			res.set({'Content-Type': 'text/json; charset=utf-8'});
			var messageObj =
			{
				id : "api_tr_showroom_01",
				name : "전시실 주요 유물 정보",
				description : "전시실 주요 유물 정보 조회",
				request :request_set,
				mapping_info:response_set,
				response :
						{
							items:response_set
						},
				script: {
							type : "url",
							script_code: ""
				  		}
			}
			if( req.query.condition != 'init' ) {
				var result = body.hits.hits;
				var response_item_set = {"items":[]};

				response_set.forEach(v_item=>{
					v_item.value = [];
				});


				var setData = (v_item,element)=>{
					var rs_item={};
					var req_lang =  "_"+req.query.lang;
					var v_field= util.replaceFieldToLang(v_item.field, req_lang);
					var v_name = v_item.name;
					var set_value = "";
					for(var in_field in element){
						if(in_field === v_field){
							if(v_name === '유물질의'){
                                set_value = element["title_ko"] + "에 대해 알려주세요";
							}else{
                                set_value = element[in_field];
							}
						}
					}
					set_value = chkArrayImage(v_item.field,set_value);
					v_item.value.push(set_value);
				}
				result.forEach(element => {
					response_set.forEach((v_item)=>{
						setData(v_item,element._source);
					});
				});
			}



			res.send(messageObj);
			return resolve();
		});
	}

	if(req.query.condition == "init"){
        // await getShowroomField();
	}else{
        // await getDataField();
        await getRelicList();
    }
	await getSendResult();
};

//***********************************************************************************************************
//  Process Logic Area (E)
//***********************************************************************************************************

var chkArrayImage = (v_field,set_value)=>{
	var ret_val = set_value;
	if(v_field == "relicImageURL"){
		if(set_value!= undefined && set_value != null){
			if(set_value.indexOf(",")!=-1){
				ret_val = set_value.split(",")[0];
			}
		}
	}
	return ret_val;
}

var _promise_checktime = function(name){
	return new Promise(function(resolve, reject){
        // elapsed time
        end = new Date();
        elapsed[name] = (end - start) + ' ms';
        console.debug('_promise_checktime ! - '+name+' ['+elapsed[name]+']');
        return resolve();
    });
};

var _promise_errhandler = function(req,res,err){
	return new Promise(function(resolve, reject){
		if(typeof(err) != 'undefined'){
			console.error(err,filename);
		    //res.status(500).send(util.res_err(req, 500, err.message));

		    res.status(err.status || 500);
		    res.render('error', {
		    	message: err.message,
		    	error: err
		    });
		    return resolve();
		}else{
			return resolve();
		}
	});
};

module.exports = router;
