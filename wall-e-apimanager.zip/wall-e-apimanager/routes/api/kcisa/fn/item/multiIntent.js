var express = require('express');
var router = express.Router();
var path = require('path');
var filename = path.basename(__filename);
var approot = require('app-root-path');
var configfile = require(approot + '/config/config.json');
var config = require(approot + '/config/config');
var util = require(approot + '/util/util');
var es = require(approot + '/util/es');

// elapsed time
var elapsed = {};
var start, end;
var add_parameter = [];
var s_result = [];

var request_set = []
var response_set = []



//***********************************************************************************************************
//  Process Logic : 인텐트 조회
//***********************************************************************************************************
/* GET intent listing. */
router.get('/intent_search', function(req, res) {
	intent_search_handler(req, res);
});

/* POST intent listing. */
router.post('/intent_search', function(req, res) {
	intent_search_handler(req, res);
});


// -- promiss handler
var intent_search_handler = function(req,res){
	util.req_param('[조회] 인텐트 검색',req,filename);
	elapsed = {};
	s_result = [];
	start = new Date();
	if(req.method == "POST") req.query = req.body;

	Promise
	.all([intent_search_paramcheck(req,res)])
	.then(function(){return _promise_checktime('paramcheck');})

	.then(function(){return intent_search_work(req,res);})
	.then(function(){return _promise_checktime('not_matching');})

	.then(function(){return intent_search_sendresult(req,res);})
	.catch(function(err){return _promise_errhandler(req,res,err);})
	;
};


var intent_search_work = async(req,res)=>{
	console.error('[intent_search_work] query =====> ' + JSON.stringify(req.query));
	/*
	let teanaKmaData = {};
	var getKmaResult = ()=>{
		return new Promise(function(resolve, reject){

			console.log('[notMatch] getKmaResult - start');
	        let in_str = req.query.in_str;

	        let teanaCallUrl = 'http://'+config.teana_engine_host+'/kma';
	        console.debug("teanaCallUrl : "+teanaCallUrl+"?in="+in_str);
	        let request = require('request');
	        let urlencode = require('urlencode');

	        let options = {
	        		method: 'POST',
	                uri: teanaCallUrl,
	                body: 'in='+urlencode(in_str),
	                timeout : config.teana_timeout,
	        		headers: {
	        			'content-type': 'application/x-www-form-urlencoded'
	        		}
	        	};
	        request(options, function (error, response, body) {
	            if(error != null){
	                console.log("teanaCallUrl : "+teanaCallUrl+'?in='+in_str);
	                console.warn(error);
	            }else{
	                console.trace('statusCode : ' + response.statusCode);
	            }
	            if(error == null) {
					req.query.kmaData = JSON.parse(body);
					teanaKmaData = JSON.parse(body);
					// console.warn('kmaData : ' + body);
				}
	            return resolve();
	        });
			console.log('[notMatch] getKmaResult - end');
		});
	}

	var searchRelicIndex = ()=>{
        add_parameter = [];
		return new Promise(function(resolve, reject){
			console.log('searchRelicIndex - start');
			let posStr = "";
			posStr = teanaKmaData.query.pos;
			// console.warn('posStr : ' + posStr);

	        let s_index = "tr_relic";
	        let nngArr = getNngArray(posStr);
	        var should_list = [];
	        var must_list = [];

            var nng_str = "";
            nngArr.forEach(function(n_item){
                nng_str += n_item+"";
            });

            add_parameter.push({ key:'명사', value:nng_str,id:"","status":"","required":"N"});

	        nngArr.forEach( el=> {
	            should_list.push( { "wildcard" : { "title_ko" : `*${el}*` } } );
	        });
            must_list.push( {"match_phrase":{"displayYN":"Y"}});

            if(nngArr.length > 0){
                var s_body =
                {
    			  size: 0,
    			  query: {
    			    bool: {
    			      must: [
                          {
                              bool:{
                                  must:must_list
                              }
                          },
                          {
                              bool:{
                                  should:should_list
                              }
                          }
                        ]
                      }
    			  },
    			  aggs: {
    			    showroomName: {
    			      terms: {
    			        field: "showroomCode.keyword",
    			        size: 100
    			      }
    			    }
    			  }
    			}
				console.error('[searchRelicIndex] searchRelicIndex : ' + JSON.stringify(s_body));

    	        es.client1.search({
    	            index: s_index,
    	            body: s_body
    	        }).then(function (resp) {
    	           // console.warn('resp : ' + JSON.stringify(resp));
    			   req.query.trRelicData = resp;
    	           return resolve();
    	        });
            }else{
                req.query.trRelicData = [];
                return resolve();
            }

			console.log('searchRelicIndex - end');
		});
	}

    var searchShowroomIndex = ()=>{
		return new Promise(function(resolve, reject){
			console.log('searchRelicIndex - start');

	        let s_index = "tr_showroom";
	        var should_list = [];

			var s_body;
	        s_body =
			{
			  size: 1000,
			  _source: ["showroomCode","title_ko","title_en","title_ja","title_zh"]
			}
	        es.client1.search({
	            index: s_index,
	            body: s_body
	        }).then(function (resp) {
	           // console.warn('resp : ' + JSON.stringify(resp));
			   req.query.trShowroomData = resp;
	           return resolve();
	        });

			console.log('searchRelicIndex - end');
		});
	}

    var setRericData =()=>{
        var v_r_set = req.query.trRelicData;
        var v_s_set = req.query.trShowroomData;

        var v_r_data = [];
        var v_s_data = [];
        if(v_r_set != undefined){
            if(v_r_set.aggregations != undefined){
                v_r_data = v_r_set.aggregations.showroomName.buckets;
                v_s_data = v_s_set.hits.hits;
            }
        }

        var ret_exh_arr = [];
        if(v_s_data.length > 0){
            v_r_data.forEach((v_item)=>{
                var v_key = v_item.key;
                v_s_data.forEach((v_s_item)=>{
                    var vs_e_key = v_s_item._source.showroomCode;
                    if(v_key == vs_e_key) {
                        v_s_item._source["doc_count"] = v_item.doc_count;
                        ret_exh_arr.push(v_s_item._source);
                    }
                })
            });
        }

        req.query.trSetData = ret_exh_arr;
    }

	await getKmaResult(req);
	await searchRelicIndex(req);
	await searchShowroomIndex(req);
	await setRericData();

	function getNngArray(kma) {
		let returnArr = [];
		let tempArr = [];
		let subArr = [];
        if(kma!=undefined){
            tempArr = kma.split(' ');
    		tempArr.forEach( el => {
    			subArr = el.split('+');
    			subArr.forEach( s_el => {
    				if(s_el.indexOf('nng')>0) {
    					let retStr = s_el.split('/')[0];
    					returnArr.push( retStr );
    				}
    			})
    		});
        }

		return returnArr;
	}
	*/
}



var intent_search_paramcheck = function(req,res){
	return new Promise(function(resolve, reject){
		var err = req.validationErrors();
		if(err) {
			err.status = 400;
			res.status(400).send(util.res_err(req, 400, err[0].msg));
			console.error(err[0].msg,filename);
			return reject();
		}else{
			req.query.in_str = req.query.in_str || "";
			req.query.domainId = req.query.domainId || "";
			req.query.lang = req.query.lang || "";
			return resolve();
        }
	});
};

var intent_search_sendresult = async(req,res)=>{

    var response_set = [
        {"name":"실_ID","field":"showroomCode","value":[],"type":"string"},
        {"name":"실명","field":"title_ko","value":[],"type":"string"}
    ];
    var request_set = [];

    var getSendResult =()=>{
		return new Promise(function(resolve, reject){
			res.set({'Content-Type': 'text/json; charset=utf-8'});
			var messageObj =
			{
				id : "notmatching",
				name : "not matching",
				description : "not matching",
				request :request_set,
				mapping_info:response_set,
				response :
						{
							items:response_set
						},
				script: {
							type : "url",
							script_code: ""
				  		},
                add_parameter: add_parameter
			}

			if( req.query.condition != 'init' ) {
				var result = req.query.trSetData;
				var response_item_set = {"items":[]};
				response_set.forEach(v_item=>{
					v_item.value = [];
				});

				var setData = (v_item,element)=>{
					var rs_item={};
					var req_lang =  "_"+req.query.lang;
					var v_field= util.replaceFieldToLang(v_item.field, req_lang);
                    v_field = v_item.field;
					var set_value = "";
					for(var in_field in element){
						if(in_field == v_field){
							set_value = element[in_field];
						}
					}

					set_value = chkArrayImage(v_item.field,set_value);
					v_item.value.push(set_value);

				}
				result.forEach(element => {
                    response_set.forEach((v_item)=>{
						setData(v_item,element);
					});
				});
			}
			res.send(messageObj);
			return resolve();
		});
	}

	await getSendResult();
};








//***********************************************************************************************************
//  Process Logic Area (E)
//***********************************************************************************************************


var _promise_checktime = function(name){
	return new Promise(function(resolve, reject){
        // elapsed time
        end = new Date();
        elapsed[name] = (end - start) + ' ms';
        console.debug('_promise_checktime ! - '+name+' ['+elapsed[name]+']');
        return resolve();
    });
};

var _promise_errhandler = function(req,res,err){
	return new Promise(function(resolve, reject){
		if(typeof(err) != 'undefined'){
			console.error(err,filename);
		    //res.status(500).send(util.res_err(req, 500, err.message));

		    res.status(err.status || 500);
		    res.render('error', {
		    	message: err.message,
		    	error: err
		    });
		    return resolve();
		}else{
			return resolve();
		}
	});
};

module.exports = router;
