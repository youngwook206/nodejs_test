var express = require('express');
var router = express.Router();
var path = require('path');
var filename = path.basename(__filename);
var approot = require('app-root-path');
var util = require(approot + '/util/util');

// elapsed time
var elapsed = {};
var start, end;

var match_list = [];

// result
var body = {};
var title_ = "";
var explain_ = "";
var audioURL_ = "";
// elasticsearch
var es = require(approot + '/util/es');
var request_list = [];
var response_set = [];
var exhibit_index = "crawl-contents-exhibithall";
var showroom_index = "tr_showroom";
var relic_index = "tr_relic";
var reponse_type = "";
var exc


//***********************************************************************************************************
//  Process Logic : 주요 유물 리스트
//***********************************************************************************************************
/* GET users listing. */
router.get('/', function(req, res) {
	reliclist_handler(req, res);
});

/* POST users listing. */
router.post('/', function(req, res) {
    reliclist_handler(req, res);
});

// -- promiss handler
var reliclist_handler = function(req,res){
	util.req_param('[조회] 주요 유물 리스트 정보',req,filename);
	elapsed = {};
	body = {};
	start = new Date();
	if(req.method == "POST") req.query = req.body;

	Promise
	.all([reliclist_paramcheck(req,res)])
	.then(function(){return _promise_checktime('paramcheck');})
	.then(function(){return reliclist_work(req,res);})
	.then(function(){return _promise_checktime('work');})
	.then(function(){return reliclist_sendresult(req,res);})
	.catch(function(err){return _promise_errhandler(req,res,err);})
	;
};

var reliclist_paramcheck = function(req,res){
	return new Promise(function(resolve, reject){
		var err = req.validationErrors();
		if(err) {
			err.status = 400;
			res.status(400).send(util.res_err(req, 400, err[0].msg));
			console.error(err[0].msg,filename);
			return reject();
		}else{
			req.query.index_nm = req.query.index_nm || "tr_showroom";
			req.query.lang = req.query.lang || "ko";
			req.query.from = req.query.from || 0;
			req.query.size = req.query.size || 999;
			return resolve();
        }

	});
};

var reliclist_work = function(req,res){


	//param - elasticsearch 반영
	title_ = `title_${req.query.lang}`;
	explain_ = `explain_${req.query.lang}`;

	//return response field
	request_list = [{"type" : "string", "param_name":"전시실명", "field":title_, "desc":"전시실명"}];
	// request_list.push( {"type" : "string", "param_name":"박물관코드", "field":"exhibitCode", "desc":"박물관코드"} );
    response_set = [

        {
            "name": "전시관 버튼", "data": [
            {field: "title_ko", key: "text"}
            , {field: "exhibitCode", key: "value"}
        ]
            , type: "string", "value": []
        }
    ]

	var rs_obj = [];
	response_set.forEach(v_item=>{
		v_item.data.forEach(in_item=>{
			rs_obj.push(in_item.field);
		});
	});

	
	var response_source = rs_obj;
	return new Promise(function(resolve, reject){
		var param_obj = req.query;

        match_list = [];

        //일반 param - elasticsearch 반영
        if( req.query.condition == 'init' ) {
            return resolve();
        }else if( req.query.condition == 'result' ) {
        }

        var s_body = {
            "size": req.query.size,
            "query": {
                "bool": {
                    "must": match_list
                }
            },
            "_source":response_source
        }

        es.client1.search({
			index: exhibit_index,
            body: s_body
        }).then(function (resp) {
            body = resp;
            return resolve();
        }, function (err) {
			err.status = 400;
			res.status(400).send(util.res_err(req, 400, err.message));
			console.error(err.message,filename);
			return resolve();
		});
	});
};

var reliclist_sendresult  = async(req,res)=>{


	var field_arr = [];

    var getExhibitField =()=>{
        return es.client1.indices.getMapping({
            index: exhibit_index
        }).then(function (resp) {
            var map_info = resp[exhibit_index].mappings.contents.properties;
            for(var field in map_info){
                field_arr.push(field);
            }
        }, function (err) {
            err.status = 400;
            res.status(400).send(util.res_err(req, 400, err.message));
            console.error(err.message,filename);
        });
    }

	var getSendResult =()=>{
		return new Promise(function(resolve, reject){
			res.set({'Content-Type': 'text/json; charset=utf-8'});
			var messageObj =
			{
				id : "api_tr_showroom_01",
				name : "전시실 정보",
				description : "전시실 정보 조회",
				request :request_list,
				mapping_info:field_arr,
				response :
						{
							items:response_set
						},
				script: {
							type : "url",
							script_code: ""
				  		}
			}
			if( req.query.condition != 'init' ) {
				var result = body.hits.hits;
				var response_item_set = {"items":[]};

				response_set.forEach(v_item=>{
					v_item.value = [];
				});

				var setData = (v_item,element)=>{
					var rs_item={};
					v_item.data.forEach(in_item=>{
						var set_value = "";
						var v_field= in_item.field;
						for(var in_field in element){
							if(in_field == v_field){
								set_value = element[in_field];

                                var regExp = /[·・]/gi;
                                // var regExp = /[\{\}\[\]\/?.,·・;:|\)*~`!^\-_+<>@\#$%&\\\=\(\'\"]/gi
                                if(regExp.test(set_value)){
                                    set_value = set_value.replace(regExp, "")
                                }
							}
						}
						rs_item[in_item.key] = set_value;
					});
					v_item.value.push(rs_item);
				}
				result.forEach(element => {
					response_set.forEach((v_item)=>{
						setData(v_item,element._source);
					});
				});
			}
			res.send(messageObj);
			return resolve();
		});
	}
	await getExhibitField();
	await getSendResult();


};

//***********************************************************************************************************
//  Process Logic Area (E)
//***********************************************************************************************************

var _promise_checktime = function(name){
	return new Promise(function(resolve, reject){
        // elapsed time
        end = new Date();
        elapsed[name] = (end - start) + ' ms';
        console.debug('_promise_checktime ! - '+name+' ['+elapsed[name]+']');
        return resolve();
    });
};

var _promise_errhandler = function(req,res,err){
	return new Promise(function(resolve, reject){
		if(typeof(err) != 'undefined'){
			console.error(err,filename);
		    //res.status(500).send(util.res_err(req, 500, err.message));

		    res.status(err.status || 500);
		    res.render('error', {
		    	message: err.message,
		    	error: err
		    });
		    return resolve();
		}else{
			return resolve();
		}
	});
};

module.exports = router;
