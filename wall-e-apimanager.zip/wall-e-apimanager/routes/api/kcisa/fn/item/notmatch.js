var express = require('express');
var router = express.Router();
var path = require('path');
var filename = path.basename(__filename);
var approot = require('app-root-path');
var configfile = require(approot + '/config/config.json');
var config = require(approot + '/config/config');
var util = require(approot + '/util/util');
var es = require(approot + '/util/es');

// elapsed time
var elapsed = {};
var start, end;
var add_parameter = [];
var s_result = [];

var request_set = []
var response_set = []



//***********************************************************************************************************
//  Process Logic : 실명 조회
//***********************************************************************************************************
/* GET users listing. */
router.get('/kma_search', function(req, res) {
	kma_search_handler(req, res);
});

/* POST users listing. */
router.post('/kma_search', function(req, res) {
	kma_search_handler(req, res);
});


// -- promiss handler
var kma_search_handler = function(req,res){
	util.req_param('[조회] 형태소분석 검색',req,filename);
	elapsed = {};
	s_result = [];
	start = new Date();
	if(req.method == "POST") req.query = req.body;

	Promise
	.all([not_matching_paramcheck(req,res)])
	.then(function(){return _promise_checktime('paramcheck');})
	.then(function(){return not_matching_work(req,res);})
	.then(function(){return _promise_checktime('not_matching');})
	.then(function(){return not_matching_sendresult(req,res);})
	.catch(function(err){return _promise_errhandler(req,res,err);})
	;
};


var not_matching_work = async(req,res)=>{

	var domain_id = req.query.domain_id;
    let teanaKmaData = {};
    let lang = "_"+req.query.lang;
	var museumCode = "PS01001001";
	if(domain_id == "naju_nm") museumCode = "PS01001013";

	var getKmaResult = ()=>{
		return new Promise(function(resolve, reject){

			// console.log('[notMatch] getKmaResult - start');
	        let in_str = req.query.in_str;

	        let teanaCallUrl = 'http://'+config.teana_engine_host+'/kma';
	        console.debug("teanaCallUrl : "+teanaCallUrl+"?in="+in_str);
	        let request = require('request');
	        let urlencode = require('urlencode');

	        let options = {
	        		method: 'POST',
	                uri: teanaCallUrl,
	                body: 'in='+urlencode(in_str),
	                timeout : config.teana_timeout,
	        		headers: {
	        			'content-type': 'application/x-www-form-urlencoded'
	        		}
	        	};
	        request(options, function (error, response, body) {
	            if(error != null){
	                // console.log("teanaCallUrl : "+teanaCallUrl+'?in='+in_str);
	                console.warn(error);
	            }else{
	                console.trace('statusCode : ' + response.statusCode);
	            }
	            if(error == null) {
					req.query.kmaData = JSON.parse(body);
					teanaKmaData = JSON.parse(body);
					// console.warn('kmaData : ' + body);
				}
	            return resolve();
	        });
			// console.log('[notMatch] getKmaResult - end');
		});
	}

	var searchRelicIndex = ()=>{
        add_parameter = [];
		return new Promise(function(resolve, reject){
			// console.log('searchRelicIndex - start');
			let posStr = "";
			posStr = teanaKmaData.query.pos;
			// console.warn('posStr : ' + posStr);

	        let s_index = "tr_relic";
	        let nngArr = getNngArray(posStr);
	        var should_list = [];
	        var must_list = [];

            var nng_str = "";
            nngArr.forEach(function(n_item){
                nng_str += n_item+" ";
            });
			nng_str = nng_str.trim();
            add_parameter.push({ key:'명사', value:nng_str,id:"","status":"","required":"N"});
			var set_str = "";
	        nngArr.forEach( el=> {
				set_str += " "+el;
	        });
			if(set_str != "") set_str = set_str.trim();

            must_list.push( {"match_phrase":{"displayYN":"Y"}});
            must_list.push(  {"match_phrase":{"museumCode": museumCode}}  );
            must_list.push(
					{
						"query_string": {
							"default_field": "title_ko.korean",
							"query": set_str
						}
					}
                );

            // 조회 조건 추가
            var explainField = util.replaceFieldToLang("explain_ko", lang) + ".keyword";
            var not_match_list = [
                {
                    "match": {}
                }
            ];
            not_match_list[0].match[explainField] = "";

            if(nngArr.length > 0){
                var s_body =
				{
				  "size": 0,
				  "query": {
				    "bool": {
				      "must": must_list,
					  "must_not": not_match_list
				    }
				  },
				  "aggs": {
				    "showroomName": {
				      "terms": {
				        "field": "showroomCode.keyword",
				        "size": 100
				      }
				    }
				  }
				};
				// console.log("must_listmust_listmust_listmust_listmust_listmust_listmust_list::::::::",JSON.stringify(s_body,null,2));

    	        es.client1.search({
    	            index: s_index,
    	            body: s_body
    	        }).then(function (resp) {
    	           // console.warn('resp : ' + JSON.stringify(resp));
    			   req.query.trRelicData = resp;
    	           return resolve();
    	        });
            }else{
                req.query.trRelicData = [];
                return resolve();
            }

			// console.log('searchRelicIndex - end');
		});
	};

    var searchShowroomIndex = ()=>{
		return new Promise(function(resolve, reject){
			// console.log('searchRelicIndex - start');

	        let s_index = "tr_showroom";
	        var should_list = [];

			var s_body;
	        s_body =
			{
			  size: 1000,
			  query: {
			      term: {
			        "museumCode.keyword": { value: museumCode}
			      }
			    },
			  _source: ["showroomCode","title_ko","title_en","title_ja","title_zh"]
			}

			// console.check('s_body : ' + JSON.stringify(s_body));
	        es.client1.search({
	            index: s_index,
	            body: s_body
	        }).then(function (resp) {
	           // console.warn('resp : ' + JSON.stringify(resp));
			   req.query.trShowroomData = resp;
	           return resolve();
	        });

			// console.log('searchRelicIndex - end');
		});
	};

    var setRericData =()=>{
        var v_r_set = req.query.trRelicData;
        var v_s_set = req.query.trShowroomData;

        var v_r_data = [];
        var v_s_data = [];
        if(v_r_set != undefined){
            if(v_r_set.aggregations != undefined){
                v_r_data = v_r_set.aggregations.showroomName.buckets;
                v_s_data = v_s_set.hits.hits;
            }
        }

        var ret_exh_arr = [];
        if(v_s_data.length > 0){
            v_r_data.forEach((v_item)=>{
                var v_key = v_item.key;
                v_s_data.forEach((v_s_item)=>{
                    var vs_e_key = v_s_item._source.showroomCode;
                    if(v_key == vs_e_key) {
                        v_s_item._source["doc_count"] = v_item.doc_count;
                        ret_exh_arr.push(v_s_item._source);
                    }
                })
            });
        }

        req.query.trSetData = ret_exh_arr;
    };

	await getKmaResult(req);
	await searchRelicIndex(req);
	await searchShowroomIndex(req);
	await setRericData();

	function getNngArray(kma) {
		let returnArr = [];
		let tempArr = [];
		let subArr = [];
        if(kma!=undefined){
            tempArr = kma.split(' ');
    		tempArr.forEach( el => {
    			subArr = el.split('+');
    			subArr.forEach( s_el => {
    				if(s_el.indexOf('nn')>0) {
    					let retStr = s_el.split('/')[0];
    					returnArr.push( retStr );
    				}
    			})
    		});
        }
		return returnArr;
	}
}

var not_matching_paramcheck = function(req,res){
	return new Promise(function(resolve, reject){
		var err = req.validationErrors();
		if(err) {
			err.status = 400;
			res.status(400).send(util.res_err(req, 400, err[0].msg));
			console.error(err[0].msg,filename);
			return reject();
		}else{
			req.query.in_str = req.query.in_str || "";
			req.query.domainId = req.query.domainId || "";
			req.query.lang = req.query.lang || "";
			return resolve();
        }
	});
};

var not_matching_sendresult = async(req,res)=>{

    var response_set = [
        {"name":"실_ID","field":"showroomCode","value":[],"type":"string"},
        {"name":"실명","field":"title_ko","value":[],"type":"string"},
        {"name":"실명_VAL","field":"title_ko","value":[],"type":"string"}
    ];



    var request_set = [];

    var getSendResult =()=>{
		return new Promise(function(resolve, reject){
			res.set({'Content-Type': 'text/json; charset=utf-8'});
			var messageObj =
			{
				id : "notmatching",
				name : "not matching",
				description : "not matching",
				request :request_set,
				mapping_info:response_set,
				response :
						{
							items:response_set
						},
				script: {
							type : "url",
							script_code: ""
				  		},
                add_parameter: add_parameter
			}

			if( req.query.condition != 'init' ) {
				var result = req.query.trSetData;
				var response_item_set = {"items":[]};
				response_set.forEach(v_item=>{
					v_item.value = [];
				});

				var setData = (v_item,element)=>{
					var rs_item={};
					var req_lang =  "_"+req.query.lang;

					var v_field = v_item.field;
					if(v_item.name != "실명_VAL"){
						v_field= util.replaceFieldToLang(v_item.field, req_lang);
					}
					var set_value = "";
					for(var in_field in element){
						if(in_field == v_field){
							set_value = element[in_field];
						}
					}
					set_value = chkArrayImage(v_item.field,set_value);
					// console.log("set_valueset_valueset_value",set_value);
					v_item.value.push(set_value);
				}

				result.forEach(element => {
                    response_set.forEach((v_item)=>{
						setData(v_item,element);
					});
				});
			}
			res.send(messageObj);
			return resolve();
		});
	}

	await getSendResult();
};






//***********************************************************************************************************
//  Process Logic : KMA 유물조회
//***********************************************************************************************************
// /* GET users listing. */
// router.get('/kma_relic_search', function(req, res) {
// 	kma_relic_search_handler(req, res);
// });
//
// /* POST users listing. */
// router.post('/kma_relic_search', function(req, res) {
// 	kma_relic_search_handler(req, res);
// });
//
//
// // -- promiss handler
// var kma_relic_search_handler = function(req,res){
// 	util.req_param('[조회] 형태소분석 유물 검색',req,filename);
// 	elapsed = {};
// 	s_result = [];
// 	start = new Date();
// 	if(req.method == "POST") req.query = req.body;
//
// 	Promise
// 	.all([kma_relic_paramcheck(req,res)])
// 	.then(function(){return _promise_checktime('paramcheck');})
// 	.then(function(){return kma_relic_work(req,res);})
// 	.then(function(){return _promise_checktime('not_matching');})
//
// 	.then(function(){return kma_relic_sendresult(req,res);})
// 	.catch(function(err){return _promise_errhandler(req,res,err);})
// 	;
// };
//
//
// var kma_relic_work = async(req,res)=>{
//
// 	let teanaKmaData = {};
// 	var domain_id = req.query.domain_id;
// 	var museumCode = "PS01001001";
// 	if(domain_id == "naju_nm") museumCode = "PS01001013";
//
// 	var getKmaResult = ()=>{
// 		return new Promise(function(resolve, reject){
//
// 	        let in_str = req.query.in_str;
// 	        let teanaCallUrl = 'http://'+config.teana_engine_host+'/kma';
// 	        console.debug("teanaCallUrl : "+teanaCallUrl+"?in="+in_str);
// 	        let request = require('request');
// 	        let urlencode = require('urlencode');
//
// 	        let options = {
// 	        		method: 'POST',
// 	                uri: teanaCallUrl,
// 	                body: 'in='+urlencode(in_str),
// 	                timeout : config.teana_timeout,
// 	        		headers: {
// 	        			'content-type': 'application/x-www-form-urlencoded'
// 	        		}
// 	        	};
// 	        request(options, function (error, response, body) {
// 	            if(error != null){
// 	                console.warn(error);
// 	            }else{
// 	                console.trace('statusCode : ' + response.statusCode);
// 	            }
// 	            if(error == null) {
// 					req.query.kmaData = JSON.parse(body);
// 					teanaKmaData = JSON.parse(body);
// 				}
// 	            return resolve();
// 	        });
// 			// console.log('[notMatch] getKmaResult - end');
// 		});
// 	}
//
// 	var domain_id = req.query.domain_id;
// 	var museumCode = {"museumCode": "PS01001001"};
// 	if(domain_id == "naju_nm") museumCode = {"museumCode": "PS01001013"};
//
//     request_set = [
//         {"name":"유물명","field":"title_ko","value":[],"type":"string"},
//         {"name":"전시관코드","field":"exhibitCode","value":[],"type":"string"}
//     ]
//     response_set = [
//         {"name":"유물명","field":"title_ko","value":[],"type":"string"},
//         {"name":"전시관코드","field":"exhibitCode","value":[],"type":"string"},
//         {"name":"전시실코드","field":"showroomCode","value":[],"type":"string"},
//         {"name":"유물설명","field":"explain_ko","value":[],"type":"string"},
//         {"name":"음성_URL","field":"audioURL_en","value":[],"type":"string"},
//         {"name":"유물이미지_URL","field":"relicImageURL","value":[],"type":"string"},
//         {"name":"전시관명","field":"showroomName","value":[],"type":"string"},
//         {"name":"층","field":"floorNum","value":[],"type":"string"},
//         {"name":"유물코드","field":"relicCode","value":[],"type":"string"}
//     ]
//
// 	var searchRelicIndex = ()=>{
//         add_parameter = [];
// 		return new Promise(function(resolve, reject){
// 			// console.log('searchRelicIndex - start');
// 			let posStr = "";
// 			posStr = teanaKmaData.query.pos;
// 			// console.warn('posStr : ' + posStr);
//
// 	        let s_index = "tr_relic";
//
//
// 	        let nngArr = getNngArray(posStr);
// 	        var should_list = [];
// 	        var must_list = [];
//
//             var nng_str = "";
//             nngArr.forEach(function(n_item){
//                 nng_str += n_item+" ";
//             });
// 			nng_str = nng_str.trim();
//             add_parameter.push({ key:'명사', value:nng_str,id:"","status":"","required":"N"});
//
//
//
//             var set_str = "";
//             nngArr.forEach( el=> {
//                 set_str += " "+el;
//             });
//             if(set_str != "") set_str = set_str.trim();
//
//             must_list.push( {"match_phrase":{"displayYN":"Y"}});
//             must_list.push(  {"match_phrase":{"museumCode": museumCode}}  );
//             must_list.push(
//                 {
//                     "query_string": {
//                         "default_field": "title_ko.korean",
//                         "query": set_str
//                     }
//                 }
//             );
//
//             // 조회 조건 추가
//             var explainField = util.replaceFieldToLang("explain_ko", lang) + ".keyword";
//             var not_match_list = [
//                 {
//                     "match": {}
//                 }
//             ];
//             not_match_list[0].match[explainField] = "";
//
//
//             var s_body =
// 			{
// 			  size: 100,
// 			  query: {
// 			    bool: {
// 			      must: [
//                       {
//                           bool:{
//                               must:must_list,
//                               must_not: not_match_list
//                           }
//                       }
//                     ]
//                   }
// 			  }
// 			};
//
// 			console.log("[유물정보(목록)_ 조회]==============>>>",JSON.stringify(s_body,null,2));
// 			console.log("s_bodys_bodys_bodys_bodys_bodys_body::xxx::::::", JSON.stringify(s_body,null,2));
// 	        es.client1.search({
// 	            index: s_index,
// 	            body: s_body
// 	        }).then(function (resp) {
// 	           // console.warn('resp : ' + JSON.stringify(resp));
// 			   s_result = resp;
// 	           return resolve();
// 	        });
// 			// console.log('searchRelicIndex - end');
// 		});
// 	}
// 	await getKmaResult(req);
// 	await searchRelicIndex(req);
//
// 	function getNngArray(kma) {
// 		let returnArr = [];
// 		let tempArr = [];
// 		let subArr = [];
//         if(kma!=undefined){
//             tempArr = kma.split(' ');
//     		tempArr.forEach( el => {
//     			subArr = el.split('+');
//     			subArr.forEach( s_el => {
//     				if(s_el.indexOf('nn')>0) {
//     					let retStr = s_el.split('/')[0];
//     					returnArr.push( retStr );
//     				}
//     			})
//     		});
//         }
//
// 		return returnArr;
// 	}
// }
//
// var kma_relic_paramcheck = function(req,res){
// 	return new Promise(function(resolve, reject){
// 		var err = req.validationErrors();
// 		if(err) {
// 			err.status = 400;
// 			res.status(400).send(util.res_err(req, 400, err[0].msg));
// 			console.error(err[0].msg,filename);
// 			return reject();
// 		}else{
// 			req.query.in_str = req.query.in_str || "";
// 			req.query.domainId = req.query.domainId || "";
// 			req.query.lang = req.query.lang || "";
// 			return resolve();
//         }
// 	});
// };
//
// var kma_relic_sendresult = async(req,res)=>{
//
// 	request_set = [
// 		{"name":"유물명","field":"title_ko","value":[],"type":"string"},
// 		{"name":"전시관코드","field":"exhibitCode","value":[],"type":"string"}
// 	]
// 	response_set = [
// 		{"name":"유물명","field":"title_ko","value":[],"type":"string"},
// 		{"name":"전시관코드","field":"exhibitCode","value":[],"type":"string"},
// 		{"name":"전시실코드","field":"showroomCode","value":[],"type":"string"},
// 		{"name":"유물설명","field":"explain_ko","value":[],"type":"string"},
// 		{"name":"음성_URL","field":"audioURL_en","value":[],"type":"string"},
// 		{"name":"유물이미지_URL","field":"relicImageURL","value":[],"type":"string"},
// 		{"name":"전시관명","field":"showroomName","value":[],"type":"string"},
// 		{"name":"층","field":"floorNum","value":[],"type":"string"},
// 		{"name":"유물코드","field":"relicCode","value":[],"type":"string"}
// 	]
//
//     var getSendResult =()=>{
// 		return new Promise(function(resolve, reject){
// 			res.set({'Content-Type': 'text/json; charset=utf-8'});
// 			var messageObj =
// 			{
// 				id : "notmatching",
// 				name : "not matching",
// 				description : "not matching",
// 				request :request_set,
// 				mapping_info:response_set,
// 				response :
// 						{
// 							items:response_set
// 						},
// 				script: {
// 							type : "url",
// 							script_code: ""
// 				  		},
//                 add_parameter: add_parameter
// 			}
//
// 			if( req.query.condition != 'init' ) {
// 				var result = s_result.hits.hits;
// 				var response_item_set = {"items":[]};
// 				response_set.forEach(v_item=>{
// 					v_item.value = [];
// 				});
//
//                 var setData = (v_item,element)=>{
// 					var rs_item={};
// 					var req_lang =  "_"+req.query.lang;
//
// 					var v_field= util.replaceFieldToLang(v_item.field, req_lang);
//
//
// 					var set_value = "";
// 					for(var in_field in element){
// 						if(in_field == v_field){
// 							set_value = element[in_field];
// 						}
// 					}
//
// 					set_value = chkArrayImage(v_item.field,set_value);
// 					v_item.value.push(set_value);
// 				}
// 				result.forEach(element => {
// 					response_set.forEach((v_item)=>{
// 						setData(v_item,element._source);
// 					});
// 				});
// 			}
// 			res.send(messageObj);
// 			return resolve();
// 		});
// 	}
// 	await getSendResult();
// };








//***********************************************************************************************************
//  Process Logic : 유물정보(목록)_ 조회
//***********************************************************************************************************
/* GET users listing. */
router.get('/relicList_search', function(req, res) {
	n_relic_search_handler(req, res);
});

/* POST users listing. */
router.post('/relicList_search', function(req, res) {
	n_relic_search_handler(req, res);
});


// -- promiss handler
var n_relic_search_handler = function(req,res){
	util.req_param('[조회] 유물리스트 검색',req,filename);
	elapsed = {};
	s_result = [];
	start = new Date();
	if(req.method == "POST") req.query = req.body;

	Promise
	.all([n_relic_search_paramcheck(req,res)])
	.then(function(){return _promise_checktime('paramcheck');})

	.then(function(){return n_relic_search_work(req,res);})
	.then(function(){return _promise_checktime('not_matching');})

	.then(function(){return n_relic_search_sendresult(req,res);})
	.catch(function(err){return _promise_errhandler(req,res,err);})
	;
};


var n_relic_search_work = async(req,res)=>{

	var domain_id = req.query.domain_id;
	var museumCode = {"museumCode": "PS01001001"};
	if(domain_id == "naju_nm") museumCode = {"museumCode": "PS01001013"};

    request_set = [
        {"name":"유물명","field":"title_ko","value":[],"type":"string"},
        {"name":"전시관코드","field":"exhibitCode","value":[],"type":"string"}
    ]
    response_set = [
        {"name":"유물명","field":"title_ko","value":[],"type":"string"},
        {"name":"전시관코드","field":"exhibitCode","value":[],"type":"string"},
        {"name":"전시실코드","field":"showroomCode","value":[],"type":"string"},
        {"name":"유물설명","field":"explain_ko","value":[],"type":"string"},
        {"name":"음성_URL","field":"audioURL_en","value":[],"type":"string"},
        {"name":"유물이미지_URL","field":"relicImageURL","value":[],"type":"string"},
        {"name":"전시관명","field":"showroomName","value":[],"type":"string"},
        {"name":"층","field":"floorNum","value":[],"type":"string"},
        {"name":"유물코드","field":"relicCode","value":[],"type":"string"}
    ]

	var searchRelicIndex = ()=>{
        add_parameter = [];
		return new Promise(function(resolve, reject){
			// console.log('searchRelicIndex - start');

            var rs_obj = [];
        	let lang = "_"+req.query.lang;
        	response_set.forEach(v_item=>{
        		// rs_obj.push(v_item.field );
        		rs_obj.push( util.replaceFieldToLang(v_item.field, lang) );
        	});
        	var response_source = rs_obj;

	        let s_index = "tr_relic";
            let set_str = "";
            var ret_param = req.query.sce_param;
			console.error('[notmatch.js] ret_param : ' + JSON.stringify(ret_param));

            if(ret_param!=undefined){
                ret_param.forEach((sce_item)=>{
                    if(sce_item.step == 0){
                        sce_item.params.forEach((s_item)=>{
                            if(s_item.key == "명사") set_str = s_item.value;
                        });
                    }
                });
            }
            if(set_str != "") set_str = set_str.trim();
			console.error('[notmatch.js] set_str : ' + set_str);

	        var must_list = [];


            must_list.push( {"match_phrase":{"displayYN":"Y"}});
            must_list.push(  {"match_phrase":museumCode}  );
            must_list.push(
                {
                    "query_string": {
                        "default_field": "title_ko.korean",
                        "query": set_str
                    }
                }
            );

            var p_param_obj = req.query.c_param;
            if(p_param_obj!=undefined){
                p_param_obj.forEach((p_item)=>{
                    if(p_item.key == "전시실_코드") must_list.push( { "match_phrase" : { "showroomCode" : p_item.value } } );
                });
            }


            // 조회 조건 추가
            var explainField = util.replaceFieldToLang("explain_ko", lang) + ".keyword";
            var not_match_list = [
                {
                    "match": {}
                }
            ];
            not_match_list[0].match[explainField] = "";


            var s_body =
            {
			  size: 100,
			  query: {
			    bool: {
			      must: must_list,
                  must_not: not_match_list
				}
			  }
			};

			// console.log("[유물정보(목록)_ 조회]==============>>>",JSON.stringify(s_body,null,2));
			// console.log("s_bodys_bodys_bodys_bodys_bodys_body::xxx::::::", JSON.stringify(s_body,null,2));
	        es.client1.search({
	            index: s_index,
	            body: s_body
	        }).then(function (resp) {
	           // console.warn('resp : ' + JSON.stringify(resp));
			   s_result = resp;
	           return resolve();
	        });
			// console.log('searchRelicIndex - end');
		});
	}
	await searchRelicIndex(req);
}


var n_relic_search_paramcheck = function(req,res){
	return new Promise(function(resolve, reject){
		var err = req.validationErrors();
		if(err) {
			err.status = 400;
			res.status(400).send(util.res_err(req, 400, err[0].msg));
			console.error(err[0].msg,filename);
			return reject();
		}else{
			req.query.in_str = req.query.in_str || "";
			req.query.domainId = req.query.domainId || "";
			req.query.lang = req.query.lang || "";
			return resolve();
        }
	});
};

var n_relic_search_sendresult = async(req,res)=>{

    var getSendResult =()=>{
		return new Promise(function(resolve, reject){
			res.set({'Content-Type': 'text/json; charset=utf-8'});
			var messageObj =
			{
				id : "notmatching",
				name : "not matching",
				description : "not matching",
				request :request_set,
				mapping_info:response_set,
				response :
						{
							items:response_set
						},
				script: {
							type : "url",
							script_code: ""
				  		},
                add_parameter: add_parameter
			}

			if( req.query.condition != 'init' ) {


				var result = s_result.hits.hits;
				var response_item_set = {"items":[]};
				response_set.forEach(v_item=>{
					v_item.value = [];
				});

                var setData = (v_item,element)=>{
					var rs_item={};
					var req_lang =  "_"+req.query.lang;
					var v_field= util.replaceFieldToLang(v_item.field, req_lang);
					var set_value = "";
					for(var in_field in element){
						if(in_field == v_field){
							set_value = element[in_field];
						}
					}

					set_value = chkArrayImage(v_item.field,set_value);
					v_item.value.push(set_value);
				}
				result.forEach(element => {
					response_set.forEach((v_item)=>{
						setData(v_item,element._source);
					});
				});
			}

			res.send(messageObj);
			return resolve();
		});
	}
	await getSendResult();
};
















//***********************************************************************************************************
//  Process Logic Area (E)
//***********************************************************************************************************

var chkArrayImage = (v_field,set_value)=>{
	var ret_val = set_value;
	if(v_field == "relicImageURL"){
		if(set_value!= undefined && set_value != null){
			if(set_value.indexOf(",")!=-1){
				ret_val = set_value.split(",")[0];
			}
		}
	}
	return ret_val;
}

var _promise_checktime = function(name){
	return new Promise(function(resolve, reject){
        // elapsed time
        end = new Date();
        elapsed[name] = (end - start) + ' ms';
        console.debug('_promise_checktime ! - '+name+' ['+elapsed[name]+']');
        return resolve();
    });
};

var _promise_errhandler = function(req,res,err){
	return new Promise(function(resolve, reject){
		if(typeof(err) != 'undefined'){
			console.error(err,filename);
		    //res.status(500).send(util.res_err(req, 500, err.message));

		    res.status(err.status || 500);
		    res.render('error', {
		    	message: err.message,
		    	error: err
		    });
		    return resolve();
		}else{
			return resolve();
		}
	});
};

module.exports = router;
