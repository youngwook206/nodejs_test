var express = require('express');
var router = express.Router();
var path = require('path');
var filename = path.basename(__filename);
var approot = require('app-root-path');
var util = require(approot + '/util/util');

// elapsed time
var elapsed = {};
var start, end;

var match_list = [];

// result
var s_result = [];
var title_ = "";
var explain_ = "";
var audioURL_ = "";
// elasticsearch
var es = require(approot + '/util/es');
var request_list = [];
var request_set = [
	{"name":"유물명","field":"title_ko","value":[],"type":"string"}
]
var response_set = [
	{"name":"박물관_카운트","field":"collectionDb","value":[],"type":"string"},
	{"name":"박물관","field":"collectionDb","value":[],"type":"string"}
]
var add_parameter = [];

//***********************************************************************************************************
//  Process Logic : 재질의 - 박물관정보 조회
//***********************************************************************************************************
/* GET users listing. */
router.get('/prompt_culture_exhibit', function(req, res) {
	info_relic_handler(req, res);
});

/* POST users listing. */
router.post('/prompt_culture_exhibit', function(req, res) {
	info_relic_handler(req, res);
});


// -- promiss handler
var info_relic_handler = function(req,res){
	util.req_param('[조회] 유물 목록',req,filename);

    request_set = [
    	{"name":"유물명","field":"title_ko","value":[],"type":"string"}
    ]
    response_set = [
		{"name":"박물관_카운트","field":"collectionDb","value":[],"type":"string","code_data":"text"},
		{"name":"박물관","field":"collectionDb","value":[],"type":"string","code_data":"value"}
    ]

	elapsed = {};
	s_result = [];
	start = new Date();
	if(req.method == "POST") req.query = req.body;

	Promise
	.all([info_relic_paramcheck(req,res)])
	.then(function(){return _promise_checktime('paramcheck');})
	.then(function(){return info_relic_work(req,res);})
	.then(function(){return _promise_checktime('work');})
	.then(function(){return info_relic_sendresult(req,res);})
	.catch(function(err){return _promise_errhandler(req,res,err);})
	;
};

var info_relic_paramcheck = function(req,res){
	return new Promise(function(resolve, reject){
		var err = req.validationErrors();
		if(err) {
			err.status = 400;
			res.status(400).send(util.res_err(req, 400, err[0].msg));
			console.error(err[0].msg,filename);
			return reject();
		}else{
			req.query.value = req.query.value || "";
			req.query.field = req.query.field || "title_ko";
			req.query.size = req.query.size || 1;
			req.query.lang = req.query.lang || "ko";
			return resolve();
        }
	});
};

var info_relic_work = async(req,res)=>{
	var rs_obj = [];
	let lang = "_"+req.query.lang;
	// response_set.forEach(v_item=>{
	// 	rs_obj.push( util.replaceFieldToLang(v_item.field, lang) );
	// });
    var tr_docent_relic_data;
	var response_source = rs_obj;
	var getRelicData = ()=>{
		return new Promise(function(resolve, reject){

            var param_obj = req.query.v_param;
            var p_param_obj = req.query.c_param;

			if( req.query.condition == 'init' ) {
				return resolve();
			}

            if(p_param_obj != undefined){
                p_param_obj.forEach(function(item){
                    if(item.key == '도슨트유물'){
                        match_list.push( { "match_phrase": {  [ "title_ko" ] : item.value } } );
                    }
                });
            }
            match_list = [];

			var s_body =
			{
			  "size": req.query.size,
			  "query": {
				  "bool": {
					  "must": match_list
					  }
			  },
			  "_source":["title_ko","temporal","medium","spatial"]
			}

	        es.client1.search({
				index: "tr_docent_relic",
	            body: s_body
	        }).then(function (resp) {
	            tr_docent_relic_data = resp.hits.hits;
	            return resolve();
	        }, function (err) {
				err.status = 400;
				res.status(400).send(util.res_err(req, 400, err.message));
				console.error(err.message,filename);
				return resolve();
			});
		});
	}

	var getExhibitionData = async()=>{
		add_parameter = [];
        var getRespData =()=>{
			return new Promise(function(resolve, reject){
                if( req.query.condition == 'init' ) {
                    return resolve();
                }

                var relic_data = tr_docent_relic_data[0]._source;

                add_parameter.push({ key:'시대', value:relic_data.temporal,id:"temporal","status":"","required":"N"});
                add_parameter.push({ key:'재질', value:relic_data.medium,id:"medium","status":"","required":"N"});
                add_parameter.push({ key:'출토지', value:relic_data.spatial,id:"spatial","status":"","required":"N"});

                var s_match_list = [];
				s_match_list.push( { "match_phrase": { "temporal":relic_data.temporal } } );
				s_match_list.push( { "match_phrase": { "medium":relic_data.medium } } );
				s_match_list.push( { "match_phrase": { "spatial":relic_data.spatial } } );
				var s_body =
				{
				  "size": 1,
				  "query": {
					  "bool": {
						  "must": s_match_list
                          , "must_not": [
                               {"match_phrase" : { "collectionDb" : "이뮤지엄" }}
                             ]
						  }
				  },
                  "aggs": {
                    "collectionDb": {
                      "terms": {
                        "field": "collectionDb.keyword",
                        "size": 100
                      }
                    }
                  }
				}

		        es.client1.search({
					index: "tr_culture_relic",
		            body: s_body
		        }).then(function (resp) {
					var r_set = resp;
                    s_result = r_set.aggregations.collectionDb.buckets;
		            return resolve();
		        }, function (err) {
					err.status = 400;
					res.status(400).send(util.res_err(req, 400, err.message));
					console.error(err.message,filename);
					return resolve();
				});
			});
            return resolve();
		}
        await getRespData();
	}

	await getRelicData();
	await getExhibitionData();
};

var info_relic_sendresult = async(req,res)=>{
	var getSendResult =()=>{
		return new Promise(function(resolve, reject){
			res.set({'Content-Type': 'text/json; charset=utf-8'});
			var messageObj =
			{
				id : "res_message",
				name : "유물 조회",
				description : "유물값 조회",
				request :request_set,
				mapping_info:response_set,
				response :
						{
							items:response_set
						},
				script: {
							type : "url",
							script_code: ""
				  		},
                add_parameter: add_parameter
			}

			if( req.query.condition != 'init' ) {
				var result = s_result;
				var response_item_set = {"items":[]};
				response_set.forEach(v_item=>{
					v_item.value = [];
				});

				var setData = (v_item,element)=>{
					var rs_item={};
					var v_field= v_item.field
					var set_value = element.key;
					var set_v_count = element.doc_count;
					if(set_value.indexOf("DB")!=-1){
						set_value = set_value.replace("DB","");
					}

					if(v_item.name == "박물관_카운트"){
						v_item.value.push(set_value+"("+set_v_count+")");
					}else{
						v_item.value.push(set_value);
					}
				}

				result.forEach(element => {
					response_set.forEach((v_item)=>{
						setData(v_item,element);
					});
				});
			}

			res.send(messageObj);
			return resolve();
		});
	}
	await getSendResult();
};




//***********************************************************************************************************
//  Process Logic : 결과 - 박물관정보 내 유물조회
//***********************************************************************************************************
/* GET users listing. */
router.get('/culture_relic', function(req, res) {
	culture_relic_handler(req, res);
});

/* POST users listing. */
router.post('/culture_relic', function(req, res) {
	culture_relic_handler(req, res);
});


// -- promiss handler
var culture_relic_handler = function(req,res){
	util.req_param('[조회] 유물 목록',req,filename);
    request_set = [
    	{"name":"재질","field":"medium","value":[],"type":"string"},
    	{"name":"시대","field":"temporal","value":[],"type":"string"},
    	{"name":"출토지","field":"spatial","value":[],"type":"string"},
    	{"name":"박물관","field":"collectionDb","value":[],"type":"string"},
    ]
    response_set = [
    	{"name":"이미지","field":"referenceIdentifier","value":[],"type":"string"},
    	{"name":"제목","field":"title","value":[],"type":"string"},
    	{"name":"제목_alter","field":"alternativeTitle","value":[],"type":"string"}
    ]

	elapsed = {};
	s_result = [];
	start = new Date();
	if(req.method == "POST") req.query = req.body;

	Promise
	.all([culture_relic_paramcheck(req,res)])
	.then(function(){return _promise_checktime('paramcheck');})
	.then(function(){return culture_relic_work(req,res);})
	.then(function(){return _promise_checktime('work');})
	.then(function(){return culture_relic_sendresult(req,res);})
	.catch(function(err){return _promise_errhandler(req,res,err);})
	;
};

var culture_relic_paramcheck = function(req,res){
	return new Promise(function(resolve, reject){
		var err = req.validationErrors();
		if(err) {
			err.status = 400;
			res.status(400).send(util.res_err(req, 400, err[0].msg));
			console.error(err[0].msg,filename);
			return reject();
		}else{
			req.query.value = req.query.value || "";
			req.query.field = req.query.field || "title_ko";
			req.query.size = req.query.size || 1;
			req.query.lang = req.query.lang || "ko";
			return resolve();
        }
	});
};

var culture_relic_work = async(req,res)=>{
	var rs_obj = [];
	let lang = "_"+req.query.lang;

    var send_data;
	var response_source = rs_obj;
	var getRelicData = ()=>{
		return new Promise(function(resolve, reject){

            var param_obj = req.query.v_param;
            var p_param_obj = req.query.c_param;

			if( req.query.condition == 'init' ) {
				return resolve();
			}
			match_list = [];

			var ret_param = req.query.sce_param;
			ret_param.forEach((sce_item)=>{
				if(sce_item.step == 0){
					sce_item.params.forEach((s_item)=>{
						if(s_item.key == "시대") match_list.push( { "match_phrase": {  [ s_item.id ] : s_item.value } } );
						if(s_item.key == "재질") match_list.push( { "match_phrase": {  [ s_item.id ] : s_item.value } } );
						if(s_item.key == "출토지") match_list.push( { "match_phrase": {  [ s_item.id ] : s_item.value } } );
					});
				}
			});
			req.query.c_param.forEach((c_item)=>{
				if(c_item.key == "박물관_명") match_list.push( { "match_phrase": {  [ "collectionDb" ] : c_item.value } } );
			});

			var s_body =
			{
			  "size": 10,
			  "query": {
				  "bool": {
					  "must": match_list
					  }
			  },
			  "_source":["referenceIdentifier","title","alternativeTitle"]
			}

	        es.client1.search({
				index: "tr_culture_relic",
	            body: s_body
	        }).then(function (resp) {
	            s_result = resp.hits.hits;
	            return resolve();
	        }, function (err) {
				err.status = 400;
				res.status(400).send(util.res_err(req, 400, err.message));
				console.error(err.message,filename);
				return resolve();
			});
		});
	}
	await getRelicData();
	// await getExhibitionData();
};

var culture_relic_sendresult = async(req,res)=>{
	var getSendResult =()=>{
		return new Promise(function(resolve, reject){
			res.set({'Content-Type': 'text/json; charset=utf-8'});
			var messageObj =
			{
				id : "api_20180930_3",
				name : "유물 조회",
				description : "유물값 조회",
				request :request_set,
				mapping_info:response_set,
				response :
						{
							items:response_set
						},
				script: {
							type : "url",
							script_code: ""
				  		}
			}

			if( req.query.condition != 'init' ) {
				var result = s_result;
				var response_item_set = {"items":[]};
				response_set.forEach(v_item=>{
					v_item.value = [];
				});

				var setData = (v_item,element)=>{
					var rs_item={};
					var req_lang =  "_"+req.query.lang;
					var v_field= v_item.field
					var set_value = "";
					for(var in_field in element){
						if(in_field == v_field){
							set_value = element[in_field];
						}
					}
					v_item.value.push(set_value);
				}
				result.forEach(element => {
					response_set.forEach((v_item)=>{
						setData(v_item,element._source);
					});
				});
			}
			res.send(messageObj);
			return resolve();
		});
	}

	await getSendResult();
};




//***********************************************************************************************************
//  Process Logic : 유물정보 조회
//***********************************************************************************************************
/* GET users listing. */
router.get('/detail_culture_relic', function(req, res) {
	detail_culture_handler(req, res);
});

/* POST users listing. */
router.post('/detail_culture_relic', function(req, res) {
	detail_culture_handler(req, res);
});


// -- promiss handler
var detail_culture_handler = function(req,res){
	util.req_param('[조회] 유물 상세',req,filename);
	elapsed = {};
	s_result = [];
	start = new Date();
	if(req.method == "POST") req.query = req.body;

	Promise
	.all([detail_culture_paramcheck(req,res)])
	.then(function(){return _promise_checktime('paramcheck');})
	.then(function(){return detail_culture_work(req,res);})
	.then(function(){return _promise_checktime('work');})
	.then(function(){return detail_culture_sendresult(req,res);})
	.catch(function(err){return _promise_errhandler(req,res,err);})
	;
};

var detail_culture_paramcheck = function(req,res){
	return new Promise(function(resolve, reject){
		var err = req.validationErrors();
		if(err) {
			err.status = 400;
			res.status(400).send(util.res_err(req, 400, err[0].msg));
			console.error(err[0].msg,filename);
			return reject();
		}else{
			req.query.value = req.query.value || "";
			req.query.field = req.query.field || "title_ko";
			req.query.size = req.query.size || 1;
			req.query.lang = req.query.lang || "ko";
			return resolve();
        }
	});
};

var detail_culture_work = async(req,res)=>{


	request_set = [
		{"name":"유물명","field":"title_ko","value":[],"type":"string"},
		{"name":"전시관코드","field":"exhibitCode","value":[],"type":"string"}
	]
	response_set = [
		{"name":"유물명","field":"alternativeTitle","value":[],"type":"string"},
		{"name":"이미지","field":"referenceIdentifier","value":[],"type":"string"}
	]

	var rs_obj = [];
	let lang = "_"+req.query.lang;
	response_set.forEach(v_item=>{
		rs_obj.push( util.replaceFieldToLang(v_item.field, lang) );
	});

	var response_source = rs_obj;
	var getRelicData = ()=>{
		return new Promise(function(resolve, reject){

			if( req.query.condition == 'init' ) {
				return resolve();
			}
			match_list = [];
			var p_param_obj = req.query.c_param;
            if(p_param_obj != undefined){
                p_param_obj.forEach(function(item){
                    if(item.key == '도슨트상세유물'){
                        if(item.value !="") match_list.push( { "match_phrase": {  [ "alternativeTitle" ] : item.value } } );
                    }
                });
            }
			let in_str = req.query.in_str;
			if(in_str !="") match_list.push( { "match_phrase": {  [ "alternativeTitle" ] : in_str } } );

			var ret_param = req.query.sce_param;
			ret_param.forEach((sce_item)=>{
				if(sce_item.step == 0){
					sce_item.params.forEach((s_item)=>{
						if(s_item.key == "시대") match_list.push( { "match_phrase": {  [ s_item.id ] : s_item.value } } );
						if(s_item.key == "재질") match_list.push( { "match_phrase": {  [ s_item.id ] : s_item.value } } );
						if(s_item.key == "출토지") match_list.push( { "match_phrase": {  [ s_item.id ] : s_item.value } } );
					});
				}
			});

			var s_body =
			{
			  "size": req.query.size,
			  "query": {
				  "bool": {
					  "must": match_list
					  }
			  },
			  "_source":response_source
			}

	        es.client1.search({
				index: "tr_culture_relic",
	            body: s_body
	        }).then(function (resp) {
	            s_result = resp.hits.hits;
	            return resolve();
	        }, function (err) {
				err.status = 400;
				res.status(400).send(util.res_err(req, 400, err.message));
				console.error(err.message,filename);
				return resolve();
			});
		});
	}

	await getRelicData();

};

var detail_culture_sendresult = async(req,res)=>{

	var getSendResult =()=>{
		return new Promise(function(resolve, reject){
			res.set({'Content-Type': 'text/json; charset=utf-8'});
			var messageObj =
			{
				id : "set",
				name : "유물상세 조회",
				description : "유물상세 조회",
				request :request_set,
				mapping_info:response_set,
				response :
						{
							items:response_set
						},
				script: {
							type : "url",
							script_code: ""
				  		}
			}
			if( req.query.condition != 'init' ) {
				var result = s_result;
				var response_item_set = {"items":[]};
				response_set.forEach(v_item=>{
					v_item.value = [];
				});

				var setData = (v_item,element)=>{
					var rs_item={};
					var req_lang =  "_"+req.query.lang;
					var v_field= v_item.field;
					var set_value = "";
					for(var in_field in element){
						if(in_field == v_field){
							set_value = element[in_field];
						}
					}
					v_item.value.push(set_value);
				}
				result.forEach(element => {
					response_set.forEach((v_item)=>{
						setData(v_item,element._source);
					});
				});
			}

			res.send(messageObj);
			return resolve();
		});
	}

	await getSendResult();
};







//***********************************************************************************************************
//  Process Logic Area (E)
//***********************************************************************************************************

var _promise_checktime = function(name){
	return new Promise(function(resolve, reject){
        // elapsed time
        end = new Date();
        elapsed[name] = (end - start) + ' ms';
        console.debug('_promise_checktime ! - '+name+' ['+elapsed[name]+']');
        return resolve();
    });
};

var _promise_errhandler = function(req,res,err){
	return new Promise(function(resolve, reject){
		if(typeof(err) != 'undefined'){
			console.error(err,filename);
		    //res.status(500).send(util.res_err(req, 500, err.message));

		    res.status(err.status || 500);
		    res.render('error', {
		    	message: err.message,
		    	error: err
		    });
		    return resolve();
		}else{
			return resolve();
		}
	});
};

module.exports = router;
