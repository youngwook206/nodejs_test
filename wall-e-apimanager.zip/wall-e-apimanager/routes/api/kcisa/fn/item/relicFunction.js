var express = require('express');
var router = express.Router();
var path = require('path');
var filename = path.basename(__filename);
var approot = require('app-root-path');
var util = require(approot + '/util/util');

// elapsed time
var elapsed = {};
var start, end;

var match_list = [];

// result
var s_result = [];
var title_ = "";
var explain_ = "";
var audioURL_ = "";
// elasticsearch
var es = require(approot + '/util/es');
var request_list = [];

var request_set = [
	{"name":"유물명","field":"title_ko","value":[],"type":"string"},
	{"name":"전시관코드","field":"exhibitCode","value":[],"type":"string"}
]
var response_set = [
	{"name":"유물명","field":"title_ko","value":[],"type":"string"},
	{"name":"유물명_N","field":"title_ko","value":[],"type":"string"},
	{"name":"전시관코드","field":"exhibitCode","value":[],"type":"string"},
	{"name":"전시실코드","field":"showroomCode","value":[],"type":"string"},
	{"name":"유물설명","field":"explain_ko","value":[],"type":"string"},
	{"name":"음성_URL","field":"audioURL_en","value":[],"type":"string"},
	{"name":"유물이미지_URL","field":"relicImageURL","value":[],"type":"string"},
	{"name":"전시관명","field":"showroomName","value":[],"type":"string"},
	{"name":"층","field":"floorNum","value":[],"type":"string"},
	{"name":"유물코드","field":"relicCode","value":[],"type":"string"}
]
var index_name = "tr_relic";

//***********************************************************************************************************
//  Process Logic : get Exhibition_cod 실정보찾기
//***********************************************************************************************************
/* GET users listing. */
router.get('/exhibit_code', function(req, res) {
	exhibit_code_handler(req, res);
});

/* POST users listing. */
router.post('/exhibit_code', function(req, res) {
	exhibit_code_handler(req, res);
});

// -- promiss handler
var exhibit_code_handler = function(req,res){
	util.req_param('[조회] item 목록',req,filename);
	elapsed = {};
	s_result = [];
	start = new Date();
	if(req.method == "POST") req.query = req.body;

	Promise
	.all([_exhibit_code_paramcheck(req,res)])
	.then(function(){return _promise_checktime('paramcheck');})
	.then(function(){return _exhibit_code_work(req,res);})
	.then(function(){return _promise_checktime('work');})
	.then(function(){return _exhibit_code_sendresult(req,res);})
	.catch(function(err){return _promise_errhandler(req,res,err);})
	;
};

var _exhibit_code_paramcheck = function(req,res){
	return new Promise(function(resolve, reject){
		var err = req.validationErrors();
		if(err) {
			err.status = 400;
			res.status(400).send(util.res_err(req, 400, err[0].msg));
			console.error(err[0].msg,filename);
			return reject();
		}else{
			return resolve();
        }
	});
};

var _exhibit_code_work = function(req,res){
	return new Promise(function(resolve, reject){
		title_ = `title_${req.query.lang}`;
		explain_ = `explain_${req.query.lang}`;
		audioURL_ = `audioURL_${req.query.lang}`;

		//일반 param - elasticsearch 반영
		if( req.query.condition == 'init' ) {
			return resolve();
		} else if( req.query.condition == 'result' ) {
		} else if( req.query.condition == 'test' ) {
		}

		var domain_id = req.query.domain_id;
		var museumCode = {"museumCode": "PS01001001"};
		if(domain_id == "naju_nm") museumCode = {"museumCode": "PS01001013"};

		var s_body;
		s_body =
		{
		  "size": 0,
		  "query": {"match_phrase":museumCode}
		  ,"aggs" : {
		        "exhibit" : {
		            "terms" : { "field" : "exhibitCode" }
		        }
		    }
		};

        es.client1.search({
			index: index_name,
            body: s_body
        }).then(function (resp) {
            s_result = resp;
            return resolve();
        }, function (err) {
			err.status = 400;
			res.status(400).send(util.res_err(req, 400, err.message));
			console.error(err.message,filename);
			return resolve();
		});

	});
};

var _exhibit_code_sendresult = function(req,res){
	return new Promise(function(resolve, reject){
		res.set({'Content-Type': 'text/json; charset=utf-8'});
		var messageObj =
		{
			id : "api_20180930_3",
			name : "exhibitCode 조회",
			description : "exhibitCode aggregation",
			request :
					[],
			response :
					{
						items:
						[
							{
								type : "list",
								name : "실정보",
								value : []
							}
						]
					},
			script: {
						type : "url",
						script_code: ""
			  		}
		}

		if( req.query.condition != 'init' ) {
			var result = s_result.aggregations.exhibit.buckets;
			result.forEach(element => {
				messageObj.response.items[0].value.push( { text : element.key,image_url:"", value : element.key } );
			});
		}
		res.send(messageObj);
		return resolve();
	});
};






//***********************************************************************************************************
//  Process Logic : 유물정보 조회
//***********************************************************************************************************
/* GET users listing. */
router.get('/info_relic', function(req, res) {
	info_relic_handler(req, res);
});

/* POST users listing. */
router.post('/info_relic', function(req, res) {
	info_relic_handler(req, res);
});


// -- promiss handler
var info_relic_handler = function(req,res){
	util.req_param('[조회] 유물 목록',req,filename);
	elapsed = {};
	s_result = [];
	start = new Date();
	if(req.method == "POST") req.query = req.body;

	Promise
	.all([info_relic_paramcheck(req,res)])
	.then(function(){return _promise_checktime('paramcheck');})
	.then(function(){return info_relic_work(req,res);})
	.then(function(){return _promise_checktime('work');})
	.then(function(){return info_relic_sendresult(req,res);})
	.catch(function(err){return _promise_errhandler(req,res,err);})
	;
};

var info_relic_paramcheck = function(req,res){
	return new Promise(function(resolve, reject){
		var err = req.validationErrors();
		if(err) {
			err.status = 400;
			res.status(400).send(util.res_err(req, 400, err[0].msg));
			console.error(err[0].msg,filename);
			return reject();
		}else{
			req.query.value = req.query.value || "";
			req.query.field = req.query.field || "title_ko";
			req.query.size = req.query.size || 1;
			req.query.lang = req.query.lang || "ko";
			return resolve();
        }
	});
};

var info_relic_work = async(req,res)=>{

	var rs_obj = [];
	let lang = "_"+req.query.lang;

	var domain_id = req.query.domain_id;
	var museumCode = {"museumCode": "PS01001001"};
	if(domain_id == "naju_nm") museumCode = {"museumCode": "PS01001013"};

	response_set.forEach(v_item=>{
		rs_obj.push( util.replaceFieldToLang(v_item.field, lang) );
	});
	var response_source = rs_obj;
	var getRelicData = ()=>{
		return new Promise(function(resolve, reject){
			var param_obj = req.query.v_param;
			match_list = [];
			match_list.push(  {"match_phrase":museumCode} );
			match_list.push( { "match": {  [ "displayYN"] : "Y"} } );
			if(param_obj != undefined){
				param_obj.forEach((s_item)=>{
					match_list.push( { "match_phrase": {  [ s_item.field+".keyword" ] : s_item.value } } );
				});
			}
			if( req.query.condition == 'init' ) {
				return resolve();
			}else if( req.query.condition == 'result' ) {
			}

            // 조회 조건 추가
            var explainField = util.replaceFieldToLang("explain_ko", lang) + ".keyword";
            var not_match_list = [
                {
                    "match": {}
                }
            ];
            not_match_list[0].match[explainField] = "";

			var s_body =
			{
			  "size": req.query.size,
			  "query": {
				  "bool": {
					  "must": match_list,
                      "must_not": not_match_list
					  }
			  },
			  "_source":response_source
		  };

		  //console.log("s_body:::::::",JSON.stringify(s_body,null,2));

	        es.client1.search({
				index: index_name,
	            body: s_body
	        }).then(function (resp) {
	            s_result = resp.hits.hits;
	            return resolve();
	        }, function (err) {
				err.status = 400;
				res.status(400).send(util.res_err(req, 400, err.message));
				console.error(err.message,filename);
				return resolve();
			});
		});
	}

	var getShowroomData = async()=>{
		var getRespData =(e_data)=>{
			var showroomCode = e_data.showroomCode;
			return new Promise(function(resolve, reject){
				var s_match_list = [];
				s_match_list.push( { "match": { "showroomCode":showroomCode } } );
				var s_source = ["floorNum",util.replaceFieldToLang("title_ko", lang)];
				var s_body =
				{
				  "size": 1,
				  "query": {
					  "bool": {
						  "must": s_match_list
						  }
				  },
				  "_source":s_source
				}

				//console.log("showroom::xxx:",JSON.stringify(s_body,null,2));
		        es.client1.search({
					index: "tr_showroom",
		            body: s_body
		        }).then(function (resp) {

					var r_set = [];
					if(resp.hits.hits.length > 0){
						r_set = resp.hits.hits[0]._source;
						for(var item in r_set){
							if(item.indexOf("title_") != -1){
								e_data["showroomName"] = r_set[item];
							}else{
								e_data[item] = r_set[item];
							}
						}
					}
		            return resolve();
		        }, function (err) {
					err.status = 400;
					res.status(400).send(util.res_err(req, 400, err.message));
					console.error(err.message,filename);
					return resolve();
				});
			});
		}

		// console.log("s_results_results_result:::::",s_result,s_result.length);
		var req_set = [];
		s_result.forEach(element => {
			var e_data = element._source;
			req_set.push(getRespData(e_data));
		});
		await Promise.all(req_set);
	}

	await getRelicData();
	await getShowroomData();
	// console.log("end!!!!!");

};

var info_relic_sendresult = async(req,res)=>{

	var getSendResult =()=>{
		return new Promise(function(resolve, reject){
			res.set({'Content-Type': 'text/json; charset=utf-8'});
			var messageObj =
			{
				id : "resp",
				name : "유물 조회",
				description : "유물값 조회",
				request :request_set,
				mapping_info:response_set,
				response :
						{
							items:response_set
						},
				script: {
							type : "url",
							script_code: ""
				  		}
			}
			if( req.query.condition != 'init' ) {
				var result = s_result;
				var response_item_set = {"items":[]};
				response_set.forEach(v_item=>{
					v_item.value = [];
				});

				var setData = (v_item,element)=>{
					var rs_item={};
					var req_lang =  "_"+req.query.lang;
					var v_field= util.replaceFieldToLang(v_item.field, req_lang);
					var set_value = "";
					for(var in_field in element){
						if(in_field == v_field){
							set_value = element[in_field];
						}
					}
					set_value = chkArrayImage(v_item.field,set_value);
					v_item.value.push(set_value);
				}
				result.forEach(element => {
					response_set.forEach((v_item)=>{
						setData(v_item,element._source);
					});
				});
			}
			//console.log("messageObjmessageObj:::",JSON.stringify(messageObj,null,2));
			res.send(messageObj);
			return resolve();
		});
	}

	await getSendResult();
};



//***********************************************************************************************************
//  Process Logic Area (E)
//***********************************************************************************************************

var chkArrayImage = (v_field,set_value)=>{
	var ret_val = set_value;
	if(v_field == "relicImageURL"){
		if(set_value!= undefined && set_value != null){
			if(set_value.indexOf(",")!=-1){
				ret_val = set_value.split(",")[0];
			}
		}
	}
	return ret_val;
}


var _promise_checktime = function(name){
	return new Promise(function(resolve, reject){
        // elapsed time
        end = new Date();
        elapsed[name] = (end - start) + ' ms';
        console.debug('_promise_checktime ! - '+name+' ['+elapsed[name]+']');
        return resolve();
    });
};

var _promise_errhandler = function(req,res,err){
	return new Promise(function(resolve, reject){
		if(typeof(err) != 'undefined'){
			console.error(err,filename);
		    //res.status(500).send(util.res_err(req, 500, err.message));

		    res.status(err.status || 500);
		    res.render('error', {
		    	message: err.message,
		    	error: err
		    });
		    return resolve();
		}else{
			return resolve();
		}
	});
};

module.exports = router;
