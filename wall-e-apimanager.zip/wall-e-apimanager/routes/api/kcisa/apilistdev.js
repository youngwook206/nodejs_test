//apilist.js

var express = require('express');
var router = express.Router();
var path = require('path');
var filename = path.basename(__filename);
var fs = require('fs');

var approot = require('app-root-path');
var util = require(approot + '/util/util');

// elapsed time
var elapsed = {};
var start, end;

// result
var body = {};

/* GET users listing. */
router.get('/', function(req, res) {
	promisshandler(req, res);
});

/* POST users listing. */
router.post('/', function(req, res) {
	promisshandler(req, res);
});


//***********************************************************************************************************
//  Process Logic Area (S)
//***********************************************************************************************************

// -- promiss handler
var promisshandler = function(req,res){
	util.req_param('API 목록 호출',req,filename);
	elapsed = {}; 
	body = {};

	Promise
	.all([_promise_work(req,res)])
	.then(function(){return _promise_checktime('work');})
	.then(function(){return _promise_sendresult(req,res);})
	.catch(function(err){return _promise_errhandler(req,res,err);})
	;

};

var _promise_work = function(req,res){
	return new Promise(function(resolve, reject){
		start = new Date();

		// req validation
		req.checkQuery('output', 'invalid output value').optional().matches("^(json|html)$");
		var err = req.validationErrors();
		if(err) {
			console.error('validationErrors : '+err[0].msg,filename);
			res.status(400).send(util.res_err(req, 400, err[0].msg));
			return reject();
		}else{
			if(req.method === "POST") req.query = req.body;
		}

	    //get parameter
	    req.query.output = req.query.output || 'html';    

		//make body
		//body = require('./apilisttext.txt');
		//console.trace(JSON.stringify(body));

		try {  
			body = fs.readFileSync(approot+'/routes/api/kcisa/apilisttextdev.html', 'utf8');
			return resolve();  
		} catch(e) {
			console.log('Error:', e.stack);
			return reject();
		}
		
	});
};

var _promise_sendresult = function(req,res){
	return new Promise(function(resolve, reject){
		start = new Date();

		if(req.query.output === 'json'){
			res.set({'Content-Type': 'application/json; charset=utf-8'});
			//res.send(apilist);
			_promise_checktime('display');
			res.send(util.res_ok(req, body, elapsed));
			return resolve();
		}else if(req.query.output === 'html'){
			res.set({'Content-Type': 'text/html; charset=utf-8'});
			//res.send('');
			_promise_checktime('display');
			//res.send(util.res_ok(req, body, elapsed));
			res.send(body);
			return resolve();
		}

	});
};

//***********************************************************************************************************
//  Process Logic Area (E)
//***********************************************************************************************************

var _promise_checktime = function(name){
	return new Promise(function(resolve, reject){
        // elapsed time
        end = new Date();
        elapsed[name] = (end - start) + ' ms';
        return resolve();
    });
};

var _promise_errhandler = function(req,res,err){
	return new Promise(function(resolve, reject){
		if(typeof(err) !== 'undefined'){
			console.error(err,filename);
		    //res.status(500).send(util.res_err(req, 500, err.message));

		    res.status(err.status || 500);
		    res.render('error', {
		    	message: err.message,
		    	error: err
		    });

		}
		return resolve();
	});
};

module.exports = router;
