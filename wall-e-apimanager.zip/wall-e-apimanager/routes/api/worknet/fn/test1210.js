var express = require('express');
var router = express.Router();
var path = require('path');
var filename = path.basename(__filename);
var approot = require('app-root-path');
var uc = require(approot + '/util/unit_changer');

/* GET users listing. */
router.get('/test', function(req, res) {
	//uc_test(req, res);
	uc_phrase_test(req, res);
});

/* POST users listing. */
router.post('/test', function(req, res) {
	//uc_test(req, res);
	uc_phrase_test(req, res);
});

var uc_test = function(req,res){
	[
		1000000
		/*
		'종로에서 1억5,600만원 이상 설계직 찾아줘'
		'1천원',
	    '1억5,600만원',
	    '일억5600만원',
	    '구억팔천칠백육십오만사천삼백이십일원',
	    '오억오천만오십원',
	    '오조구억구원',
	    '100억칠십만200원'
		*/
	].forEach((e) => {
	    console.log(e, '=', uc(e));
	});
}

var uc_phrase_test = function(req,res) {
	console.log('uc_phrase_test');
	// testStr = '종로에서 1억5,600만원 이상 설계직 찾아줘';
	// testStr = '종로에서 1억4600 이상 설계직 찾아줘';
	// testStr = '경기 이천 1억4600 이상 설계직 찾아줘';
	// testStr = '일억2000원 찾아줘';
	//testStr = '1000 찾아줘';
	testStr = '100000';


	resultStr = '';
	temp_arr = testStr.split(' ');
	temp_arr.forEach( el => {
		if( resultStr != '') resultStr += ' ';
		if( uc(el) == -1 ) {
			resultStr += el;
		} else {
			resultStr += uc(el);
		}
	})
	console.log('unit_changer 변환 문장 : ' + resultStr);
}

module.exports = router;
