var express = require('express');
var router = express.Router();
var path = require('path');
var filename = path.basename(__filename);
var approot = require('app-root-path');
var util = require(approot + '/util/util');
var es = require(approot + '/util/es');

// elapsed time
var elapsed = {};
var start, end;
var body = {};



//***********************************************************************************************************
//  Process Logic : 채용정보 검색
//***********************************************************************************************************
/* GET users listing. */
router.get('/callWantedApi', function(req, res) {
	wantedApi_handler(req, res);
});

/* POST users listing. */
router.post('/callWantedApi', function(req, res) {
	wantedApi_handler(req, res);
});


// -- promiss handler
var wantedApi_handler = function(req,res){
	util.req_param('[API연동] 채용정보 검색',req,filename);
	elapsed = {};
	start = new Date();
	if(req.method == "POST") req.query = req.body;

	Promise
	.all([wantedApi_paramcheck(req,res)])
	.then(function(){return _promise_checktime('paramcheck');})

	.then(function(){return wantedApi_work(req,res);})
	.then(function(){return _promise_checktime('wantedApi');})

	.then(function(){return wantedApi_sendresult(req,res);})
	.catch(function(err){return _promise_errhandler(req,res,err);})
	;
};


var wantedApi_work = async(req)=>{
    let s_result = {};
    let region_code = "";

    let getRegionCode = function(req) {
        return new Promise(function(resolve, reject) {
            console.warn('[wanted] getRegionCode - start');

            let region = req.query.region;
            console.check('[getRegionCode] region =======> ' + region);

            let matchObj = {};
            if(region != "") matchObj = { match : { region : region }};
            console.check('[getRegionCode] matchObj =======> ' + JSON.stringify(matchObj));

            let s_body =
            {
              query: matchObj
            }
            console.warn("[getRegionCode] s_body : " + JSON.stringify(s_body));

	        es.client1.search({
				index: "tr_region",
	            body: s_body
	        }).then(function (resp) {
	            s_result = resp.hits.hits;
				console.warn('[getRegionCode] tr_region : ' + resp.hits.total);
	            return resolve();
            }).then(function () {
                console.check('s_result : '+ JSON.stringify(s_result));
                region_code = s_result[0]._source.code;

	        }, function (err) {
				err.status = 400;
				res.status(400).send(util.res_err(req, 400, err.message));
				console.error(err.message,filename);
				return resolve();
			});
        });
    }

    let callWantedApi = function(req) {
        return new Promise(function(resolve, reject) {
            console.warn('[wanted] callWantedApi - start');

            let http = require('http');
            let xml2js = require('xml2js');
            let urlencode = require('urlencode');
            let parser = new xml2js.Parser();

            parser.on('error', function(err) {
                console.log('Parser error', err);
            });

    		let apiHost = "http://openapi.work.go.kr/opi/opi/opia/wantedApi.do";
    		let authKey = "WNJNWU9VRR5UJEJZ08ZH52VR1HK";
    		let callTp = "L";
    		let returnType = "xml";
    		let startPage = "1";
    		let display = "100";
            let keyword = '';
            if(req.query.keyword) {
                keyword = urlencode(req.query.keyword);
            }
    		let callUrl = `${apiHost}?authKey=${authKey}&callTp=${callTp}&returnType=${returnType}&startPage=${startPage}&display=${display}&region=${region_code}&keyword=${keyword}`;
            console.check('[callWantedApi] callUrl : ' + callUrl);
            let data = '';
            http.get(callUrl, function(res) {
                if (res.statusCode >= 200 && res.statusCode < 400) {
                    res.on('data', function(data_) {
                        data += data_.toString();
                    });
                    res.on('end', function() {
                        parser.parseString(data, function(err, result) {
                            // console.warn('1 :' + JSON.stringify(result));
                            body = {result:result};
                        });
                    });
                }
                resolve();
            });
        });
    }

    await getRegionCode(req);
    await callWantedApi(req);
}



var wantedApi_paramcheck = function(req,res){
	return new Promise(function(resolve, reject){
		var err = req.validationErrors();
		if(err) {
			err.status = 400;
			res.status(400).send(util.res_err(req, 400, err[0].msg));
			console.error(err[0].msg,filename);
			return reject();
		}else{
            req.query.keyword = req.query.keyword || '';
            req.query.region = req.query.region || '';
			return resolve();
        }
	});
};


var wantedApi_sendresult = function(req,res){
	return new Promise(function(resolve, reject){

		res.set({'Content-Type': 'text/json; charset=utf-8'});
		//res.send('');

		end = new Date();
		elapsed['sendresult'] = (end - start) + ' ms';
        // console.check('[wantedApi_sendresult] body : ' + JSON.stringify(body));
		res.send(util.res_ok(req, body, elapsed));
		console.debug('_promise_sendresult !');
		return resolve();
	});
};


//***********************************************************************************************************
//  Process Logic : 직종 검색
//***********************************************************************************************************
/* GET users listing. */
router.get('/getJobCode', function(req, res) {
	jobCode_handler(req, res);
});

/* POST users listing. */
router.post('/getJobCode', function(req, res) {
	jobCode_handler(req, res);
});


// -- promiss handler
var jobCode_handler = function(req,res){
	util.req_param('[코드검색]  검색',req,filename);
	elapsed = {};
	start = new Date();
	if(req.method == "POST") req.query = req.body;

	Promise
	.all([jobCode_paramcheck(req,res)])
	.then(function(){return _promise_checktime('paramcheck');})

	.then(function(){return jobCode_work(req,res);})
	.then(function(){return _promise_checktime('jobCode');})

	.then(function(){return jobCode_sendresult(req,res);})
	.catch(function(err){return _promise_errhandler(req,res,err);})
	;
};


var jobCode_work = async(req)=>{

	let s_result = {};
    let job_code = "";

    let jobCode = function(req) {
        return new Promise(function(resolve, reject) {
            console.warn('[wanted] jobCode - start');


			/*
            let region = req.query.region;
            console.check('[jobCode] region =======> ' + region);

            let matchObj = {};
            if(region != "") matchObj = { match : { region : region }};
            console.check('[getRegionCode] matchObj =======> ' + JSON.stringify(matchObj));

            let s_body =
            {
              query: matchObj
            }
			*/
            console.warn("[getRegionCode] s_body : " + JSON.stringify(s_body));

	        es.client1.search({
				index: "tr_region",
	            body: s_body
	        }).then(function (resp) {
	            s_result = resp.hits.hits;
				console.warn('[getRegionCode] tr_region : ' + resp.hits.total);
	            return resolve();
            }).then(function () {
                console.check('s_result : '+ JSON.stringify(s_result));
                region_code = s_result[0]._source.code;

	        }, function (err) {
				err.status = 400;
				res.status(400).send(util.res_err(req, 400, err.message));
				console.error(err.message,filename);
				return resolve();
			});
        });
    }


    await getJobCode(req);
}



var jobCode_paramcheck = function(req,res){
	return new Promise(function(resolve, reject){
		var err = req.validationErrors();
		if(err) {
			err.status = 400;
			res.status(400).send(util.res_err(req, 400, err[0].msg));
			console.error(err[0].msg,filename);
			return reject();
		}else{
            req.query.occupation_keyword = req.query.occupation_keyword || '';
			return resolve();
        }
	});
};


var jobCode_sendresult = function(req,res){
	return new Promise(function(resolve, reject){
		res.set({'Content-Type': 'text/json; charset=utf-8'});
		//res.send('');

		end = new Date();
		elapsed['sendresult'] = (end - start) + ' ms';
        // console.check('[wantedApi_sendresult] body : ' + JSON.stringify(body));
		res.send(util.res_ok(req, body, elapsed));
		console.debug('_promise_sendresult !');
		return resolve();
	});
};

//***********************************************************************************************************
//  Process Logic Area (E)
//***********************************************************************************************************

var _promise_checktime = function(name){
	return new Promise(function(resolve, reject){
        // elapsed time
        end = new Date();
        elapsed[name] = (end - start) + ' ms';
        console.debug('_promise_checktime ! - '+name+' ['+elapsed[name]+']');
        return resolve();
    });
};

var _promise_errhandler = function(req,res,err){
	return new Promise(function(resolve, reject){
		if(typeof(err) != 'undefined'){
			console.error(err,filename);
		    //res.status(500).send(util.res_err(req, 500, err.message));

		    res.status(err.status || 500);
		    res.render('error', {
		    	message: err.message,
		    	error: err
		    });
		    return resolve();
		}else{
			return resolve();
		}
	});
};

module.exports = router;
