const express = require('express');
const router = express.Router();
const path = require('path');
const filename = path.basename(__filename);
const approot = require('app-root-path');

/* GET users listing. */
router.get('/test', function(req, res) {
	uc_phrase_test(req, res);
});

/* POST users listing. */
router.post('/test', function(req, res) {
	uc_phrase_test(req, res);
});

const uc_phrase_test = function(req, res) {
    const josa = '이가은는을를과와';
    const regex = new RegExp('.{~[' + josa + ']}', 'g');

    function replaceJosa(text) {
        return text.replace(regex, function(match) {
			console.check('match=' + match);
            let idx = josa.indexOf(match.charAt(3));
			console.check('idx:' + idx);
            let josa1 = josa2 = josa.charAt(idx);

            if (idx % 2 == 0) {
                josa2 = josa.charAt(idx + 1);
            } else {
                josa1 = josa.charAt(idx - 1);
            }

            let char = match.charAt(0);
            let charcode = match.charCodeAt(0);
            if (charcode >= 0xAC00 && charcode <= 0xD7A3) {
                let jong = (charcode - 0xAC00) % 28;
                if (jong == 0) {
                    return char + josa2;
                } else {
                    return char + josa1;
                }
            } else {
                return josa1;
            }
        });
    }


    [
        'NBA{~는} 조선시대{~을} 말하는 칼{~이} 1층{~와} 2층에 있다고 알려줬어요.',
        '문화정보원{~와} 아이브릭스의 챗봇{~가} 잘 작동합니다.'
    ].forEach(function(text) {
        console.log(text, '=>', replaceJosa(text));
    });

}

module.exports = router;
