var express = require('express');
var router = express.Router();
var path = require('path');
var filename = path.basename(__filename);
var approot = require('app-root-path');
var configfile = require(approot + '/config/config.json');
var config = require(approot + '/config/config');
var util = require(approot + '/util/util');
var clonedeep = require('lodash.clonedeep');
var es = require(approot + '/util/es');

// elapsed time
var elapsed = {};
var start, end;
var add_parameter = [];
var s_result = [];
var request_set = [];
var response_set = [];
var param_obj = [];
var sce_param_obj = [];
var recall_parameters = [];
var result_count = 0;
var recommend_arr = [];
var recommend_condition = "";


//***********************************************************************************************************
//  Process Logic : 실명 조회
//***********************************************************************************************************
/* GET users listing. */
router.get('/', function(req, res) {
	basic_handler(req, res);
});

/* POST users listing. */
router.post('/', function(req, res) {
	basic_handler(req, res);
});


// -- promiss handler
var basic_handler = function(req,res){
	util.req_param('[조회] 추천정보',req,filename);
	elapsed = {};
	s_result = [];
	start = new Date();
	if(req.method == "POST") req.query = req.body;

	Promise
	.all([basic_paramcheck(req,res)])
	.then(function(){return _promise_checktime('paramcheck');})
	.then(function(){return basic_work(req,res);})
	.then(function(){return _promise_checktime('not_matching');})
	.then(function(){return basic_sendresult(req,res);})
	.catch(function(err){return _promise_errhandler(req,res,err);})
	;
};

var basic_work = async(req,res)=>{
	var domain_id = req.query.domain_id;
    var user_id_flag = false;
    var recommend_flag = false;

    var chkRecommedInfo =()=>{

        recommend_condition = "";
        // console.log("XXX::::::::::::::::::req.query.req_parameters:::",req.query.req_parameters);
        // console.log("XXX::::::::::::::::::req.query.req_parameters:::",req.query.user_id);
        if(req.query.req_parameters != undefined){
            var parameters = req.query.req_parameters;
            var param_obj = JSON.parse(parameters);
            if(param_obj.recommend != undefined){
                param_obj.recommend.forEach((s_item)=>{
                    // console.log("s_item::::",s_item);
                    var count = s_item.count;
                    if(count > 0) recommend_flag = true;
                });
            }
        }

        if(req.query.user_id != undefined){
            if(req.query.user_id != "") user_id_flag = true;
        }

        // console.log("====>:::",user_id_flag ,recommend_flag);
        if(user_id_flag && !recommend_flag) recommend_condition = "로그인";
        if(!user_id_flag) recommend_condition = "noresult";
        // console.log("recommend_condition::::::::::::",recommend_condition);
    }

	var getRecommendResult =()=>{
		return new Promise(function(resolve, reject){
            // console.log("req.query.req_parametersreq.query.req_parameters:::::",req.query.req_parameters);
            if(req.query.req_parameters != undefined){
                var parameters = req.query.req_parameters;
                var param_obj = JSON.parse(parameters);
                recommend_arr = param_obj.recommend;
            }
            return resolve();
		});
	}

    var getUrl =()=>{
        if(recommend_arr !=undefined){
            var setUrl = "https://www.work.go.kr/indivMemberSrv/theWork/retrieveTheWorkInfo.do";
            recommend_arr.forEach((v_item)=>{
                if(v_item.name == "채용"){
                    v_item.url = setUrl+"?infoDiv=work#work";
                }else if(v_item.name == "정책"){
                    v_item.url = setUrl+"?infoDiv=?infoDiv=poly#poly";
                }if(v_item.name == "기업"){
                    v_item.url = setUrl+"?infoDiv=?infoDiv=busi#busi";
                }if(v_item.name == "훈련"){
                    v_item.url = setUrl+"?infoDiv=?infoDiv=train#train";
                }if(v_item.name == "자격"){
                    v_item.url = setUrl+"?infoDiv=?infoDiv=qual#qual";
                }if(v_item.name == "심리검사"){
                    v_item.url = setUrl+"?infoDiv=?infoDiv=psy#psy";
                }
            });
        }
    }


    var checkParameters = (req)=> {
    	param_obj = clonedeep(req.query.by_pass_param);
    	sce_param_obj = req.query.sce_param;

        return new Promise(function(resolve, reject){
			recall_parameters = param_obj;
            // console.log("recommend_condition::::::::",recall_parameters);
            if(recall_parameters != undefined){
                if(recommend_condition != ""){
                    recall_parameters.forEach((p_item)=>{
                        if(p_item.key == "apicondition") p_item.value = recommend_condition;
                    })
                    req.query.recall_type = 'recall';
                }
                if(sce_param_obj != undefined){
                    sce_param_obj.forEach( el => {
                        if( el.intent_id == req.query.intent_id ) el.params = recall_parameters;
                    });
                }
            }

			resolve();
		});
	}

    await chkRecommedInfo();
    if(recommend_condition == ""){
        await getRecommendResult(req);
        await getUrl();
    }
    await await checkParameters(req);
}

var basic_paramcheck = function(req,res){
	return new Promise(function(resolve, reject){
		var err = req.validationErrors();
		if(err) {
			err.status = 400;
			res.status(400).send(util.res_err(req, 400, err[0].msg));
			console.error(err[0].msg,filename);
			return reject();
		}else{
			req.query.in_str = req.query.in_str || "";
			req.query.domainId = req.query.domainId || "";
			req.query.lang = req.query.lang || "";
			return resolve();
        }
	});
};

var basic_sendresult = async(req,res)=>{

    var response_set = [
        {"name":"COUNT","field":"count","value":[],"type":"string"},
        {"name":"TITLE","field":"name","value":[],"type":"string"},
        {"name":"URL","field":"url","value":[],"type":"string"}
    ];
    var request_set = [];

    var getSendResult =()=>{
		return new Promise(function(resolve, reject){
			res.set({'Content-Type': 'text/json; charset=utf-8'});


            // req_body.result.meta.response_type = recall_response_type;
            // req_body.result.meta.recall_total_count = recall_total_count;
            // req_body.result.meta.parameters = recall_param;
            // req_body.result.meta.scenario_parameters = recall_scenario_param;
            // console.log("recall_parametersrecalXXXXXl_parameters:::",recall_parameters,"::::",req.query.recall_type);
			var messageObj =
			{
                recall_inform : {
    				recall_parameters : recall_parameters,
    				scenario_parameters : sce_param_obj,
    				recall_type : req.query.recall_type,
    				response_type : "answer"
    			},
				id : "notmatching",
				name : "not matching",
				description : "not matching",
				request :request_set,
				mapping_info:response_set,
				response :
						{
							items:response_set
						},
				script: {
							type : "url",
							script_code: ""
				  		},
                add_parameter: add_parameter
			}

			if( req.query.condition != 'init' ) {
				var result = recommend_arr;
				var response_item_set = {"items":[]};
				response_set.forEach(v_item=>{
					v_item.value = [];
				});

				var setData = (v_item,element)=>{
					var rs_item={};
					var v_field = v_item.field;
					var set_value = "";
					for(var in_field in element){
						if(in_field == v_field){
							set_value = element[in_field];
						}
					}
					v_item.value.push(set_value);
				}

                if(result!=undefined){
                    result.forEach(element => {
                        response_set.forEach((v_item)=>{
    						setData(v_item,element);
    					});
    				});
                }

			}

			res.send(messageObj);
			return resolve();
		});
	}

	await getSendResult();
};














//***********************************************************************************************************
//  Process Logic Area (E)
//***********************************************************************************************************

var chkArrayImage = (v_field,set_value)=>{
	var ret_val = set_value;
	if(v_field == "relicImageURL"){
		if(set_value!= undefined && set_value != null){
			if(set_value.indexOf(",")!=-1){
				ret_val = set_value.split(",")[0];
			}
		}
	}
	return ret_val;
}

var _promise_checktime = function(name){
	return new Promise(function(resolve, reject){
        // elapsed time
        end = new Date();
        elapsed[name] = (end - start) + ' ms';
        console.debug('_promise_checktime ! - '+name+' ['+elapsed[name]+']');
        return resolve();
    });
};

var _promise_errhandler = function(req,res,err){
	return new Promise(function(resolve, reject){
		if(typeof(err) != 'undefined'){
			console.error(err,filename);
		    //res.status(500).send(util.res_err(req, 500, err.message));

		    res.status(err.status || 500);
		    res.render('error', {
		    	message: err.message,
		    	error: err
		    });
		    return resolve();
		}else{
			return resolve();
		}
	});
};

module.exports = router;
