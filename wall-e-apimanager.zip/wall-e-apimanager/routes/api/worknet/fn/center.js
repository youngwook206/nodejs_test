let express = require('express');
let router = express.Router();
let path = require('path');
let filename = path.basename(__filename);
let approot = require('app-root-path');
let util = require(approot + '/util/util');
let config = require(approot + '/config/config');
let clonedeep = require('lodash.clonedeep');
let uc = require(approot + '/util/unit_changer');

// elapsed time
let elapsed = {};
let start, end;

let match_list = [];

// result
let s_result = [];
let a_result = {};

// elasticsearch
let es = require(approot + '/util/es');
let request_list = [];
let request_set = [];
let add_parameter = [];
let recall_parameters = [];
let sce_param_obj = [];
let search_total_cnt = 0;
let center_obj = {};

//***********************************************************************************************************
//  Process Logic : 고용센터 찾기
//***********************************************************************************************************
/* GET checkWantedParam */
router.get('/getCenter', function(req, res) {
	getCenter_handler(req, res);
});

/* POST checkWantedParam */
router.post('/getCenter', function(req, res) {
	getCenter_handler(req, res);
});


// -- promiss handler
const getCenter_handler = function(req,res){
	console.debug('[center.js] 고용센터 찾기 Function Start');
	elapsed = {};
	start = new Date();
	if(req.method == "POST") req.query = req.body;

	Promise
	.all([getCenter_paramcheck(req,res)])
	.then(function(){return _promise_checktime('paramcheck');})

	.then(function(){return getCenter_work(req,res);})
	.then(function(){return _promise_checktime('getCenter');})

	.then(function(){return getCenter_sendresult(req,res);})
	.catch(function(err){return _promise_errhandler(req,res,err);})
	;
};


const getCenter_paramcheck = function(req,res){
	return new Promise(function(resolve, reject){
		let err = req.validationErrors();
		if(err) {
			err.status = 400;
			res.status(400).send(util.res_err(req, 400, err[0].msg));
			console.error(err[0].msg,filename);
			return reject();
		}else{
			// req.query.user_id = req.query.user_id || '';
			req.query.recall_type = 'by_pass';
			add_parameter = [];
			return resolve();
        }
	});
};


const getCenter_work = async(req)=>{
	sce_param_obj = req.query.sce_param;
	let param_obj = req.query.by_pass_param;
	let region_nm = "";
	let apicondition_value = '';
	center_obj = [];

	if(param_obj != undefined){
		for (const el of param_obj) {
			if(el.key == '고용센터지역정보') {
				region_nm = el.value;
			}
		}
		recall_parameters = param_obj;
	}

	let getCenterInstance = function() {
		return new Promise(function(resolve, reject) {
			console.debug('[wanted] getCenterInstance - start');

			if(region_nm!='') {
				let req_promise = require('request-promise');
				let req_param = {
		            method: 'POST',
		            uri: "",
		            body: "",
		            headers: {
		              'Content-Type': 'application/json'
		            },
		            json: false
		        };
				req_param.body = JSON.stringify( {"region_nm":region_nm} );
				req_param.uri = config.work_center_url;

				return req_promise(req_param,function(e,v,item){
					try{
						item = JSON.parse( item );
						if(item.status.code == 200) {
							center_obj = item.centers;
						}
						resolve();
					}catch(e){
						console.error(config.work_center_url+' 실행에러!!!');
						console.error(e);
						resolve();
					}
				});
			} else {
				console.error('region_nm 도 없음');
				resolve();
			}
		});
	}

	let setApicondition = function(req) {
		return new Promise(function(resolve, reject) {
			console.debug('[wanted] setApicondition - start');

			let org_nm = "";
			center_obj.forEach( c_el => {
				org_nm = center_obj.org_nm;
			});

			if(org_nm == ""  && center_obj.length == 1) {
				req.query.recall_type = 'recall';
				apicondition_value = "noresult";
			} else {
				req.query.recall_type = 'by_pass';
			}

			recall_parameters.forEach((p_item)=>{
				if(p_item.key == "apicondition") p_item.value = apicondition_value;
			});

			if(sce_param_obj != undefined){
				sce_param_obj.forEach( el => {
					if( el.intent_id == req.query.intent_id ) el.params = recall_parameters;
				});
			}

			resolve();
		});
	}

	await getCenterInstance();
	await setApicondition(req);
}


const getCenter_sendresult = function(req,res){
	return new Promise(function(resolve, reject){
		console.debug('getCenter_sendresult');

		request_set = [];
		const response_set = [
			{"name":"센터명","field":"org_nm","value":[],"type":"string"},
			{"name":"전화번호","field":"telno","value":[],"type":"string"},
			{"name":"주소","field":"full_addr","value":[],"type":"string"}
		];

		res.set({'Content-Type': 'text/json; charset=utf-8'});
		let messageObj =
		{
			recall_inform : {
				recall_parameters : recall_parameters,
				scenario_parameters : sce_param_obj,
				recall_type : req.query.recall_type,
				response_type : req.query.aw_type
			},

			id : "worknet_getCenter",
			name : "[고용센터] 고용센터 찾기",
			description : "return centerInform",
			request :request_set,
			mapping_info:response_set,
			response :
					{
						items: response_set
					},
			script: {
						type : "url",
						script_code: ""
			  		},
			add_parameter: add_parameter
		}

		if( req.query.condition != 'init' ) {
			let response_item_set = {"items":[]};
			response_set.forEach(v_item=>{
				v_item.value = [];
			});

			var setData = (v_item,element)=>{
				var v_field= v_item.field;
				var set_value = "";
				for(var in_field in element){
					if(in_field == v_field){
						set_value = element[in_field];
					}
				}
				v_item.value.push(set_value);
			}

			center_obj.forEach(element => {
				response_set.forEach((v_item)=>{
					setData(v_item,element);
				});
			});
		}

		// console.error(JSON.stringify(messageObj));

		res.send(messageObj);
		return resolve();
	});
};




//***********************************************************************************************************
//  Process Logic : 고용센터 결과없음
//***********************************************************************************************************
/* GET checkWantedParam */
router.get('/noResult', function(req, res) {
	noResult_handler(req, res);
});

/* POST checkWantedParam */
router.post('/noResult', function(req, res) {
	noResult_handler(req, res);
});


// -- promiss handler
const noResult_handler = function(req,res){
	console.debug('[center.js] 고용센터  없음 Function Start');
	elapsed = {};
	start = new Date();
	if(req.method == "POST") req.query = req.body;

	Promise
	.all([noResult_paramcheck(req,res)])
	.then(function(){return _promise_checktime('paramcheck');})

	.then(function(){return noResult_work(req,res);})
	.then(function(){return _promise_checktime('getCenter');})

	.then(function(){return noResult_sendresult(req,res);})
	.catch(function(err){return _promise_errhandler(req,res,err);})
	;
};


const noResult_paramcheck = function(req,res){
	return new Promise(function(resolve, reject){
		let err = req.validationErrors();
		if(err) {
			err.status = 400;
			res.status(400).send(util.res_err(req, 400, err[0].msg));
			console.error(err[0].msg,filename);
			return reject();
		}else{
			// req.query.user_id = req.query.user_id || '';
			req.query.recall_type = 'by_pass';
			add_parameter = [];
			return resolve();
        }
	});
};


const noResult_work = async(req)=>{

	let param_obj = req.query.by_pass_param;
	let region_nm = "";

	if(param_obj != undefined){
		for (const el of param_obj) {
			if(el.key == '고용센터지역정보') {
				region_nm = el.value;
			}
		}
		recall_parameters = param_obj;
	}
}


const noResult_sendresult = function(req,res){
	return new Promise(function(resolve, reject){
		console.debug('noResult_sendresult');

		request_set = [];
		const response_set = [
			{"name":"no result","field":"org_detail","value":[],"type":"string"}
		];

		res.set({'Content-Type': 'text/json; charset=utf-8'});
		let messageObj =
		{
			recall_inform : {
				recall_parameters : recall_parameters,
				scenario_parameters : sce_param_obj,
				recall_type : req.query.recall_type,
				response_type : req.query.aw_type
			},

			id : "worknet_getCenter",
			name : "[고용센터] 해당센터없음",
			description : "return no result",
			request :request_set,
			mapping_info:response_set,
			response :
					{
						items: response_set
					},
			script: {
						type : "url",
						script_code: ""
			  		},
			add_parameter: add_parameter
		}

		if( req.query.condition != 'init' ) {
			response_set.forEach( el => {
				el.value[0] = `해당지역의 고용센터 정보를 찾을 수 없습니다.`;
			})
		}

		// console.error(JSON.stringify(messageObj));

		res.send(messageObj);
		return resolve();
	});
};



//***********************************************************************************************************
//  Process Logic Area (E)
//***********************************************************************************************************
const _promise_checktime = function(name){
	return new Promise(function(resolve, reject){
        // elapsed time
        end = new Date();
        elapsed[name] = (end - start) + ' ms';
        //console.debug('_promise_checktime ! - '+name+' ['+elapsed[name]+']');
        return resolve();
    });
};

const _promise_errhandler = function(req,res,err){
	return new Promise(function(resolve, reject){
		if(typeof(err) != 'undefined'){
			console.error(err,filename);
		    //res.status(500).send(util.res_err(req, 500, err.message));

		    res.status(err.status || 500);
		    res.render('error', {
		    	message: err.message,
		    	error: err
		    });
		    return resolve();
		}else{
			return resolve();
		}
	});
};


module.exports = router;
