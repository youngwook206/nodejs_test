const express = require('express');
const router = express.Router();
const path = require('path');
const filename = path.basename(__filename);
const approot = require('app-root-path');
const util = require(approot + '/util/util');
const es = require(approot + '/util/es');

// elapsed time
let elapsed = {};
let start, end;

//***********************************************************************************************************
//  Process Logic : 인덱스 복사
//***********************************************************************************************************
/* GET users listing. */
router.get('/copy_index', function(req, res) {
	copy_index_handler(req, res);
});

/* POST users listing. */
router.post('/copy_index', function(req, res) {
	copy_index_handler(req, res);
});


// -- promiss handler
let copy_index_handler = function(req,res){
	util.req_param('인덱스 복사',req,filename);
	elapsed = {};
	start = new Date();
	if(req.method == "POST") req.query = req.body;

	Promise
	.all([copy_paramcheck(req,res)])
	.then(function(){return _promise_checktime('paramcheck');})
	.then(function(){return copy_work(req,res);})
	.then(function(){return _promise_checktime('copy_index');})
	.then(function(){return copy_sendresult(req,res);})
	.catch(function(err){return _promise_errhandler(req,res,err);})
	;
};

let copy_work = async(req,res)=>{
	console.debug('[copy_index] copy_work - start');
	let old_domain_id = req.query.asis_domain_id;
	let domain_id = req.query.domain_id;
	let s_body;
	let size = 5000;
	let s_index = req.query.s_index;
	let s_result = [];
	let sr_result = [];
	let sp_result = [];
	let mr_list = [];
	console.debug('new domain_id ==> ' + domain_id + ' / index ===> ' + s_index);

	let searchIndex =()=> {
		return new Promise(function(resolve,reject) {
			console.debug('[copy_work] searchTrLog - start');

			s_body = {};
			s_body =
			{
			  "query": {
			    "term": {
			      "domain_id.keyword": ""
			    }
			  },
			  "size": 200
			}

			es.client1.search({
				index: s_index,
				body: s_body
			}).then(function (resp) {
				if(resp.hits.total>0) {
					s_result = resp.hits.hits;
					console.check('[searchIndex] count : ' + resp.hits.total);
				}
				return resolve();
			});
		});
	}

	let putIndex =()=> {
		return new Promise(function(resolve,reject) {
			console.debug('[copy_work] putIndex - start');
			let n_domain_id = req.query.domain_id;
			let prefix = n_domain_id + '-'
			let set_bodys = {"body":[]};
			let end_pattern = /^.*_id$/;

			s_result.forEach( el => {

				if(s_index == 'tr_message') {
					if( mr_list.includes(el._id) ) {

					} else {
						return;
					}
				}

				let new_id = prefix + el._id;
				let source = el._source;
				let body_item =
				{
					"_index": s_index,
					"_type": 'doc',
					"_id": new_id
				}

				let keys = Object.keys(source);

				keys.forEach( k_el => {
					let el_value = source[k_el];
					let e_type = typeof el_value;

					/*
					1. Object 타입
					*/
					if( e_type == 'object' ) {

						// 1-1. Arrary
						if(Array.isArray(el_value)) {
							let new_el_value = [];
							el_value.forEach( a_el => {
								let s_keys = Object.keys(a_el);

								s_keys.forEach( sk_el => {
									if(sk_el == 'domain_id') {
										a_el[sk_el] = n_domain_id;
									} else if(end_pattern.test(sk_el)) {	// _id 로 끝나는 경우
										a_el[sk_el] = setSourceValue(prefix, a_el[sk_el]);
									}
								});
								new_el_value.push(a_el);
							});
							el_value = new_el_value;

						// 1-2. object
						} else {
							let s_keys = Object.keys(el_value);
							s_keys.forEach( sk_el => {

								if(sk_el == 'domain_id') {
									el_value[sk_el] = n_domain_id;

								} else if(sk_el == 'template_output_id') {

								} else if(el_value[sk_el] == 'undefined') {

								} else if(end_pattern.test(sk_el)) {	// _id 로 끝나는 경우
									el_value[sk_el] = setSourceValue(prefix, el_value[sk_el]);
								} else {
									let obj_val = el_value[sk_el];

									if(Array.isArray(obj_val)) {
										let new_el_value = [];

										obj_val.forEach( a_el => {
											let ss_keys = Object.keys(a_el);

											ss_keys.forEach( sk_el => {
												if(sk_el == 'domain_id') {
													a_el[sk_el] = n_domain_id;
												} else if(sk_el == 'from_intent') {
													a_el[sk_el] = setSourceValue(prefix, a_el[sk_el]);
												} else if(sk_el == 'from_message') {
													a_el[sk_el] = setSourceValue(prefix, a_el[sk_el]);
												} else if(end_pattern.test(sk_el)) {	// _id 로 끝나는 경우
													a_el[sk_el] = setSourceValue(prefix, a_el[sk_el]);
												}
											});
										});

									} else {
										// console.check(sk_el + ' => ');
										// console.error('226 else !!')
									}
								}
							});
						}

					/*
					2. string 타입
					*/
					} else if ( e_type == 'string' ){
						if(k_el == 'id') {
							source[k_el] = new_id;
						} else if(k_el == 'template_output_id') {

						} else if(k_el == 'domain_id') {
							source[k_el] = n_domain_id;
						} else if(end_pattern.test(k_el)) {
							source[k_el] = setSourceValue(prefix,source[k_el]);
						}
					} else {
						console.error('OTHER TYPE : ' + e_type);
					}
					if(s_index == 'tr_message') {
						source['domain_id'] = n_domain_id;
					}

				});

				set_bodys.body.push({"index":body_item});
				set_bodys.body.push(source);
			});

			// console.check('set_bodys : ' + JSON.stringify(set_bodys));
			// console.check('==============================================');

			es.client1.bulk(set_bodys)
			.then(function (resp) {
				body = {result:resp};
				return resolve();
			}, function(err){
				err.status = 400;
				res.status(400).send(util.res_err(req, 400, err.message));
				console.error(err.message,filename);
				return resolve();
			});
		});
	}

	let copyIndex =()=> {
		return new Promise(function(resolve,reject) {
			console.debug('[copy_work] putIndex - start');
			let n_domain_id = req.query.domain_id;
			let set_bodys = {"body":[]};

			s_result.forEach( el => {

				let new_id = el._id;
				let source = el._source;
				let body_item =
				{
					"_index": s_index,
					"_type": 'doc',
					"_id": new_id
				}

				let keys = Object.keys(source);

				keys.forEach( k_el => {
					let el_value = source[k_el];
					let e_type = typeof el_value;

					/*
					2. string 타입
					*/
					if ( e_type == 'string' ){
						if(k_el == 'domain_id') {
							source[k_el] = "trdomain20181204T1649474290000";
						}
					} else {
						console.error('OTHER TYPE : ' + e_type);
					}
				});

				set_bodys.body.push({"index":body_item});
				set_bodys.body.push(source);
			});
			/*
			console.check('set_bodys : ' + JSON.stringify(set_bodys));
			console.check('==============================================');
			*/

			es.client1.bulk(set_bodys)
			.then(function (resp) {
				body = {result:resp};
				return resolve();
			}, function(err){
				err.status = 400;
				res.status(400).send(util.res_err(req, 400, err.message));
				console.error(err.message,filename);
				return resolve();
			});
			resolve();
		});
	}

	await searchIndex();
	await copyIndex();
	// await putIndex();


	function setSourceValue(prefix, value) {
		let retVal = '';
		if(value == '' || value == undefined) {

		} else {
			retVal = prefix + value;
		}
		return retVal;
	}
}

let copy_paramcheck = function(req,res){
	return new Promise(function(resolve, reject){
		console.debug('[menumatch] sample_paramcheck - start');
		let err = req.validationErrors();
		if(err) {
			err.status = 400;
			res.status(400).send(util.res_err(req, 400, err[0].msg));
			console.error(err[0].msg,filename);
			return reject();
		}else{
			req.query.domain_id = req.query.domain_id || "";
			req.query.s_index = req.query.s_index || "";
			console.debug('[sample_paramcheck] req.query.domain_id : ' + req.query.domain_id);
			console.debug('[sample_paramcheck] req.query.s_index : ' + req.query.s_index);
			return resolve();
        }
	});
};

let copy_sendresult = async(req,res)=>{
	console.debug('[sample] copy_sendresult - start');

    let getSendResult =()=>{
		return new Promise(function(resolve, reject){
			console.debug('copy_sendresult > getSendResult - start');
			res.set({'Content-Type': 'text/json; charset=utf-8'});
			let messageObj =
			{
				hi : {
					its : "good"
				}
			}
			res.send(messageObj);
			return resolve();
		});
	}

	await getSendResult();
};


//***********************************************************************************************************
//  Process Logic Area (E)
//***********************************************************************************************************

let _promise_checktime = function(name){
	return new Promise(function(resolve, reject){
        // elapsed time
        end = new Date();
        elapsed[name] = (end - start) + ' ms';
        console.debug('_promise_checktime ! - '+name+' ['+elapsed[name]+']');
        return resolve();
    });
};

let _promise_errhandler = function(req,res,err){
	return new Promise(function(resolve, reject){
		if(typeof(err) != 'undefined'){
			console.error(err,filename);
		    //res.status(500).send(util.res_err(req, 500, err.message));

		    res.status(err.status || 500);
		    res.render('error', {
		    	message: err.message,
		    	error: err
		    });
		    return resolve();
		}else{
			return resolve();
		}
	});
};

module.exports = router;
