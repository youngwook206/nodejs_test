var express = require('express');
var router = express.Router();
var path = require('path');
var filename = path.basename(__filename);
var approot = require('app-root-path');
var util = require(approot + '/util/util');
var config = require(approot + '/config/config');
var clonedeep = require('lodash.clonedeep');
var uc = require(approot + '/util/unit_changer');

// elapsed time
var elapsed = {};
var start, end;

var match_list = [];

// result
var s_result = [];
var a_result = {};

// elasticsearch
var es = require(approot + '/util/es');
var request_list = [];
var request_set = [];
var response_set = [
	{"name":"회사명","field":"company","value":[],"type":"string"},
	{"name":"공고명","field":"title","value":[],"type":"string"},
	{"name":"연봉","field":"sal","value":[],"type":"string"},
	{"name":"주소","field":"region","value":[],"type":"string"},
	{"name":"상세링크","field":"wantedInfoUrl","value":[],"type":"string"}
];
var add_parameter = [];
var recall_parameters = [];
var sce_param_obj = [];
var search_total_cnt = 0;
var recommend_condition = "";


//***********************************************************************************************************
//  Process Logic : condition 체크
//***********************************************************************************************************
/* GET checkWantedParam */
router.get('/resetConditionInPrompt', function(req, res) {
	resetCondition_handler(req, res);
});

/* POST checkWantedParam */
router.post('/resetConditionInPrompt', function(req, res) {
	resetCondition_handler(req, res);
});


// -- promiss handler
var resetCondition_handler = function(req,res){

	//util.req_param('[리셋] 컨디션 파라미터',req,filename);
	elapsed = {};
	start = new Date();
	if(req.method == "POST") req.query = req.body;

	Promise
	.all([resetCondition_paramcheck(req,res)])
	.then(function(){return _promise_checktime('paramcheck');})

	.then(function(){return resetCondition_work(req,res);})
	.then(function(){return _promise_checktime('resetCondition');})

	.then(function(){return resetCondition_sendresult(req,res);})
	.catch(function(err){return _promise_errhandler(req,res,err);})
	;
};


var resetCondition_paramcheck = function(req,res){
	return new Promise(function(resolve, reject){
		var err = req.validationErrors();
		if(err) {
			err.status = 400;
			res.status(400).send(util.res_err(req, 400, err[0].msg));
			console.error(err[0].msg,filename);
			return reject();
		}else{
			req.query.intent_id = req.query.intent_id || '';
			add_parameter = [];
			// req.query.intent_id = 'trintent20181213T1744238280000';
			return resolve();
        }
	});
};


var resetCondition_work = async(req)=>{
	//console.log('[resetCondition_work] start');

	sce_param_obj = req.query.sce_param;
	let param_obj = req.query.by_pass_param;
	// let aw_type = req.query.aw_type;
	let isE = false;


	var checkResponseType  = function(req,res){
		return new Promise(function(resolve, reject){
			param_obj.forEach( el => {
				if(el.status == 'E') {
					isE = true;
				}
			});
			if( !isE ) console.error('[resetConditionInPrompt] anwer일때 resetConditionInPrompt 실행 오류')
			return resolve();
		});
	}

	var resetCondition  = function(req,res){
		return new Promise(function(resolve, reject){

			param_obj.forEach( el => {
				var el_key = el.key.toString();
				if( isE && el_key == 'condition' ) {
					el.value = '';
					el.codeValue = '';
					el.status = 'R';
				}
			});

			sce_param_obj.forEach( el => {
				let s_params = el.params;
				s_params.forEach( s_el => {
					var s_el_key = s_el.key.toString();
					if( s_el_key.toLocaleLowerCase() == 'condition' ) {
						s_el.value = '';
						s_el.codeValue = '';
						s_el.status = 'R';
					}
				});
			});

			return resolve();
		});
	}

	var checkParameters = function(req,res){
		return new Promise(function(resolve, reject){
			recall_parameters = param_obj;
			req.query.recall_type = 'by_pass';
			sce_param_obj.forEach( el => {
				if( el.intent_id == req.query.intent_id ) el.params = recall_parameters;
			});
			resolve();
		});
	}

	if(req.query.condition !='init' ) {
		await checkResponseType(req);
		await resetCondition(req);
		await checkParameters(req);
	}
}


var resetCondition_sendresult = function(req,res){
	return new Promise(function(resolve, reject){
		//console.log('resetCondition_sendresult');

		request_set = [];
		response_set = [];

		res.set({'Content-Type': 'text/json; charset=utf-8'});
		let messageObj =
		{
			recall_inform : {
				recall_parameters : recall_parameters,
				scenario_parameters : sce_param_obj,
				recall_type : req.query.recall_type,
				response_type : "prompt"
			},

			id : "worknet_resetCondition",
			name : "[prompt] condition 파라미터 리셋",
			description : "delete parameter reset",
			request :request_set,
			mapping_info:response_set,
			response :
					{
						items: response_set
					},
			script: {
						type : "url",
						script_code: ""
			  		}
		}

		res.send(messageObj);
		return resolve();
	});
};



//***********************************************************************************************************
//  Process Logic : 구직정보 파라미터 체크
//***********************************************************************************************************
/* GET checkWantedParam */
router.get('/getResume', function(req, res) {
	getResume_handler(req, res);
});

/* POST checkWantedParam */
router.post('/getResume', function(req, res) {
	getResume_handler(req, res);
});


// -- promiss handler
var getResume_handler = function(req,res){
	//util.req_param('[구직정보] 파라미터 체크',req,filename);
	console.debug('[wanted.js] 구직정보 파라미터 체크 Function Start');
	elapsed = {};
	start = new Date();
	if(req.method == "POST") req.query = req.body;

	Promise
	.all([getResume_paramcheck(req,res)])
	.then(function(){return _promise_checktime('paramcheck');})

	.then(function(){return getResume_work(req,res);})
	.then(function(){return _promise_checktime('wantedApi');})

	.then(function(){return getResume_sendresult(req,res);})
	.catch(function(err){return _promise_errhandler(req,res,err);})
	;
};


var getResume_paramcheck = function(req,res){
	return new Promise(function(resolve, reject){
		var err = req.validationErrors();
		if(err) {
			err.status = 400;
			res.status(400).send(util.res_err(req, 400, err[0].msg));
			console.error(err[0].msg,filename);
			return reject();
		}else{
			req.query.user_id = req.query.user_id || '';
			add_parameter = [];
			return resolve();
        }
	});
};


var getResume_work = async(req)=>{
	// console.log('[getResume_work] start');
	sce_param_obj = req.query.sce_param;
	let param_obj = clonedeep(req.query.by_pass_param);
	let user_id = req.query.user_id;
	let isValidParam = true;

	let job_cd = "";
	let region_cd = "";
	let salary_min = "";

	let job_nm = "";
	let region_nm = "";
	let salary_value = "";

	let sal_tp_cd = "";
	let readjust_poss_yn = "";

	let resume_obj = {};



	let searchJobCd = async function(req, keyword){
        return new Promise(function(resolve, reject){
			console.debug('[resume] searchJobCd - start');

            let s_body =
            {
                size:10,
                query : {
                        bool : {
                            must : [ {
                                simple_query_string : {
                                    query : keyword,
                                    fields : [
										"jobname",
                                        "rel_jobname"
                                      ],
                                    default_operator : "AND"
                                }
                            } ]
                        }
                    },
                _source:"code"
            }

            console.debug("[WORKNET searchJobCd] s_body : " + JSON.stringify(s_body));
            es.client1.search({
                index: "wn_jobcode",
                body: s_body
            }).then(function (resp) {
                s_result = resp.hits.hits;
                console.debug('[WORKNET searchJobCd] JOB TOTAL : ' + resp.hits.total);
                if(resp.hits.total > 0) {
                    let jobCd = "";
					let elCode = "";
                    s_result.forEach( el => {
						elCode = el._source.code.toString();
						if(util.chkDigitNumber(elCode, 6)) jobCd += elCode+'|';
                    });
                    job_cd = jobCd;
					job_cd = util.sliceLastSC(job_cd, '|');
                }
                return resolve();
            }, function (err) {
                err.status = 400;
                res.status(400).send(util.res_err(req, 400, err.message));
                console.error(err.message,filename);
                return resolve();
            });
        });
    }

	let getRegionCode = function(req, region) {
	    return new Promise(function(resolve, reject) {
	        console.debug('[resume] getRegionCode - start');

			let s_body = {};
	        if(region != "") s_body =
			{
			  query: {
			    simple_query_string: {
			      query: region,
			      fields: [
			        "region"
			      ],
			      default_operator: "and"
			    }
			  },
			  size:1,
			  sort: [
			    {
			      code: {
			        order: "asc"
			      }
			    }
			  ]
			}
	        console.debug("[getRegionCode] s_body : " + JSON.stringify(s_body));

	        es.client1.search({
				index: "wn_region",
	            body: s_body
	        }).then(function (resp) {
	            s_result = resp.hits.hits;
				if(resp.hits.total > 0) {
					region_cd = s_result[0]._source.code;
				} else {
					region_cd = "";
				}
	            return resolve();
	        }, function (err) {
				err.status = 400;
				res.status(400).send(util.res_err(req, 400, err.message));
				console.error(err.message,filename);
				return resolve();
			});
	    });
	}

	let getSalaryMin = function(req, salary) {
		return new Promise(function(resolve, reject) {
	        console.debug('[wanted] getSalaryMin - start');

			salary_min = util.getRealSalary(salary, sal_tp_cd, readjust_poss_yn);

			return resolve();
		});
	}

	let getResumeInstance = function(req) {
		return new Promise(function(resolve, reject) {
			console.debug('[wanted] getResumeInstance - start');

			if(user_id!='') {
				var req_promise = require('request-promise');
				var req_param = {
		            method: 'POST',
		            uri: "",
		            body: "",
		            headers: {
		              'Content-Type': 'application/json'
		            },
		            json: false
		        };
				req_param.body = JSON.stringify( {"user_id":user_id} );
				req_param.uri = config.work_resume_url;

				return req_promise(req_param,function(e,v,item){
					try{
						item = JSON.parse( item );
						if(item.status.code == 200) {
							resume_obj = item.resume;
						}
						resolve();
					}catch(e){
						console.error(config.work_resume_url+' 실행에러!!!');
						console.error(e);
						resolve();
					}
				});
			} else {
				console.error('user id 도 없고 충족된 파라미터도 하나도 없음');
				resolve();
			}
		});
	}

	let checkResumeResult = function(req) {
		return new Promise(function(resolve, reject) {
			console.debug('checkResumeResult - start');

			if( JSON.stringify(resume_obj) == '{}' ) {
				console.error('[checkResumeResult] resume_obj is empty');
			} else {
				job_cd = resume_obj.hope_jobs_1_cd;
				if(job_cd != '') job_cd += '|'+resume_obj.hope_jobs_2_cd;
				if(job_cd != '') job_cd += '|'+resume_obj.hope_jobs_3_cd;
				job_cd = util.sliceLastSC(job_cd, '|');

				job_nm = resume_obj.hope_jobs_1_nm;
				if(job_nm != '') job_nm += '|'+resume_obj.hope_jobs_2_nm;
				if(job_nm != '') job_nm += '|'+resume_obj.hope_jobs_3_nm;
				job_nm = util.sliceLastSC(job_nm, '|');

				region_cd = resume_obj.hope_region_1_cd;
				if(region_cd != '') region_cd += '|'+resume_obj.hope_region_2_cd;
				if(region_cd != '') region_cd += '|'+resume_obj.hope_region_3_cd;
				region_cd = util.sliceLastSC(region_cd, '|');

				region_nm = resume_obj.hope_region_1_nm;
				if(region_nm != '') region_nm += '|'+resume_obj.hope_region_2_nm;
				if(region_nm != '') region_nm += '|'+resume_obj.hope_region_3_nm;
				region_nm = util.sliceLastSC(region_nm, '|');

				if(resume_obj.sal_tp_cd!='') sal_tp_cd = resume_obj.sal_tp_cd;

				salary_value = resume_obj.hope_sal;
				readjust_poss_yn = resume_obj.readjust_poss_yn;
				salary_min = util.getRealSalary(salary_value, sal_tp_cd, readjust_poss_yn);

				console.debug(`[checkResumeResult] job_cd:${job_cd}, region_cd:${region_cd}, salary_min:${salary_min}, readjust_poss_yn:${readjust_poss_yn}`);


				if(readjust_poss_yn == 'Y') {
					add_parameter.push({ key:'readjust_poss_yn', value:'Y', id:"readjust_poss_yn", status:"", required:"N"});
				} else {
					add_parameter.push({ key:'readjust_poss_yn', value:'N', id:"readjust_poss_yn", status:"", required:"N"});
				}

				if((job_nm=='' && job_cd=='') && region_cd=='' && salary_min=='') {
					isValidParam = false;
				} else {
					isValidParam = true;
				}
			}
			resolve();
		});
	}


	if(param_obj != undefined){
		console.debug('param_obj != undefined');

		for (const el of param_obj) {
			if(el.key == '임금_구분' && el.value != '') {
				sal_tp_cd = el.value;
			}
		}

		for (const el of param_obj) {
			if(el.key == '희망직종') {
				job_nm = el.value;
				if(job_nm != "") {
					await searchJobCd(req, el.value);
				}
			}
			if(el.key == '희망지역') {
				region_nm = el.value;
				if(region_nm != "") {
					await getRegionCode(req, el.value);
				}
			}

			if(el.key == 'system.amount') {
				console.debug('system.amount ==========> salary_value : ' + salary_value);
				salary_value = el.value;
				if(salary_value != '') {
					console.error('system.amount - salary_value is not null');
					await getSalaryMin(req, el.value);
				}
			}
	    }

		console.debug('[getResume_work] job_cd : ' + job_cd + ' / region_cd : ' + region_cd + ' / salary_min : ' + salary_min);


		if((job_nm=='' && job_cd=='') && region_cd=='' && salary_min=='') isValidParam = false;

		if(!isValidParam) {
			await getResumeInstance(req);
			await checkResumeResult(req);
		}

		let checkParameters = function(req, region) {
		    return new Promise(function(resolve, reject) {
				recall_parameters = assignValue(param_obj);

				req.query.recall_type = 'recall';
				let isActiveEl = 'N';   // paramter E

				if(readjust_poss_yn == 'Y') {
					recall_parameters.forEach( el => {
						if(el.key == '임금_구분' && el.value == '') {
							el.value = 'Y';
							el.status = 'C';
						}
					});
				}

				recall_parameters.forEach( el => {
					if(isActiveEl == 'N' && el.required == 'Y' && el.codeValue == '') {
						if(el.key == '희망직종' && el.value != '') {
						} else if(el.key == '임금_구분' && el.value != '') {

						} else {
							el.status = 'E';
		                    isActiveEl = 'Y';
						}
	                }
				});

				recall_parameters.forEach( el => {
					if( el.status == 'C') {
						sce_param_obj.forEach( s_el => {
							let s_params = s_el.params;
							s_params.forEach( ss_el => {
								if( ss_el.key == el.key ) {
									ss_el.value = el.value;
									ss_el.codeValue = el.codeValue;
									ss_el.status = 'C';
								}
							})
						})
					}
				});

				return resolve();
			});
		}

		await checkParameters(req);

		function assignValue(paramObj) {
			let r_param_obj = [];
			for(let i=0; i<paramObj.length; i++) {
				let el = paramObj[i];
				if( el.key == '희망직종') {
					if(job_cd != '') {
						el.value = job_nm;
						el.codeValue = job_cd;
						el.status = 'C';
					} else {
						if( el.value != '' ) {
							el.codeValue = '';
							el.status = 'C';
						} else {
							el.codeValue = '';
							el.status = 'R';
						}
					}
				}
				if( el.key == '희망지역') {
					el.value = region_nm;
					el.codeValue = region_cd;
					if(region_cd != '') {
						el.status = 'C';
					} else {
						el.status = 'R';
					}
				}
				if( el.key == 'system.amount') {
					salary_min = salary_min.toString();

					if(salary_min != '') {
						el.value = salary_value.toString();
						el.codeValue = salary_min;
						el.status = 'C';
					} else {
						el.value = '';
						el.codeValue = '';
						el.status = 'R';
					}
				}

				if( el.key == '임금_구분') {
					if(sal_tp_cd != '') {
						el.value = sal_tp_cd;
						el.codeValue = '';
						el.status = 'C';
					} else {
						el.value = '';
						el.codeValue = '';
						el.status = 'R';
					}
				}

				// console.error('assignValue ===========================================================> isValidParam : ' + isValidParam);

				if( el.key == 'parameter_yn') {
					let parameter_yn = "";
					if(isValidParam) { parameter_yn = 'true'; } else { parameter_yn = 'false'; };
					el.value = parameter_yn;
					el.codeValue = parameter_yn;
					el.status = 'C';
				}
				r_param_obj.push( el );
			}

			return r_param_obj;
		}
	}

}


var getResume_sendresult = function(req,res){
	return new Promise(function(resolve, reject){
		console.debug('getResume_sendresult');

		request_set = [];
		response_set = [];

		res.set({'Content-Type': 'text/json; charset=utf-8'});
		let messageObj =
		{
			recall_inform : {
				recall_parameters : recall_parameters,
				scenario_parameters : sce_param_obj,
				recall_type : req.query.recall_type,
				response_type : "answer"
			},

			id : "worknet_getResume",
			name : "[구직정보] 파라미터 체크",
			description : "return parameter_yn",
			request :request_set,
			mapping_info:response_set,
			response :
					{
						items: response_set
					},
			script: {
						type : "url",
						script_code: ""
			  		},
			add_parameter: add_parameter
		}

		// console.error(JSON.stringify(messageObj));

		res.send(messageObj);
		return resolve();
	});
};




//***********************************************************************************************************
//  Process Logic : 채용정보 검색
//***********************************************************************************************************
/* GET users listing. */
router.get('/callWantedApi', function(req, res) {
	wantedApi_handler(req, res);
});

/* POST users listing. */
router.post('/callWantedApi', function(req, res) {
	wantedApi_handler(req, res);
});


// -- promiss handler
var wantedApi_handler = function(req,res){
	console.debug('[wanted.js] API연동 - 채용정보 검색 Function Start');
	//util.req_param('[API연동] 채용정보 검색',req,filename);
	elapsed = {};
	start = new Date();
	if(req.method == "POST") req.query = req.body;

	Promise
	.all([wantedApi_paramcheck(req,res)])
	.then(function(){return _promise_checktime('paramcheck');})

	.then(function(){return wantedApi_work(req,res);})
	.then(function(){return _promise_checktime('wantedApi');})

	.then(function(){return wantedApi_sendresult(req,res);})
	.catch(function(err){return _promise_errhandler(req,res,err);})
	;
};


var wantedApi_work = async(req)=>{

	let s_result = {};
	let org_param_obj = clonedeep(req.query.by_pass_param);
	let param_obj = clonedeep(req.query.by_pass_param);
	sce_param_obj = req.query.sce_param;

	let c_param_occupation = "";
	let c_param_region = "";
	let c_param_salary_min = '';
	let job_cd = "";
	let region_cd = "";
	let salary_min = '';
	let sal_tp_cd = '';
	let readjust_poss_yn = "";

	let checkCodeValue = function(req) {
		return new Promise(function(resolve, reject) {
			if( org_param_obj != undefined ) {
				org_param_obj.forEach( el => {
					if(el.key == '희망직종' && el.codeValue != '') {
						job_cd = el.codeValue;
					}
					if(el.key == '희망지역' && el.codeValue != '') {
						region_cd = el.codeValue;
					}
					if(el.key == 'system.amount' && el.codeValue != '') {
						salary_min = el.codeValue;
					}

				})
			}
			resolve();
		});
	}

    let callWantedApi = function(req) {
        return new Promise(function(resolve, reject) {

            let http = require('http');
            let xml2js = require('xml2js');
            let urlencode = require('urlencode');
            let parser = new xml2js.Parser();

            parser.on('error', function(err) {
                console.error('Parser error', err);
            });

			let apiHost = config.work_openapi_url;
    		let authKey = config.work_openapi_key;
    		let callTp = "L";
    		let returnType = "xml";
    		let startPage = "1";
    		let display = "10";
            let occupation_keyword = '';
			let api_sal_tp_cd = sal_tp_cd;
			if(api_sal_tp_cd == '') api_sal_tp_cd = 'Y';

			if( org_param_obj != undefined ) {
				org_param_obj.forEach( el => {
					if(el.key == '희망직종') occupation_keyword = el.value;
				});

	    		let callUrl = `${apiHost}?authKey=${authKey}&callTp=${callTp}&returnType=${returnType}&startPage=${startPage}&display=${display}`;
				if(job_cd != '') {
					callUrl += `&occupation=${job_cd}`;
				} else {
					callUrl += `&keyword=${urlencode(occupation_keyword)}`;
				}
				if(region_cd != '') {
					let api_region_cd="";
					if(region_cd=='00000') {
						api_region_cd="";
					} else {
						api_region_cd=region_cd;
					}
					callUrl += `&region=${api_region_cd}`;
				}
				if(salary_min != '') {
					let api_salary_min = 0;
					api_salary_min = util.getApiSalary(c_param_salary_min, sal_tp_cd, readjust_poss_yn);
					if(api_salary_min.indexOf('.')>-1) {
						api_salary_min = api_salary_min.split('.')[0];
					}

					if( readjust_poss_yn != 'Y' ) {
						callUrl += `&salTp=${api_sal_tp_cd}&minPay=${api_salary_min}`;
					}
				}

				// console.log('[OPENAPI] WORKNET OPENAPI =====> ' + callUrl);

	            let data = '';
				if(req.query.response_type == 'answer') {
					console.debug('파라미터 조건 충족하여 wantedApi 검색 실행');
					try {

						http.get(callUrl, function(res) {
							if(res.statusCode >= 200 && res.statusCode < 400) {
								res.on('data', function(data_) {
	  		                        data += data_.toString();
	  		                    });
	  		                    res.on('end', function() {
									if(data.startsWith( '<?xml version' )) {
										parser.parseString(data, function(err, result) {
		  		                            a_result = result;
		  									resolve();
		  		                        });
									} else {
										console.error('data ERROR !!!!');
										a_result = {};
										resolve();
									}
	  		                    });
	  		                } else {
	  						  	a_result = {};
	  					      	resolve();
							}
			            });

					} catch(err) {
						console.error(callUrl + '호출 에러 !!');
						console.error( err );
						a_result = {};
						resolve();
					}

				} else {
					a_result = {};
					resolve();
				}
			} else {
				if( req.query.condition == 'init' ) {
					return resolve();
				}
			}

        });
    }

	let searchJobCd = async function(req, keyword){
        return new Promise(function(resolve, reject){

            let s_body =
            {
                size:15,
                query : {
                        bool : {
                            must : [ {
                                simple_query_string : {
                                    query : keyword,
                                    fields : [
                                      "jobname",
                                      "rel_jobname"
                                      ],
                                    default_operator : "AND"
                                }
                            } ]
                        }
                    },
                _source:"code"
            }
            // console.debug("[WORKNET searchJobCd] s_body : " + JSON.stringify(s_body));
            es.client1.search({
                index: "wn_jobcode",
                body: s_body
            }).then(function (resp) {
                s_result = resp.hits.hits;
                console.debug('[WORKNET searchJobCd] JOB TOTAL : ' + resp.hits.total);
                if(resp.hits.total > 0) {
                    let jobCd = "";
					let elCode = "";
                    s_result.forEach( el => {
						elCode = el._source.code.toString();
						if(util.chkDigitNumber(elCode, 6)) jobCd += elCode+'|';
                    });

                    job_cd = jobCd;
					if(job_cd.charAt( job_cd.length-1 ) == "|") {
						job_cd = job_cd.replace('||', '|');
						job_cd = job_cd.slice(0, -1);
					}
                }
                return resolve();
            }, function (err) {
                err.status = 400;
                res.status(400).send(util.res_err(req, 400, err.message));
                console.error(err.message,filename);
                return resolve();
            });
        });
    }

	let getRegionCode = function(req, region) {
	    return new Promise(function(resolve, reject) {

			let s_body = {};
	        if(region != "") s_body =
			{
			  query: {
			    simple_query_string: {
			      query: region,
			      fields: [
			        "region"
			      ],
			      default_operator: "and"
			    }
			  },
			  size:1,
			  sort: [
			    {
			      code: {
			        order: "asc"
			      }
			    }
			  ]
			}
	        console.debug("[getRegionCode] s_body : " + JSON.stringify(s_body));

	        es.client1.search({
				index: "wn_region",
	            body: s_body
	        }).then(function (resp) {
				//console.log('[WORKNET getRegionCode] REGION TOTAL : ' + resp.hits.total);
	            s_result = resp.hits.hits;
				if(resp.hits.total > 0) {
					region_cd = s_result[0]._source.code;
				} else {
					region_cd = "";
				}
	            resolve();
	        }, function (err) {
				console.error('getRegionCode ERROR');
				err.status = 400;
				res.status(400).send(util.res_err(req, 400, err.message));
				console.error(err.message,filename);
				return resolve();
			});
	    });
	}

	let getSalaryMin = function(req, salary) {
		return new Promise(function(resolve, reject) {

			salary_min = util.getRealSalary(salary, sal_tp_cd, '');
			return resolve();
		});
	}

	let checkParameters = function(req, region) {
	    return new Promise(function(resolve, reject) {

			recall_parameters = assignValue(param_obj);
			req.query.response_type = 'answer';
			let isActiveEl = 'N';   // paramter E
			recall_parameters.forEach( el => {
				if(isActiveEl == 'N' && el.required == 'Y' && el.codeValue == '') {
					if(el.key == '희망직종' && el.value != '') {

					} else if(el.key == '임금_구분' && el.value != '') {

					} else {
						el.status = 'E';
						isActiveEl = 'Y';
						req.query.response_type = 'prompt';
					}
				}
			});

			if(req.query.response_type == 'prompt') {
				req.query.recall_type = 'recall';
			} else {
				req.query.recall_type = 'by_pass';
			}


			recall_parameters.forEach( el => {
				if( el.status == 'C') {
					sce_param_obj.forEach( s_el => {
						let s_params = s_el.params;
						s_params.forEach( ss_el => {
							if( ss_el.key == el.key ) {
								ss_el.value = el.value;
								ss_el.codeValue = el.codeValue;
								ss_el.status = 'C';
							}
						})
					})
				}
			})

			return resolve();
		});
	}

	var chkRecommedInfo =(req)=>{

		var user_id_flag = false;
	    var recommend_flag = false;
        recommend_condition = "";

        if(req.query.req_parameters != undefined){
            var parameters = req.query.req_parameters;
            var param_obj = JSON.parse(parameters);
            if(param_obj.recommend != undefined){
                param_obj.recommend.forEach((s_item)=>{
                    var count = s_item.count;
                    var v_name = s_item.name;
					if(v_name == "채용"){
						if(count > 0) recommend_flag = true;
					}
                });
            }
        }
        if(req.query.user_id != undefined){
            if(req.query.user_id != "") user_id_flag = true;
        }
        if(recommend_flag) {
			recommend_condition = "개인추천";
		}else{
			recommend_condition = "";
		}
		checkRecommedParameters(req);

    }

	var checkRecommedParameters = (req)=> {
    	param_obj = clonedeep(req.query.by_pass_param);
    	sce_param_obj = req.query.sce_param;

        return new Promise(function(resolve, reject){

			recall_parameters.forEach((p_item)=>{
                if(p_item.key == "condition"){
					if(p_item.value == ""){
						p_item.value = recommend_condition;
					}
				}
            });

			req.query.recall_type = 'recall';
            if(sce_param_obj != undefined){
                sce_param_obj.forEach( el => {
                    if( el.intent_id == req.query.intent_id ) el.params = recall_parameters;
                });
            }
			resolve();
		});
	}

	if(sce_param_obj != undefined) {
		for(const el of sce_param_obj) {
			let params = el.params;
			if(el.step == '0') {
				params.forEach(p_el => {
					if(p_el.key == 'readjust_poss_yn') {
						readjust_poss_yn = p_el.value;
					}
				});
			}
		}
	}

	if(param_obj != undefined){

		for(const el of param_obj) {
			if(el.key == '임금_구분') sal_tp_cd = el.value;
		}

		for (const el of param_obj) {
            if(el.key == '희망직종' && el.value != "" && el.codeValue == "") {
				c_param_occupation = el.value;
                await searchJobCd(req, el.value);
            }
			if(el.key == '희망지역' && el.value != "" && el.codeValue == "") {
				// console.error( 'param_obj > 희망지역 : ' + JSON.stringify(el) );
				c_param_region = el.value;
				await getRegionCode(req, el.value);
			}
			if(el.key == 'system.amount' && el.value != "") {
				// console.check('system.amount : ' + el.value);
				c_param_salary_min = el.value + '';
				await getSalaryMin(req, el.value);
			}
	    }

		await checkCodeValue(req);
		await checkParameters(req);
	    await callWantedApi(req);
		await chkRecommedInfo(req);
	}



	function assignValue(paramObj) {
		let r_param_obj = [];
		for(let i=0; i<paramObj.length; i++) {
			let el = paramObj[i];
			if( el.key == '희망직종') {
				if(c_param_occupation != '') {
					//el.value = c_param_occupation;
					el.codeValue = job_cd;
					el.status = 'C';
				}
			}
			if( el.key == '희망지역') {
				if(region_cd != '') {
					//el.value = c_param_region;
					el.codeValue = region_cd;
					el.status = 'C';
				} else {
					//el.value = c_param_region;
					el.codeValue = region_cd;
					el.status = 'R';
				}
			}

			if( el.key == '임금_구분') {
				if(sal_tp_cd != '') {
					el.value = sal_tp_cd;
					el.codeValue = '';
					el.status = 'C';
				} else {
					el.value = '';
					el.codeValue = '';
					el.status = 'R';
				}
			}

			if( el.key == 'system.amount') {
				salary_min = salary_min.toString();
				if(salary_min != '') {
					//el.value = salary_min;
					el.codeValue = salary_min;
					el.status = 'C';
				} else {
					//el.value = '';
					el.codeValue = '';
					el.status = 'R';
				}
			}
			r_param_obj.push( el );
		}

		return r_param_obj;
	}
}


var wantedApi_paramcheck = function(req,res){
	return new Promise(function(resolve, reject){
		var err = req.validationErrors();
		if(err) {
			err.status = 400;
			res.status(400).send(util.res_err(req, 400, err[0].msg));
			console.error(err[0].msg,filename);
			return reject();
		}else{
            req.query.keyword = req.query.keyword || '';
            req.query.region = req.query.region || '';
			req.query.response_type = 'answer';
			add_parameter = [];
			return resolve();
        }
	});
};

var chkSalValue =(str)=>{
	var salArr = [];
	var gb_sal = "";
	if(str.indexOf("만원")!=-1){
		gb_sal = "만원";
	}else{
		gb_sal = "원";
	}
	var retSal = "";
	if(str.indexOf("~") !=-1){
		salArr = str.split("~");
		salArr.forEach((s_item,idx)=>{
			s_item = s_item.trim();
			s_item = s_item.replace(gb_sal,"");
			s_item = util.numberFormatType(s_item);
			if(idx==salArr.length-1) retSal += " ~ ";
			retSal += s_item+gb_sal;
		});
	}else{
		var s_item = str.replace(gb_sal,"");
		s_item = util.numberFormatType(s_item);
		retSal += s_item+gb_sal;
	}
	return retSal;
}

var wantedApi_sendresult = function(req,res){
	return new Promise(function(resolve, reject){

		var request_set = [
			{"name":"회사명","field":"company","value":[],"type":"string"},
			{"name":"공고명","field":"title","value":[],"type":"string"}
		]
		response_set = [
			{"name":"회사명","field":"company","value":[],"type":"string"},
			{"name":"공고명","field":"title","value":[],"type":"string"},
			{"name":"연봉","field":"sal","value":[],"type":"string"},
			{"name":"주소","field":"region","value":[],"type":"string"},
			{"name":"상세링크","field":"wantedInfoUrl","value":[],"type":"string"}
		];


		res.set({'Content-Type': 'text/json; charset=utf-8'});
		let messageObj =
		{
			recall_inform : {
				recall_parameters : recall_parameters,
				scenario_parameters : sce_param_obj,
				recall_type : req.query.recall_type,
				response_type : req.query.response_type,
				search_total_cnt : search_total_cnt
			},
			id : "worknet_callJobApi",
			name : "채용 조회 API 연동",
			description : "call wantedApi",
			request :request_set,
			mapping_info:response_set,
			response :
					{
						items: response_set
					},
			script: {
						type : "url",
						script_code: ""
			  		},
			add_parameter: add_parameter
		}

		let result_root = {};
		let isWantedResult=true;

		if( Object.keys(a_result).length == 0 ) {
			isWantedResult=false;
			console.debug('a_result 결과 없음');
		} else {
			result_root = a_result.wantedRoot;
			if(result_root.hasOwnProperty('wanted')) {
				isWantedResult=true;
				console.debug('wantedAPI 조회결과 있음');
			} else {
				if(result_root.messageCd == '006') {
					console.error('wantedAPI 조회결과 없음(messageCd=006)');
					isWantedResult=false;
				}
			}
		}

		if( req.query.condition != 'init' && isWantedResult) {
			var result = result_root.wanted;
			search_total_cnt = result_root.total;
			if(search_total_cnt.length == 1) {
				messageObj.recall_inform.search_total_cnt = search_total_cnt[0];
			}
			var response_item_set = {"items":[]};
			response_set.forEach(v_item=>{
				v_item.value = [];
			});

			var setData = (v_item,element)=>{
				var rs_item={};
				var v_field= v_item.field;
				var set_value = "";
				for(var in_field in element){
					//console.error('=====> in_field : ' + in_field);
					if(in_field == v_field){
						if(in_field == "sal"){
							set_value = chkSalValue(element[in_field][0]);
						}else{
							set_value = element[in_field][0];
						}
					}
				}
				v_item.value.push(set_value);
			}
			result.forEach(element => {
				response_set.forEach((v_item)=>{
					setData(v_item,element);
				});
			});
		}
		if( !isWantedResult ) {
			response_set = [];
		}

		// console.error("[wantedApi_sendresult] messageObj =====> " + JSON.stringify(messageObj.recall_inform,null,2));

		res.send(messageObj);
		return resolve();
	});



};

//***********************************************************************************************************
//  Process Logic Area (E)
//***********************************************************************************************************
var _promise_checktime = function(name){
	return new Promise(function(resolve, reject){
        // elapsed time
        end = new Date();
        elapsed[name] = (end - start) + ' ms';
        //console.debug('_promise_checktime ! - '+name+' ['+elapsed[name]+']');
        return resolve();
    });
};

var _promise_errhandler = function(req,res,err){
	return new Promise(function(resolve, reject){
		if(typeof(err) != 'undefined'){
			console.error(err,filename);
		    //res.status(500).send(util.res_err(req, 500, err.message));

		    res.status(err.status || 500);
		    res.render('error', {
		    	message: err.message,
		    	error: err
		    });
		    return resolve();
		}else{
			return resolve();
		}
	});
};


module.exports = router;
