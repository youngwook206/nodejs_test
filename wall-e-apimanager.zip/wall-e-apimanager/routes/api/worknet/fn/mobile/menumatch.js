const express = require('express');
const router = express.Router();
const path = require('path');
const filename = path.basename(__filename);
const approot = require('app-root-path');
const configfile = require(approot + '/config/config.json');
const config = require(approot + '/config/config');
const util = require(approot + '/util/util');
const clonedeep = require('lodash.clonedeep');
const es = require(approot + '/util/es');

// elapsed time
let elapsed = {};
let start, end;

let s_result = [];
let t_result = [];
let request_set = [];
let response_set = [];
let add_parameter = [];
let param_obj = [];
let sce_param_obj = [];
let recall_parameters = [];
let result_count = 0;


//***********************************************************************************************************
//  Process Logic : 메뉴 매칭
//***********************************************************************************************************
/* GET users listing. */
router.get('/match', function(req, res) {
	match_handler(req, res);
});

/* POST users listing. */
router.post('/match', function(req, res) {
	match_handler(req, res);
});


// -- promiss handler
let match_handler = function(req,res){
	util.req_param('[조회] 메뉴 매칭',req,filename);
	elapsed = {};
	t_result = [];
	start = new Date();
	if(req.method == "POST") req.query = req.body;

	Promise
	.all([menu_matcher_paramcheck(req,res)])
	.then(function(){return _promise_checktime('paramcheck');})
	.then(function(){return menu_matcher_work(req,res);})
	.then(function(){return _promise_checktime('menu_matcher');})
	.then(function(){return menu_matcher_sendresult(req,res);})
	.catch(function(err){return _promise_errhandler(req,res,err);})
	;
};

let menu_matcher_work = async(req,res)=>{
	console.debug('[menumatch] menu_matcher_work - start')
	//const domain_id = req.query.domain_id;
	//const inStr = req.query.in_str;
	const intent_id = req.query.intent_id;
	param_obj = req.query.by_pass_param;
	sce_param_obj = req.query.sce_param;
	let matchQuery = '';
	let chlidList = [];
	let isCardView = false;
	let hasGrandChildMenu = false;
	let menu_depth = 0;

	let apicondition_value = '리스트보기';

	if(param_obj != undefined){
		for (const el of param_obj) {
			if(el.key == '메뉴이름') {
				matchQuery = el.value;
			}
		}
		recall_parameters = param_obj;
	}
	let s_index = "wn_menu_mobile_info";

	let searchMenuNm =()=> {
		return new Promise(function(resolve,reject) {
			console.debug('[menumatch] searchMenuNm - start');
			let s_body;
			let size = 0;
			let sourceList = [];
			let matchObj = {};
			// console.check('param_obj : ' + JSON.stringify(param_obj));

			if(matchQuery!='') {
				size = 1;
				matchObj = { "menu_nm.exact": matchQuery };
				sourceList.push('menu_nm');
				sourceList.push('menu_desc');
				sourceList.push('url');

				s_body =
				{
					size: size,
					sort: {menu_order:{order:'asc'}},
					query: { match: matchObj },
					_source: sourceList
				};
				console.debug('[searchMenuNm] s_body :' + JSON.stringify(s_body));

				es.client1.search({
					index: s_index,
					body: s_body
				}).then(function (resp) {
					if(resp.hits.total>0) {
						s_result = resp.hits.hits;
					}
					return resolve();
				});

			} else {
				resolve();
			}
		});
	}

	let getChildList =()=> {
		return new Promise(function(resolve,reject) {
			console.debug('[menumatch] getChildList - start');

			let s_body;
			let size = 0;
			let sourceList = [];
			let matchObj = {};
			// console.check('param_obj : ' + JSON.stringify(param_obj));

			if(matchQuery!='') {
				console.debug('getChildList 검색 ====================>');
				size = 50;
				matchObj = { "parent_nm.exact": matchQuery };
				sourceList.push('menu_nm');
				sourceList.push('menu_desc');
				sourceList.push('url');
				s_body =
				{
					size: size,
					sort: {menu_order:{order:'asc'}},
					query: { match: matchObj },
					_source: sourceList
				};
				console.debug('[getChildList] s_body :' + JSON.stringify(s_body));

				es.client1.search({
					index: s_index,
					body: s_body
				}).then(function (resp) {
					//console.check('[getChildList] resp.hits.total : ' + resp.hits.total);
					if(resp.hits.total>0) {
						s_result = resp.hits.hits;
						console.debug('getChildList count : ' + resp.hits.total);

						s_result.forEach( el=> {
							chlidList.push( el._source.menu_nm );
						})
					}
					resolve();
				});
			} else {
				resolve();
			}
		});
	}

	let searchGrandChild =()=> {
		return new Promise(function(resolve,reject) {
			console.debug('[menumatch] searchGrandChild - start');

			if(chlidList.length>0) {
				let s_body;
				let size = 0;
				let sourceList = [];
				let matchObj = {};
				let should_list = [];
				chlidList.forEach( el => {
					should_list.push( { match : { "parent_nm.exact" : el } })
				})

				size = 1;
				matchObj = { "parent_nm.exact": matchQuery };
				sourceList.push('menu_nm');
				s_body =
				{
					size: size,
					sort: {menu_order:{order:'asc'}},
					query: { bool: {should : should_list} },
					_source: sourceList
				};

				es.client1.search({
					index: s_index,
					body: s_body
				}).then(function (resp) {
					//console.check('[searchGrandChild] resp.hits.total : ' + resp.hits.total);
					if(resp.hits.total>0) {
						// hasGrandChildMenu = true;
						isCardView = false;
					} else {
						isCardView = true;
					}
					resolve();
				});
			} else {
				isCardView = true;
				resolve();
			}
		});
	}

	let setApiCondition = function(req,res) {
		return new Promise(function(resolve, reject){
			console.debug('[menumatch] setApiCondition - start');

			//console.check('[setApiCondition] isCardView : ' + isCardView);

			// if(isDetailView || !hasGrandChildMenu) {
			if(isCardView) {
				req.query.recall_type = 'recall';
				apicondition_value = "카드보기";
			} else {
				req.query.recall_type = 'by_pass';
			}

			// if(matchQuery!='') req.query.recall_type = 'by_pass';

			recall_parameters.forEach((p_item)=>{
				if(p_item.key == "apicondition") p_item.value = apicondition_value;
			});

			if(sce_param_obj != undefined){
				sce_param_obj.forEach( el => {
					if( el.intent_id == req.query.intent_id ) el.params = recall_parameters;
				});
			}

			resolve();
		});
	}

	await searchMenuNm();
	await getChildList();
	await searchGrandChild();
	await setApiCondition(req);
}

let menu_matcher_paramcheck = function(req,res){
	return new Promise(function(resolve, reject){
		console.debug('[menumatch] menu_matcher_paramcheck - start');
		let err = req.validationErrors();
		if(err) {
			err.status = 400;
			res.status(400).send(util.res_err(req, 400, err[0].msg));
			console.error(err[0].msg,filename);
			return reject();
		}else{
			req.query.domainId = req.query.domainId || "";
			req.query.in_str = req.query.in_str || '';
			t_result = [];
			return resolve();
        }
	});
};

let menu_matcher_sendresult = async(req,res)=>{
	console.debug('[menumatch] menu_matcher_sendresult - start');
    const response_set =
	[
		// {"name":"상위메뉴명","field":"parent_nm","value":[],"type":"string"},
        // {"name":"태그정보","field":"tag_info","value":[],"type":"string"},
        {"name":"메뉴명","field":"menu_nm","value":[],"type":"string"},
		{"name":"메뉴설명","field":"menu_desc","value":[],"type":"string"},
        {"name":"URL","field":"url","value":[],"type":"string"},
		{"name":"chatbot","field":"","value":"chatbot","type":"string"}
    ];
    let request_set = [];

    let getSendResult =()=>{
		return new Promise(function(resolve, reject){
			console.debug('menu_matcher_sendresult > getSendResult - start');

			//console.check('[menu_matcher_sendresult] req.query.recall_type : ' + req.query.recall_type);

			res.set({'Content-Type': 'text/json; charset=utf-8'});
			let messageObj =
			{
                recall_inform : {
    				recall_parameters : recall_parameters,
    				scenario_parameters : sce_param_obj,
    				recall_type : req.query.recall_type,
    				response_type : "answer"
    			},
				id : "menuMatch",
				name : "menu match",
				description : "menu match",
				request :request_set,
				mapping_info:response_set,
				response :
						{
							items:response_set
						},
				script: {
							type : "url",
							script_code: ""
				  		},
                add_parameter: add_parameter
			}

			if( req.query.condition != 'init' ) {
				let response_item_set = {"items":[]};
				response_set.forEach(v_item=>{
					v_item.value = [];
				});

				let setData = (v_item,element)=>{
					let rs_item={};
					let v_field = v_item.field;
					let set_value = "";
					for(let in_field in element){
						if(in_field == v_field){
							set_value = element[in_field];
						}
						if(v_item.name == "chatbot") set_value ="chatbot";
					}
					v_item.value.push(set_value);
				}

				s_result.forEach(element => {
                    response_set.forEach((v_item)=>{
						setData(v_item,element._source);
					});
				});
			}
            // console.check("messageObj:::::::",JSON.stringify(messageObj,null,2));

			res.send(messageObj);
			return resolve();
		});
	}

	await getSendResult();
};


//***********************************************************************************************************
//  Process Logic : 메뉴 보기
//***********************************************************************************************************
/* GET users listing. */
router.get('/menu_view', function(req, res) {
	menuView_handler(req, res);
});

/* POST users listing. */
router.post('/menu_view', function(req, res) {
	menuView_handler(req, res);
});


// -- promiss handler
let menuView_handler = function(req,res){
	util.req_param('[조회] 메뉴보기',req,filename);
	elapsed = {};
	start = new Date();
	if(req.method == "POST") req.query = req.body;

	//console.check('menuView_handler===============================================>');

	Promise
	.all([menu_view_paramcheck(req,res)])
	.then(function(){return _promise_checktime('paramcheck');})
	.then(function(){return menu_view_work(req,res);})
	.then(function(){return _promise_checktime('menu_view');})
	.then(function(){return menu_view_sendresult(req,res);})
	.catch(function(err){return _promise_errhandler(req,res,err);})
	;
};

let menu_view_work = async(req,res)=>{
	console.debug('[menumatch] menu_matcher_work - start');
	const intent_id = req.query.intent_id;
	param_obj = req.query.by_pass_param;
	sce_param_obj = req.query.sce_param;
	req.query.recall_type = 'by_pass';
	let matchQuery = '';
	let childCount = 0;
	if(param_obj != undefined){
		for (const el of param_obj) {
			if(el.key == '메뉴이름') {
				matchQuery = el.value;
			}
		}
	}

	let searchParentNm =()=> {
		return new Promise(function(resolve,reject) {
			console.debug('[menu_view_work] searchParentNm - start');
			let s_index = "wn_menu_info";
			let s_body;
			let size = 50;
			let sourceList = [];
			let matchObj = {};

			if(matchQuery!='') {
				console.debug('parent_nm 검색 ====================>');
				size = 50;
				matchObj = { "parent_nm.exact": matchQuery };
				sourceList.push('menu_nm');
				sourceList.push('menu_desc');
				sourceList.push('url');

				s_body =
				{
					size: size,
					sort: {menu_order:{order:'asc'}},
					query: { match: matchObj },
					_source: sourceList
				};
				console.debug('[searchParentNm] s_body :' + JSON.stringify(s_body));

				es.client1.search({
					index: s_index,
					body: s_body
				}).then(function (resp) {
					if(resp.hits.total>0) {
						childCount = resp.hits.total;
						s_result = resp.hits.hits;
						console.debug('[searchParentNm] count : ' + resp.hits.total);
					}
					return resolve();
				});

			} else {
				resolve();
			}
		});
	}

	let searchMenuNm =()=> {
		return new Promise(function(resolve,reject) {
			console.debug('[menu_view_work] searchParentNm - start');
			let s_index = "wn_menu_info";
			let s_body;
			let size = 50;
			let sourceList = [];
			let matchObj = {};

			if(matchQuery!='') {
				// console.check('menu_nm 검색 ====================>');
				size = 1;
				matchObj = { "menu_nm.exact": matchQuery };
				sourceList.push('menu_nm');
				sourceList.push('menu_desc');
				sourceList.push('url');

				s_body =
				{
					size: size,
					sort: {menu_order:{order:'asc'}},
					query: { match: matchObj },
					_source: sourceList
				};
				// console.debug('[searchMenuNm] s_body :' + JSON.stringify(s_body));

				es.client1.search({
					index: s_index,
					body: s_body
				}).then(function (resp) {
					if(resp.hits.total>0) {
						s_result = resp.hits.hits;
						console.debug('[searchMenuNm] count : ' + resp.hits.total);
						// console.check('s_result :' + JSON.stringify(s_result));
					}
					return resolve();
				});

			} else {
				resolve();
			}
		});
	}

	await searchParentNm();
	if(childCount == 0) {
		await searchMenuNm();
	}
}

let menu_view_paramcheck = function(req,res){
	return new Promise(function(resolve, reject){
		console.debug('[menumatch] menu_matcher_paramcheck - start');
		let err = req.validationErrors();
		if(err) {
			err.status = 400;
			res.status(400).send(util.res_err(req, 400, err[0].msg));
			console.error(err[0].msg,filename);
			return reject();
		}else{
			req.query.domainId = req.query.domainId || "";
			req.query.in_str = req.query.in_str || '';
			s_result = [];
			return resolve();
        }
	});
};

let menu_view_sendresult = async(req,res)=>{
	console.debug('[menumatch] menu_matcher_sendresult - start');
    const response_set =
	[
		// {"name":"상위메뉴명","field":"parent_nm","value":[],"type":"string"},
        // {"name":"태그정보","field":"tag_info","value":[],"type":"string"},
        {"name":"메뉴명","field":"menu_nm","value":[],"type":"string"},
		{"name":"메뉴설명","field":"menu_desc","value":[],"type":"string"},
        {"name":"URL","field":"url","value":[],"type":"string"},
		{"name":"chatbot","field":"url","value":"chatbot","type":"string"}
    ];
    let request_set = [];

    let getSendResult =()=>{
		return new Promise(function(resolve, reject){
			console.debug('menu_matcher_sendresult > getSendResult - start');

			res.set({'Content-Type': 'text/json; charset=utf-8'});
			let messageObj =
			{
                recall_inform : {
    				recall_parameters : recall_parameters,
    				scenario_parameters : sce_param_obj,
    				recall_type : req.query.recall_type,
    				response_type : "answer"
    			},
				id : "menuMatch",
				name : "menu match",
				description : "menu match",
				request :request_set,
				mapping_info:response_set,
				response :
						{
							items:response_set
						},
				script: {
							type : "url",
							script_code: ""
				  		},
                add_parameter: add_parameter
			}

			if( req.query.condition != 'init' ) {
				let response_item_set = {"items":[]};
				response_set.forEach(v_item=>{
					v_item.value = [];
				});

				let setData = (v_item,element)=>{
					let rs_item={};
					let v_field = v_item.field;
					let set_value = "";
					for(let in_field in element){
						if(in_field == v_field){
							if(in_field == 'chatbot') {
								set_value = 'chatbot';
							} else {
								set_value = element[in_field];
							}
						}
					}
					v_item.value.push(set_value);
				}

				s_result.forEach(element => {
                    response_set.forEach((v_item)=>{
						setData(v_item,element._source);
					});
				});
			}
            //console.check("messageObj:::::::",JSON.stringify(messageObj,null,2));

			res.send(messageObj);
			return resolve();
		});
	}

	await getSendResult();
};


//***********************************************************************************************************
//  Process Logic Area (E)
//***********************************************************************************************************
let checkStartPattern = function(el, pattern) {
	let retFlag = false;
	el = el.toLowerCase();
	if(el.startsWith(pattern)) {
		retFlag = true;
	}
	return retFlag;
}
function regExp_str(el) {
	//let regExp = /[\{\}\[\]\/?.,;:|\)*~`!^·\_+<>@\#$%&\\\=\(\'\"]/gi;
	let regExp = /[\[\]?？.,;:|\)~`!\_〈〉<>\#$%&\\\=\(\'\"‘’]/gi;
	let ret = "";
	if(regExp.test(el)){
		ret = el.replace(regExp, " ");
	}else{
		ret = el;
	}
	return ret;
}

let _promise_checktime = function(name){
	return new Promise(function(resolve, reject){
        // elapsed time
        end = new Date();
        elapsed[name] = (end - start) + ' ms';
        console.debug('_promise_checktime ! - '+name+' ['+elapsed[name]+']');
        return resolve();
    });
};

let _promise_errhandler = function(req,res,err){
	return new Promise(function(resolve, reject){
		if(typeof(err) != 'undefined'){
			console.error(err,filename);
		    //res.status(500).send(util.res_err(req, 500, err.message));

		    res.status(err.status || 500);
		    res.render('error', {
		    	message: err.message,
		    	error: err
		    });
		    return resolve();
		}else{
			return resolve();
		}
	});
};

module.exports = router;
