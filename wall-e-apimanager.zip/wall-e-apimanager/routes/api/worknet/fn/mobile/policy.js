const express = require('express');
const router = express.Router();
const path = require('path');
const filename = path.basename(__filename);
const approot = require('app-root-path');
const configfile = require(approot + '/config/config.json');
const config = require(approot + '/config/config');
const util = require(approot + '/util/util');
const moment = require('moment');
var clonedeep = require('lodash.clonedeep');

// elapsed time
let elapsed = {};
let start, end;

// result
let s_result = [];

// elasticsearch
const es = require(approot + '/util/es');
let request_list = [];
let request_set = [];
const response_set = [
	{"name":"번호","field":"svc_no","value":[],"type":"string"},
	{"name":"정책명","field":"policy_nm","value":[],"type":"string"},
	{"name":"내용","field":"policy_desc","value":[],"type":"string"},
	{"name":"chatbot","field":"chatbot","value":[],"type":"string"},
	{"name":"링크","field":"url","value":[],"type":"string"}
];
let add_parameter = [];
var recall_parameters = [];
var sce_param_obj = [];
var recommend_condition = "";
let totalCount = 0;

//***********************************************************************************************************
//  Process Logic : 정책정보 검색
//***********************************************************************************************************
/* GET users listing. */
router.get('/getPolicy', function(req, res) {
	getPolicy_handler(req, res);
});

/* POST users listing. */
router.post('/getPolicy', function(req, res) {
	getPolicy_handler(req, res);
});


// -- promiss handler
const getPolicy_handler = function(req,res){
	util.req_param('[조회] 정책정보 검색',req,filename);
	start = new Date();
	if(req.method == "POST") req.query = req.body;

	Promise
	.all([getPolicy_paramcheck(req,res)])
	.then(function(){return _promise_checktime('paramcheck');})

	.then(function(){return getPolicy_work(req,res);})
	.then(function(){return _promise_checktime('wantedApi');})

	.then(function(){return getPolicy_sendresult(req,res);})
	.catch(function(err){return _promise_errhandler(req,res,err);})
	;
};


const getPolicy_work = async(req)=>{
	console.debug('[getPolicy_work] start');

	let s_index = "wn_policy_info";
	let param_obj = req.query.by_pass_param;
	let policy_query = "";
	let teanaKmaData = "";

	if(param_obj == undefined) param_obj = [];

	var getKmaResult = ()=>{
		return new Promise(function(resolve, reject){
			console.log('[notMatch] getKmaResult - start');

	        let in_str = req.query.in_str;
	        let teanaCallUrl = 'http://'+config.teana_engine_host+'/kma';
	        console.debug("teanaCallUrl : "+teanaCallUrl+"?in="+in_str);
	        let request = require('request');
	        let urlencode = require('urlencode');

	        let options = {
	        		method: 'POST',
	                uri: teanaCallUrl,
	                body: 'in='+urlencode(in_str),
	                timeout : config.teana_timeout,
	        		headers: {
	        			'content-type': 'application/x-www-form-urlencoded'
	        		}
	        	};
	        request(options, function (error, response, body) {
	            if(error != null){
	                // console.log("teanaCallUrl : "+teanaCallUrl+'?in='+in_str);
	                console.warn(error);
	            }else{
	                console.trace('statusCode : ' + response.statusCode);
	            }
	            if(error == null) {
					teanaKmaData = JSON.parse(body);
					console.warn('kmaData : ' + body);
				}
	            return resolve();
	        });
			// console.log('[notMatch] getKmaResult - end');
		});
	}

	let searchPolicy = ()=>{
		return new Promise(function(resolve, reject){
			// console.log('searchRelicIndex - start');

			let posStr = "";
			posStr = teanaKmaData.query.pos;
			// console.warn('posStr : ' + posStr);

	        let nngArr = getNngArray(posStr);
	        var should_list = [];
	        var must_list = [];
			var set_str = "";
	        nngArr.forEach( el=> {
				set_str += " "+el;
	        });
			if(set_str != "") set_str = set_str.trim();
			console.debug('set_str : ' + set_str);

            if(nngArr.length > 0){
                var s_body =
				{
				  size : 300,
				  query: {
				    simple_query_string: {
				      query: set_str,
				      fields: ["policy_nm.korean^3","tag_info^2","policy_desc.korean"]
				    }
				  }
				}
				console.debug('s_body : ' + JSON.stringify(s_body,null,2));

				es.client1.search({
					index: s_index,
					body: s_body
				}).then(function (resp) {
					totalCount = resp.hits.total;
					if(totalCount>0) s_result = resp.hits.hits;
				  	return resolve();
				}, function (err) {
					err.status = 400;
					res.status(400).send(util.res_err(req, 400, err.message));
					console.error(err.message,filename);
					return resolve();
				});
            }else{
                s_result = [];
                resolve();
            }
		});
	};

	let searchAllPolicy = ()=>{
		return new Promise(function(resolve, reject){
			console.debug('searchAllPolicy - start');

            let s_body = { query: { match_all: {} }, size: 300 };

			es.client1.search({
				index: s_index,
				body: s_body
			}).then(function (resp) {
				totalCount = resp.hits.total;
				s_result = resp.hits.hits;
			  	return resolve();
			}, function (err) {
				err.status = 400;
				res.status(400).send(util.res_err(req, 400, err.message));
				console.error(err.message,filename);
				return resolve();
			});
		});
	};

	var chkRecommedInfo =(req)=>{
		var user_id_flag = false;
	    var recommend_flag = false;
        recommend_condition = "";
        if(req.query.req_parameters != undefined){
            var parameters = req.query.req_parameters;
            var param_obj = JSON.parse(parameters);
            if(param_obj.recommend != undefined){
                param_obj.recommend.forEach((s_item)=>{
                    var count = s_item.count;
                    var v_name = s_item.name;
					if(v_name == "정책"){
						if(count > 0) recommend_flag = true;
					}
                });
            }
        }
        if(req.query.user_id != undefined){
            if(req.query.user_id != "") user_id_flag = true;
        }
        if(recommend_flag) {
			recommend_condition = "개인추천";
		}else{
			recommend_condition = "";
		}
		checkRecommedParameters(req);
    }

	var checkRecommedParameters = (req)=> {
    	param_obj = clonedeep(req.query.by_pass_param);
    	sce_param_obj = req.query.sce_param;
		recall_parameters = param_obj;
        return new Promise(function(resolve, reject){
			recall_parameters.forEach((p_item)=>{
                if(p_item.key == "apicondition") p_item.value = recommend_condition;
            });
			req.query.recall_type = 'recall';
            if(sce_param_obj != undefined){
                sce_param_obj.forEach( el => {
                    if( el.intent_id == req.query.intent_id ) el.params = recall_parameters;
                });
            }
			resolve();
		});
	}



	await getKmaResult(req);
	await searchPolicy(req);
	if(totalCount == 0) {
		await searchAllPolicy(req)
	}
	await chkRecommedInfo(req);

	function getNngArray(kma) {
		let returnArr = [];
		let tempArr = [];
		let subArr = [];
        if(kma!=undefined){
            tempArr = kma.split(' ');
    		tempArr.forEach( el => {
    			subArr = el.split('+');
    			subArr.forEach( s_el => {
    				if(s_el.indexOf('nn')>0) {
    					let retStr = s_el.split('/')[0];
    					returnArr.push( retStr );
    				}
    			})
    		});
        }
		return returnArr;
	}
}


const getPolicy_paramcheck = function(req,res){
	return new Promise(function(resolve, reject){
		const err = req.validationErrors();
		if(err) {
			err.status = 400;
			res.status(400).send(util.res_err(req, 400, err[0].msg));
			console.error(err[0].msg,filename);
			return reject();
		}else{
			s_result = [];
			return resolve();
        }
	});
};


const getPolicy_sendresult = async(req,res)=>{

	let getSendResult =()=>{
		return new Promise(function(resolve, reject){
			res.set({'Content-Type': 'text/json; charset=utf-8'});

			let messageObj =
			{
				recall_inform : {
					recall_parameters : recall_parameters,
					scenario_parameters : sce_param_obj,
					recall_type : req.query.recall_type,
					response_type : req.query.response_type
				},
				id : "get_policy_info",
				name : "정책정보 조회",
				description : "정책정보 조회",
				request :request_set,
				mapping_info:response_set,
				response :
						{
							items:response_set
						},
				script: {
							type : "url",
							script_code: ""
				  		},
                add_parameter: add_parameter
			}

			messageObj.recall_inform.search_total_cnt = totalCount;
			const policy_url = config.work_policy_mobile;

			if( req.query.condition != 'init' ) {
				let result = s_result;
                let response_item_set = {"items":[]};
                response_set.forEach(v_item=>{
                    v_item.value = [];
                });

                let setData = (v_item,element)=>{
                    let rs_item={};
                    let req_lang =  "_"+req.query.lang;
                    let v_field= util.replaceFieldToLang(v_item.field, req_lang);
                    let set_value = "";
					let svc_no = "";

                    for(let in_field in element){
                        if(in_field == v_field){
							set_value = element[in_field];
                        }

						if(in_field == 'svc_no') {
							svc_no = element[in_field];
						}
                    }
					if(v_field == 'url') {
						set_value = `${policy_url}?svno=${svc_no}`;
					}
                    v_item.value.push(set_value);
                }
                result.forEach(element => {
                    response_set.forEach((v_item)=>{
                        setData(v_item,element._source);
                    });
                });
			}

			res.send(messageObj);
			// console.check('[getPolicy_sendresult] messageObj : ' + JSON.stringify(messageObj,null,2));
			return resolve();
		});
	}
	await getSendResult();
};

//***********************************************************************************************************
//  Process Logic Area (E)
//***********************************************************************************************************
const _promise_checktime = function(name){
	return new Promise(function(resolve, reject){
        // elapsed time
        end = new Date();
        elapsed[name] = (end - start) + ' ms';
        console.debug('_promise_checktime ! - '+name+' ['+elapsed[name]+']');
        return resolve();
    });
};

const _promise_errhandler = function(req,res,err){
	return new Promise(function(resolve, reject){
		if(typeof(err) != 'undefined'){
			console.error(err,filename);
		    //res.status(500).send(util.res_err(req, 500, err.message));

		    res.status(err.status || 500);
		    res.render('error', {
		    	message: err.message,
		    	error: err
		    });
		    return resolve();
		}else{
			return resolve();
		}
	});
};

module.exports = router;
