var express = require('express');
var router = express.Router();
var path = require('path');
var filename = path.basename(__filename);
var approot = require('app-root-path');
var uc = require(approot + '/util/unit_changer');

/* GET users listing. */
router.get('/test', function(req, res) {
	// uc_phrase_test(req, res);
	convert_resume_test(req, res);
});
/* POST users listing. */
router.post('/test', function(req, res) {
	// uc_phrase_test(req, res);
	convert_resume_test(req, res);
});

const sample_resume_obj =
{
  "status": {
    "code": 200,
    "message": "OK"
  },
  "resume": {
    "hope_jobs_1_cd": "706000", "hope_jobs_1_nm": "건설 채굴 단순 종사원", "hope_jobs_2_cd": "", "hope_jobs_2_nm": "", "hope_jobs_3_cd": "", "hope_jobs_3_nm": "",
    "hope_region_1_cd": "28000", "hope_region_1_nm": "인천", "hope_region_2_cd": "", "hope_region_2_nm": "", "hope_region_3_cd": "", "hope_region_3_nm": "",
    "readjust_poss_yn": "N",
    "hope_sal": "9000",
    "sal_tp_cd": "Y",
    "sal_tp_nm": ""
  }
}

var convert_resume_test = function(req,res) {

	let resume_obj = sample_resume_obj.resume;
	let salary_value = '';
	let salary_min = -1;
	let readjust_poss_yn = "";
	let sal_tp_cd = "";

	salary_value = resume_obj.hope_sal;
	readjust_poss_yn = resume_obj.readjust_poss_yn;
    sal_tp_cd = resume_obj.sal_tp_cd;

	salary_min = getRealSalary(salary_value, sal_tp_cd, readjust_poss_yn);
	console.error(salary_min);
	console.check('==========================================================');
	let apiSalary = "";
	apiSalary = getApiSalary(salary_min, sal_tp_cd, readjust_poss_yn);
	console.error(apiSalary);
	//return retSalary;
}

var getRealSalary = function( salary, payGubun, readJustYn) {
	console.log('[getRealSalary] 변환전_희망임금:"'+salary + '", 변환전_연봉구분:"'+payGubun + '", 면접후결정파라미터:"' +readJustYn+ '"');
	let retSalary = "";

	if( salary!="" && salary!="undefined" && salary!=undefined ) {
		if(payGubun != 'H' && payGubun != 'D') {
			console.check( 'payGubun ===> ' + payGubun );
			retSalary = salary*10000+'';
		} else {
			retSalary = salary+'';
		}
	}

	if( readJustYn=='Y' ) retSalary="0";
    return retSalary;
}

var getApiSalary = function( salaryMin, payGubun, readJustYn) {
	console.log('[getApiSalary] 희망임금(원):"'+salaryMin + '", 연봉구분:"'+payGubun + '", 면접후결정파라미터:"' +readJustYn+ '"');
    let retSalary = "";
	if(salaryMin != "") {
		if(payGubun != 'H' && payGubun != 'D') {
			console.check( 'payGubun ===> ' + payGubun );
			retSalary = salaryMin/10000+'';
			if(retSalary<1) retSalary='0';
		} else {
			console.check( 'salaryMin is not changed' );
			retSalary = salaryMin;
		}
	}
	if( readJustYn=='Y' ) retSalary="0";
    return retSalary;
}



const sample_teana_response =
{
	"query": {
		"len": 17,
		"input": "서울에서 100만원 교사 찾아줘"
	},
	"res": [
		[
			{
				"intent": "1111",
				"variableList": [
					"$system.amount=서울에서 100만원 교사"
				],
				"parameterList": [
					"$system.amount,system.amount=서울에서 100만원 교사"
				]
			},
			{
				"intent": "2222",
				"variableList": [
					"$희망직종=교사",
					"$system.amount=만원"

				],
				"parameterList": [
					"$희망직종,희망직종=교사",
					"$system.amount,system.amount=만원"
				]
			},
			{
				"intent": "3333",
				"variableList": [
					"$system.amount=서울에서 100만원 교사"
				],
				"parameterList": [
					"$system.amount,system.amount=서울에서 100만원 교사"
				]
			},
			{
				"intent": "4444",
				"variableList": [
					"$system.amount=서울에서 100만원 교사"
				],
				"parameterList": [
					"$system.amount,system.amount=서울에서 100만원 교사"
				]
			},
			{
				"intent": "5555",
				"variableList": [
					"$방가워=1233",
					"$system.amount=2000만원",
					"$system.entity=변환불가단어"
				],
				"parameterList": [
					"$system.amount,system.amount=2000만원"
				]
			}
		]
	]
}

var uc_phrase_test = function(req,res) {
	console.log( '변환전 length : ' + sample_teana_response.res[0].length);
	let teana_res_array = sample_teana_response.res[0];
	let convert_res_array = [];
	teana_res_array.forEach( el => {
		let variable_list = el.variableList;
		let validate_system_entity = true;
		variable_list.forEach( v_el => {
			let variable_key = v_el.split('=')[0];
			let variable_value = v_el.split('=')[1];
			if(variable_key == '$system.amount') {
				console.log('-----------------------------------------------------------------')
				console.log('variable_key : ' + variable_key);
				console.log('variable_value : ' + variable_value);
				console.check( 'converted_value : ' + uc(variable_value) );
				if(uc(variable_value) == -1) validate_system_entity = false;
				console.log('-----------------------------------------------------------------')
			}
		});

		if(validate_system_entity) {
			console.log( el.intent + ' : 정상 추출 teana 결과' );
			convert_res_array.push( el );
		}
	})

	console.log( '변환후 length : ' + convert_res_array.length );
	console.check( '' + JSON.stringify(convert_res_array) );
}

module.exports = router;
