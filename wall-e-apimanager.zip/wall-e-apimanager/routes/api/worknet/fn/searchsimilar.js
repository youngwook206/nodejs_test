var express = require('express');
var router = express.Router();
var path = require('path');
var filename = path.basename(__filename);
var approot = require('app-root-path');
var util = require(approot + '/util/util');
var moment = require('moment');

// elapsed time
var elapsed = {};
var start, end;

var match_list = [];

// result
var s_result = [];
var agg_result = [];

// elasticsearch
var es = require(approot + '/util/es');
var request_list = [];
var request_set = [];
var response_set = [
	{"name":"질의문","field":"req_in_str","value":[],"type":"string"},
	{"name":"인텐트","field":"res_intent","value":[],"type":"string"},
	{"name":"인텐트id","field":"res_intent_id","value":[],"type":"string"},
	{"name":"chatbot","field":"chatbot","value":[],"type":"string"},
	{"name":"매칭 스코어","field":"res_score","value":[],"type":"string"}
];
var add_parameter = [];
var blank_info = { intents:[], messages:[] };


//***********************************************************************************************************
//  Process Logic : 유사질의 검색
//***********************************************************************************************************
/* GET users listing. */
router.get('/getSimLogs', function(req, res) {
	logSearch_handler(req, res);
});

/* POST users listing. */
router.post('/getSimLogs', function(req, res) {
	logSearch_handler(req, res);
});


// -- promiss handler
var logSearch_handler = function(req,res){
	util.req_param('[조회] 유사질의 검색',req,filename);
	elapsed = {};
	start = new Date();
	if(req.method == "POST") req.query = req.body;

	Promise
	.all([getSimilarInLogs_paramcheck(req,res)])
	.then(function(){return _promise_checktime('paramcheck');})
	.then(function(){return checkBlankInfo(req,res);})
	.then(function(){return _promise_checktime('checkBlank');})
	.then(function(){return getSimilarInLogs_work(req,res);})
	.then(function(){return _promise_checktime('searchLog');})

	.then(function(){return getSimilarInLogs_sendresult(req,res);})
	.catch(function(err){return _promise_errhandler(req,res,err);})
	;
};

let checkBlankInfo = async(req) =>{

	let blank_intent_data = {};
	let blank_message_data = {};
	let domain_id = req.query.domain_id;

	let searchBlankIntent = function(req){
		return new Promise(function(resolve, reject){
			let s_body;
			let term_list = [];
			term_list.push( { match: { use_yn: "Y" } } );
			term_list.push( { match: { type: "service" } } );
			term_list.push( { match_phrase: { domain_id: domain_id } } );

			s_body =
			{
			  query: {
				bool: {
				  must: term_list
				}
			  }
			};
			try {
				es.client1.search({
					index: 'tr_blank_intent',
					body: s_body
				}).then(function (resp) {
					blank_intent_data = resp;
					resolve();
				});
			} catch(err) {
				console.error(err);
				resolve();
			}
		});
	}

	let searchBlankMessage = function(req){
		return new Promise(function(resolve, reject){
			let s_body;
			let term_list = [];
			term_list.push( { match: { use_yn: "Y" } } );
			term_list.push( { match: { type: "service" } } );
			term_list.push( { match_phrase: { domain_id: domain_id } } );
			s_body =
			{
			  query: {
				bool: {
				  must: term_list
				}
			  }
			}

			try {
				es.client1.search({
					index: 'tr_blank_message',
					body: s_body
				}).then(function (resp) {
					blank_message_data = resp;
					resolve();
				});
			} catch(err) {
				console.error(err);
				resolve();
			}
		});
	}

	let setBlankInfo = function(req){
		return new Promise(function(resolve, reject){
			if(blank_intent_data.hits.total > 0) {
				blank_info.intents = [];
				blank_intent_data.hits.hits.forEach( el => {
					blank_info.intents.push( el._source.intent_id );
				});
			}
			if(blank_message_data.hits.total > 0) {
				blank_info.messages = [];
				blank_message_data.hits.hits.forEach( el => {
					blank_info.messages.push( el._source.text );
				});
			}
			resolve();
		});
	}

	if(req.query.condition != 'init'){
		await searchBlankIntent(req);
		await searchBlankMessage(req);
		await setBlankInfo(req);
	}

}


var getSimilarInLogs_work = async(req)=>{
	console.log('[getSimilarInLogs_work] start');

	/*
		1. 입력문 받음
		2. 입력문 tr_log에 질의
		3. 질의 결과 뿌림
	*/
	// let param_obj = clonedeep(req.query.in_str);
	let in_str = req.query.in_str;
	var today = util.getThisMonth();
	let s_index = 'tr_chatlog_'+today;
	let search_fields = [ "req_in_str", "req_in_str.exact", "req_in_str.korean","req_in_str.keyword" ];
	let source_fiels = [ "req_in_str", "res_intent", "res_intent_id", "res_score"];
	let searchLogCount = 0;

	let searchChatlog = function(req) {
		return new Promise(function(resolve, reject) {
			console.log('searchChatlog');

			let must_not_list = [];
			blank_info.intents.forEach( el=> {
				must_not_list.push({ term: { "res_intent_id.keyword": { value: el } } });
				//must_not_list.push({ term: { "res_intent_id.keyword": { value: 'trintent_a328ef3e-605c-426a-9418-77626bfde8a0' } } });
			});

			blank_info.messages.forEach( el=> {
				must_not_list.push({ term: { "req_in_str.keyword": { value: el } } });
			});

			let s_body;
			s_body = {
			  size:0,
			  query: {
			    bool: {
			      must: [
			        {
			          simple_query_string: {
					      query: req.query.in_str,
					      fields: search_fields
					    }
			        },
			        {
			          range: {
			            res_current_step: {
			              gte: 1,
			              lte: 1
			            }
			          }
				  },
				  {
			          prefix: {
			            "res_is_matching.keyword": {
			              value: "Y"
			            }
			          }
			        }
				],
				must_not: must_not_list
			    }
			},
			"aggs" : {
	            "str_agg" : {
	                "terms" : { "field" : "req_in_str.keyword" }
	            }
	        }
			// ,_source : source_fiels
			}
			//console.check('s_body : ' + JSON.stringify(s_body));

			//console.check('[로그인덱스(tr_chatlog_) 유사질의 검색] s_index : ' + JSON.stringify(s_body,null,2));

			es.client1.search({
				index: s_index,
				body: s_body
			}).then(function (resp) {
				s_result = resp.hits.hits;
				agg_result = resp.aggregations.str_agg;
				// console.log("agg_result::::",agg_result);
				console.warn('[searchSimilar.js] searchChatlog TOTAL : ' + resp.hits.total);
				searchLogCount = resp.hits.total;
				// console.warn( 's_result : ' + JSON.stringify(s_result) );
			  	return resolve();
			}, function (err) {
				err.status = 400;
				res.status(400).send(util.res_err(req, 400, err.message));
				console.error(err.message,filename);
				return resolve();
			});
		});
	}

	let searchPopularLog = function(req) {
		return new Promise(function(resolve, reject) {
			console.log('searchPopularLog Start');

			if(searchLogCount == 0) {
				let s_body;
					s_body = {
					  size:0,
					  query: {
					    bool: {
					      must: [
					        {
					          range: {
					            res_current_step: {
					              gte: 1,
					              lte: 1
					            }
					          }
						  },
						  {
					          prefix: {
					            "res_is_matching.keyword": {
					              value: "Y"
					            }
					          }
					        }
					      ]
					    }
					},
					"aggs" : {
			            "str_agg" : {
			                "terms" : { "field" : "req_in_str.keyword" }
			            }
			        }
				}
				//console.check('[로그인덱스(tr_chatlog_) 인기질의 검색] s_index : ' + JSON.stringify(s_body,null,2));

				es.client1.search({
					index: s_index,
					body: s_body
				}).then(function (resp) {
					s_result = resp.hits.hits;
					agg_result = resp.aggregations.str_agg;
					agg_result =
					{
					  "doc_count_error_upper_bound": 0,
					  "sum_other_doc_count": 2,
					  "buckets": [
					    {
					      "key": "서울에서 채용정보 찾아줘",
					      "doc_count": 210
					    },
					    {
					      "key": "너는 이름이 뭐니",
					      "doc_count": 167
					    }
					  ]
					}

					// console.warn( 'popular - agg_result : ' + JSON.stringify(agg_result) );
				  	return resolve();
				}, function (err) {
					err.status = 400;
					res.status(400).send(util.res_err(req, 400, err.message));
					console.error(err.message,filename);
					return resolve();
				});
			} else {
				//console.check('simialr log exist !!!');
				resolve();
			}
		});
	}

	await searchChatlog(req);
	await searchPopularLog(req);

}


var getSimilarInLogs_paramcheck = function(req,res){
	return new Promise(function(resolve, reject){
		var err = req.validationErrors();
		if(err) {
			err.status = 400;
			res.status(400).send(util.res_err(req, 400, err[0].msg));
			console.error(err[0].msg,filename);
			return reject();
		}else{
			req.query.from = req.query.from || 0;
			req.query.size = req.query.size || 10;
            req.query.in_str = req.query.in_str || '공고알려줘';
			return resolve();
        }
	});
};


var getSimilarInLogs_sendresult = async(req,res)=>{
	let getSendResult =()=>{
		return new Promise(function(resolve, reject){
			res.set({'Content-Type': 'text/json; charset=utf-8'});
			// console.check('[getSimilarInLogs_sendresult] response_set : '+JSON.stringify(response_set));

			let messageObj =
			{
				id : "search_chatbot_log",
				name : "챗봇로그 유사질의어 조회",
				description : "챗봇로그 유사질의어 조회",
				request :request_set,
				mapping_info:response_set,
				response :
						{
							items:response_set
						},
				script: {
							type : "url",
							script_code: ""
				  		},
                add_parameter: add_parameter
			}

			// console.error('req.query.condition : ' + req.query.condition);

			if( req.query.condition != 'init' ) {
                let result = s_result;
				let agg_set = agg_result.buckets;

				var v_agg_set = [];
				for(var idx=0; idx<agg_set.length;idx++){
					v_agg_set.push(agg_set[idx]);
					if(idx>3) break;
				}

				response_set.forEach(v_item=>{
					v_item.value = [];
				});
				var setData = (v_item,element)=>{
					var rs_item={};
					var v_field= v_item.field
					var set_value = element.key;
					var set_v_count = element.doc_count;
					if(v_item.name == "chatbot") set_value = "chatbot";
					v_item.value.push(set_value);
				}

				v_agg_set.forEach(element => {
					response_set.forEach((v_item)=>{
						setData(v_item,element);
					});
				});

			}

			res.send(messageObj);
			// console.check('[getSimilarInLogs_sendresult] messageObj : ' + JSON.stringify(messageObj,null,2));
			return resolve();
		});
	}
	await getSendResult();
};





//***********************************************************************************************************
//  Process Logic Area (E)
//***********************************************************************************************************
var _promise_checktime = function(name){
	return new Promise(function(resolve, reject){
        // elapsed time
        end = new Date();
        elapsed[name] = (end - start) + ' ms';
        console.debug('_promise_checktime ! - '+name+' ['+elapsed[name]+']');
        return resolve();
    });
};

var _promise_errhandler = function(req,res,err){
	return new Promise(function(resolve, reject){
		if(typeof(err) != 'undefined'){
			console.error(err,filename);
		    //res.status(500).send(util.res_err(req, 500, err.message));

		    res.status(err.status || 500);
		    res.render('error', {
		    	message: err.message,
		    	error: err
		    });
		    return resolve();
		}else{
			return resolve();
		}
	});
};

module.exports = router;
