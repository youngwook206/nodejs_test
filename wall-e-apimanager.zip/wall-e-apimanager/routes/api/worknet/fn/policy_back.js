const express = require('express');
const router = express.Router();
const path = require('path');
const filename = path.basename(__filename);
const approot = require('app-root-path');
const configfile = require(approot + '/config/config.json');
const config = require(approot + '/config/config');
const util = require(approot + '/util/util');
const moment = require('moment');

// elapsed time
let elapsed = {};
let start, end;

// result
let s_result = [];

// elasticsearch
const es = require(approot + '/util/es');
let request_list = [];
let request_set = [];
const response_set = [
	{"name":"번호","field":"svc_no","value":[],"type":"string"},
	{"name":"정책명","field":"policy_nm","value":[],"type":"string"},
	{"name":"내용","field":"policy_desc","value":[],"type":"string"},
	{"name":"chatbot","field":"chatbot","value":[],"type":"string"},
	{"name":"링크","field":"url","value":[],"type":"string"}
];
let add_parameter = [];


//***********************************************************************************************************
//  Process Logic : 정책정보 검색
//***********************************************************************************************************
/* GET users listing. */
router.get('/getPolicy', function(req, res) {
	getPolicy_handler(req, res);
});

/* POST users listing. */
router.post('/getPolicy', function(req, res) {
	getPolicy_handler(req, res);
});


// -- promiss handler
const getPolicy_handler = function(req,res){
	util.req_param('[조회] 정책정보 검색',req,filename);
	start = new Date();
	if(req.method == "POST") req.query = req.body;

	Promise
	.all([getPolicy_paramcheck(req,res)])
	.then(function(){return _promise_checktime('paramcheck');})

	.then(function(){return getPolicy_work(req,res);})
	.then(function(){return _promise_checktime('wantedApi');})

	.then(function(){return getPolicy_sendresult(req,res);})
	.catch(function(err){return _promise_errhandler(req,res,err);})
	;
};


const getPolicy_work = async(req)=>{
	console.log('[getPolicy_work] start');

	let s_index = "wn_policy_info";
	let totalCount = 0;
	let param_obj = req.query.by_pass_param;
	let teanaData = {};

	let policy_query = "";
	let domainId = "";
	let intent_id = "";
	let passedTeanaData = [];
	let paramData = [];

	policy_query = req.query.in_str;
	domainId = req.query.domain_id;
	intent_id = req.query.intent_id;

	/*
	1. inStr Teana 분석
	2. 질의문생성
		-- 1) intentId에 해당하는 분석결과 array
		2) 정책정보 Parameter의 값 array로 (중복 Parameter value 제거)
		3) 질의문 생성( 공백으로 연결 )
	3. default_operator AND로 검색 ( size : 10)
	4. 검색결과 0 건 이상인 경우 결과로
	5. 검색결과 0건인 경우 재검색
	  -default_operator OR로 검색 ( size : 5)
	6. 검색결과 set message
	*/

	let getInfoTeanaData = function(req){
		return new Promise(function(resolve, reject){
			console.debug('[policy] getInfoTeanaData - start');

			inStr = regExp_str(policy_query);
			let teanaCallUrl = 'http://'+config.teana_engine_host+'/match';
			let request = require('request');
			let urlencode = require('urlencode');
			let threshold = 0.8;
			let callBody = 'in='+urlencode(inStr)+'&domainId='+domainId+'&threshold='+threshold;
			callBody = callBody + '&intentId=' + intent_id;
			console.check("teanaCallUrl : "+teanaCallUrl + '?' + callBody);

			let options = {
					method: 'POST',
					uri: teanaCallUrl,
					body: callBody,
					timeout : config.teana_timeout,
					headers: {
						'content-type': 'application/x-www-form-urlencoded'
					}
				};

			request(options, function (error, response, body) {
				if(error != null){
					console.error(error);
				}else{
					console.trace('statusCode : ' + response.statusCode);
				}
				if(error == null) {
					teanaData = JSON.parse(body);
					console.check('teanaData : ' + JSON.stringify(teanaData));
				} else {
					console.error('getInfoTeanaData ERROR !!');
					teanaData =  { query: { len: inStr.length, input: inStr }, res: [[]] }
				}
				return resolve();
			});
		});
	};

	let filterTeanaData = function(req){
		return new Promise(function(resolve,reject) {
			console.debug('[policy] filterTeanaData - start');

			let teanaDataRes = [];
			try{
				teanaDataRes = teanaData.res[0];
			}catch(err){
				console.error( '[filterTeanaData] teanaData.res[0] error' );

			}

			// teanaData pass 여부 판독
			teanaDataRes.forEach( el => {
				if(el.cutoff) {

				} else {
					passedTeanaData.push( el );
				}
			});
			console.check('filterTeanaData > passedTeanaData : ' + JSON.stringify(passedTeanaData));

			resolve();
		});
	}

	let getParamArray = function(req){
		return new Promise(function(resolve, reject) {
			console.debug('[policy] getParamArray - start');
			passedTeanaData.forEach( el => {
				let params = el.parameterList;
				params.forEach( p_el => {
					console.check('[getParamArray] p_el : ' + p_el);
					let paramValue = getParameterValue(p_el)
				})
			})

			resolve();
		});
	}


	await getInfoTeanaData(req);
	await filterTeanaData(req);
	await getParamArray(req);
}


const getPolicy_paramcheck = function(req,res){
	return new Promise(function(resolve, reject){
		const err = req.validationErrors();
		if(err) {
			err.status = 400;
			res.status(400).send(util.res_err(req, 400, err[0].msg));
			console.error(err[0].msg,filename);
			return reject();
		}else{
			return resolve();
        }
	});
};


const getPolicy_sendresult = async(req,res)=>{

	let getSendResult =()=>{
		return new Promise(function(resolve, reject){
			res.set({'Content-Type': 'text/json; charset=utf-8'});
			// console.check('[getSimilarInLogs_sendresult] response_set : '+JSON.stringify(response_set));

			let messageObj =
			{
				id : "get_policy_info",
				name : "정책정보 조회",
				description : "정책정보 조회",
				request :request_set,
				mapping_info:response_set,
				response :
						{
							items:response_set
						},
				script: {
							type : "url",
							script_code: ""
				  		},
                add_parameter: add_parameter
			}

			// console.error('req.query.condition : ' + req.query.condition);

			if( req.query.condition != 'init' ) {
				let result = s_result;
                let response_item_set = {"items":[]};
                response_set.forEach(v_item=>{
                    v_item.value = [];
                });

                let setData = (v_item,element)=>{
                    let rs_item={};
                    let req_lang =  "_"+req.query.lang;
                    let v_field= util.replaceFieldToLang(v_item.field, req_lang);
                    let set_value = "";
                    for(let in_field in element){
                        if(in_field == v_field){
                            set_value = element[in_field];
                        }
                    }
                    v_item.value.push(set_value);
                }
                result.forEach(element => {
                    response_set.forEach((v_item)=>{
                        setData(v_item,element._source);
                    });
                });
			}

			res.send(messageObj);
			// console.check('[getPolicy_sendresult] messageObj : ' + JSON.stringify(messageObj,null,2));
			return resolve();
		});
	}
	await getSendResult();
};

//***********************************************************************************************************
//  Process Logic Area (E)
//***********************************************************************************************************
function regExp_str(el) {
	//let regExp = /[\{\}\[\]\/?.,;:|\)*~`!^·\_+<>@\#$%&\\\=\(\'\"]/gi;
	let regExp = /[\[\]?？.,;:|\)~`!\_〈〉<>\#$%&\\\=\(\'\"‘’]/gi;
	let ret = "";
	if(regExp.test(el)){
		ret = el.replace(regExp, " ");
	}else{
		ret = el;
	}
	return ret;
}
function getTeanaParamValue(el) {
	let arr = el.split(',');
}

const _promise_checktime = function(name){
	return new Promise(function(resolve, reject){
        // elapsed time
        end = new Date();
        elapsed[name] = (end - start) + ' ms';
        console.debug('_promise_checktime ! - '+name+' ['+elapsed[name]+']');
        return resolve();
    });
};

const _promise_errhandler = function(req,res,err){
	return new Promise(function(resolve, reject){
		if(typeof(err) != 'undefined'){
			console.error(err,filename);
		    //res.status(500).send(util.res_err(req, 500, err.message));

		    res.status(err.status || 500);
		    res.render('error', {
		    	message: err.message,
		    	error: err
		    });
		    return resolve();
		}else{
			return resolve();
		}
	});
};

module.exports = router;
