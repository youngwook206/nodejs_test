var express = require('express');
var router = express.Router();
var path = require('path');
var filename = path.basename(__filename);
var approot = require('app-root-path');
var configfile = require(approot + '/config/config.json');
var config = require(approot + '/config/config');
var util = require(approot + '/util/util');
var clonedeep = require('lodash.clonedeep');
var es = require(approot + '/util/es');

// elapsed time
var elapsed = {};
var start, end;
var add_parameter = [];
var s_result = [];
var request_set = [];
var response_set = [];
var param_obj = [];
var sce_param_obj = [];
var recall_parameters = [];
var result_count = 0;


//***********************************************************************************************************
//  Process Logic : 실명 조회
//***********************************************************************************************************
/* GET users listing. */
router.get('/search', function(req, res) {
	kma_search_handler(req, res);
});

/* POST users listing. */
router.post('/search', function(req, res) {
	kma_search_handler(req, res);
});


// -- promiss handler
var kma_search_handler = function(req,res){
	util.req_param('[조회] 형태소분석 검색',req,filename);
	elapsed = {};
	s_result = [];
	start = new Date();
	if(req.method == "POST") req.query = req.body;

	Promise
	.all([not_matching_paramcheck(req,res)])
	.then(function(){return _promise_checktime('paramcheck');})
	.then(function(){return not_matching_work(req,res);})
	.then(function(){return _promise_checktime('not_matching');})
	.then(function(){return not_matching_sendresult(req,res);})
	.catch(function(err){return _promise_errhandler(req,res,err);})
	;
};

var not_matching_work = async(req,res)=>{
	var domain_id = req.query.domain_id;
    let teanaKmaData = {};
	var getKmaResult = ()=>{
		return new Promise(function(resolve, reject){

	        let in_str = req.query.in_str;
	        let teanaCallUrl = 'http://'+config.teana_engine_host+'/kma';
	        console.debug("teanaCallUrl : "+teanaCallUrl+"?in="+in_str);
	        let request = require('request');
	        let urlencode = require('urlencode');

	        let options = {
	        		method: 'POST',
	                uri: teanaCallUrl,
	                body: 'in='+urlencode(in_str),
	                timeout : config.teana_timeout,
	        		headers: {
	        			'content-type': 'application/x-www-form-urlencoded'
	        		}
	        	};
	        request(options, function (error, response, body) {
	            if(error != null){
	                // console.log("teanaCallUrl : "+teanaCallUrl+'?in='+in_str);
	                console.warn(error);
	            }else{
	                console.trace('statusCode : ' + response.statusCode);
	            }
	            if(error == null) {
					req.query.kmaData = JSON.parse(body);
					teanaKmaData = JSON.parse(body);
				}
	            return resolve();
	        });
			// console.log('[notMatch] getKmaResult - end');
		});
	}

	var searchIndex = ()=>{
        add_parameter = [];
		return new Promise(function(resolve, reject){
			// console.log('searchRelicIndex - start');
			let posStr = "";
			posStr = teanaKmaData.query.pos;

	        let s_index = "wn_menu_info";
	        let nngArr = getNngArray(posStr);
	        var should_list = [];
	        var must_list = [];

            var nng_str = "";
            nngArr.forEach(function(n_item){
                nng_str += n_item+" ";
            });
			nng_str = nng_str.trim();
            add_parameter.push({ key:'nng_str', value:nng_str,id:"","status":"","required":"N"});

			var set_str = "";
	        nngArr.forEach( el=> {
				set_str += " "+el;
	        });
			if(set_str != "") set_str = set_str.trim();

            must_list.push(
					{
						"query_string": {
							"fields" : ["tag_info", "menu_nm","menu_desc"],
							"query": set_str
						}
					}
                );

            if(nngArr.length > 0){
                var s_body =
				{
				  "size": 50,
				  "query": {
				    "bool": {
				      "must": must_list
				    }
				  }
				};

                // console.log("s_body:::::::",JSON.stringify(s_body,null,2));
    	        es.client1.search({
    	            index: s_index,
    	            body: s_body
    	        }).then(function (resp) {
    			   req.query.trResult = resp.hits.hits;
    	           return resolve();
    	        });
            }else{
                req.query.trResult = [];
                return resolve();
            }
		});
	};

    var checkParameters = (req, region)=> {

        result_count = req.query.trResult.length;
        // console.log("result_count:::::::",result_count);

    	param_obj = clonedeep(req.query.by_pass_param);
    	sce_param_obj = req.query.sce_param;
        return new Promise(function(resolve, reject){
			recall_parameters = param_obj;
            if(result_count == 0){
                recall_parameters.forEach((p_item)=>{
                    if(p_item.key == "apiresult") p_item.value = "noresult";
                })
                req.query.recall_type = 'recall';
            }
            if(sce_param_obj != undefined){
                sce_param_obj.forEach( el => {
                    if( el.intent_id == req.query.intent_id ) el.params = recall_parameters;
                });
            }
			resolve();
		});
	}

    // console.log("NOt mAtchWORK!!!===>",req.query.in_str);

    if(req.query.in_str != undefined && req.query.in_str != ""){
        // console.log("OUT!!!!");
        await getKmaResult(req);
        await searchIndex(req);
        await checkParameters(req);
    }

	function getNngArray(kma) {
		let returnArr = [];
		let tempArr = [];
		let subArr = [];
        if(kma!=undefined){
            tempArr = kma.split(' ');
    		tempArr.forEach( el => {
    			subArr = el.split('+');
    			subArr.forEach( s_el => {
    				if(s_el.indexOf('nn')>0) {
    					let retStr = s_el.split('/')[0];
    					returnArr.push( retStr );
    				}
    			})
    		});
        }
		return returnArr;
	}
}

var not_matching_paramcheck = function(req,res){
	return new Promise(function(resolve, reject){
		var err = req.validationErrors();
		if(err) {
			err.status = 400;
			res.status(400).send(util.res_err(req, 400, err[0].msg));
			console.error(err[0].msg,filename);
			return reject();
		}else{
			req.query.in_str = req.query.in_str || "";
			req.query.domainId = req.query.domainId || "";
			req.query.lang = req.query.lang || "";
			return resolve();
        }
	});
};

var not_matching_sendresult = async(req,res)=>{

    var response_set = [
        {"name":"상위메뉴명","field":"parent_nm","value":[],"type":"string"},
        {"name":"태그정보","field":"tag_info","value":[],"type":"string"},
        {"name":"메뉴설명","field":"menu_desc","value":[],"type":"string"},
        {"name":"메뉴명","field":"menu_nm","value":[],"type":"string"},
        {"name":"URL","field":"url","value":[],"type":"string"}
    ];
    var request_set = [];

    var getSendResult =()=>{
		return new Promise(function(resolve, reject){
			res.set({'Content-Type': 'text/json; charset=utf-8'});


            // req_body.result.meta.response_type = recall_response_type;
            // req_body.result.meta.recall_total_count = recall_total_count;
            // req_body.result.meta.parameters = recall_param;
            // req_body.result.meta.scenario_parameters = recall_scenario_param;

			var messageObj =
			{
                recall_inform : {
    				recall_parameters : recall_parameters,
    				scenario_parameters : sce_param_obj,
    				recall_type : req.query.recall_type,
    				response_type : "answer"
    			},
				id : "notmatching",
				name : "not matching",
				description : "not matching",
				request :request_set,
				mapping_info:response_set,
				response :
						{
							items:response_set
						},
				script: {
							type : "url",
							script_code: ""
				  		},
                add_parameter: add_parameter
			}

			if( req.query.condition != 'init' ) {
				var result = req.query.trResult;
				var response_item_set = {"items":[]};
				response_set.forEach(v_item=>{
					v_item.value = [];
				});

				var setData = (v_item,element)=>{
					var rs_item={};
					var v_field = v_item.field;
					var set_value = "";
					for(var in_field in element){
						if(in_field == v_field){
							set_value = element[in_field];
						}
					}
					// set_value = chkArrayImage(v_item.field,set_value);
					// console.log("set_valueset_valueset_value",set_value);
					v_item.value.push(set_value);
				}

                // console.log("result:::::",result);

				result.forEach(element => {
                    // console.log("element:::",element);
                    response_set.forEach((v_item)=>{
						setData(v_item,element._source);
					});
				});
			}

			res.send(messageObj);
			return resolve();
		});
	}

	await getSendResult();
};














//***********************************************************************************************************
//  Process Logic Area (E)
//***********************************************************************************************************

var chkArrayImage = (v_field,set_value)=>{
	var ret_val = set_value;
	if(v_field == "relicImageURL"){
		if(set_value!= undefined && set_value != null){
			if(set_value.indexOf(",")!=-1){
				ret_val = set_value.split(",")[0];
			}
		}
	}
	return ret_val;
}

var _promise_checktime = function(name){
	return new Promise(function(resolve, reject){
        // elapsed time
        end = new Date();
        elapsed[name] = (end - start) + ' ms';
        console.debug('_promise_checktime ! - '+name+' ['+elapsed[name]+']');
        return resolve();
    });
};

var _promise_errhandler = function(req,res,err){
	return new Promise(function(resolve, reject){
		if(typeof(err) != 'undefined'){
			console.error(err,filename);
		    //res.status(500).send(util.res_err(req, 500, err.message));

		    res.status(err.status || 500);
		    res.render('error', {
		    	message: err.message,
		    	error: err
		    });
		    return resolve();
		}else{
			return resolve();
		}
	});
};

module.exports = router;
