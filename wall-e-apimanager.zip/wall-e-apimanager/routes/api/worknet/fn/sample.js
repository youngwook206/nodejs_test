const express = require('express');
const router = express.Router();
const path = require('path');
const filename = path.basename(__filename);
const approot = require('app-root-path');
const util = require(approot + '/util/util');
const es = require(approot + '/util/es');

// elapsed time
let elapsed = {};
let start, end;

let s_result = [];
let request_set = [];
let response_set = [];
let add_parameter = [];
let param_obj = [];
let sce_param_obj = [];
let recall_parameters = [];

//***********************************************************************************************************
//  Process Logic : 메뉴 보기
//***********************************************************************************************************
/* GET users listing. */
router.get('/logSearch', function(req, res) {
	sample_handler(req, res);
});

/* POST users listing. */
router.post('/logSearch', function(req, res) {
	sample_handler(req, res);
});


// -- promiss handler
let sample_handler = function(req,res){
	util.req_param('[조회] 인텐트 보기',req,filename);
	elapsed = {};
	start = new Date();
	if(req.method == "POST") req.query = req.body;

	Promise
	.all([sample_paramcheck(req,res)])
	.then(function(){return _promise_checktime('paramcheck');})
	.then(function(){return sample_work(req,res);})
	.then(function(){return _promise_checktime('menu_view');})
	.then(function(){return sample_sendresult(req,res);})
	.catch(function(err){return _promise_errhandler(req,res,err);})
	;
};

let sample_work = async(req,res)=>{
	console.debug('[menumatch] sample_work - start');

	param_obj = req.query.by_pass_param;
	sce_param_obj = req.query.sce_param;
	let searchQuery = "";

	if(param_obj != undefined){
		for (const el of param_obj) {
			if(el.key == '희망직종') {
				searchQuery += el.value + " ";
			}
			if(el.key == '희망지역') {
				searchQuery += el.value + " ";
			}
		}
		searchQuery = searchQuery.trim();
		console.debug('searchQuery : ' + searchQuery);
	}

	let searchTrLog =()=> {
		return new Promise(function(resolve,reject) {
			console.debug('[sample_work] searchTrLog - start');
			console.debug('[searchTrLog] req.query.domain_id : ' + req.query.domain_id);

			let s_index = "tr_chatlog_201812";
			let s_body;
			let size = 20;

			if(searchQuery!='') {
				s_body =
				{
					size : size,
					query: {
						match: {
							"req_in_str.korean": searchQuery
						}
					},
					_source : [
						"req_in_str",
						"res_intent",
						"timestamp"
					]
				};

				es.client1.search({
					index: s_index,
					body: s_body
				}).then(function (resp) {
					if(resp.hits.total>0) {
						s_result = resp.hits.hits;
						console.debug('[searchTrLog] count : ' + resp.hits.total);
					}
					return resolve();
				});

			} else {
				resolve();
			}
		});
	}


	await searchTrLog();
}

let sample_paramcheck = function(req,res){
	return new Promise(function(resolve, reject){
		console.debug('[menumatch] sample_paramcheck - start');
		let err = req.validationErrors();
		if(err) {
			err.status = 400;
			res.status(400).send(util.res_err(req, 400, err[0].msg));
			console.error(err[0].msg,filename);
			return reject();
		}else{
			req.query.domain_id = req.query.domain_id || "";
			console.debug('[sample_paramcheck] req.query.domain_id : ' + req.query.domain_id);
			return resolve();
        }
	});
};

let sample_sendresult = async(req,res)=>{
	console.debug('[sample] sample_sendresult - start');
    const response_set =
	[
        {"name":"질의어","field":"req_in_str","value":[],"type":"string"},
		{"name":"매칭인텐트","field":"res_intent","value":[],"type":"string"},
		{"name":"질의시간","field":"timestamp","value":[],"type":"string"}
    ];
    let request_set = [];

    let getSendResult =()=>{
		return new Promise(function(resolve, reject){
			console.debug('sample_sendresult > getSendResult - start');

			res.set({'Content-Type': 'text/json; charset=utf-8'});
			let messageObj =
			{
                recall_inform : {
    				recall_parameters : recall_parameters,
    				scenario_parameters : sce_param_obj,
    				recall_type : req.query.recall_type,
    				response_type : "answer"
    			},
				id : "sample",
				name : "api sample",
				description : "api sample",
				request :request_set,
				mapping_info:response_set,
				response :
						{
							items:response_set
						},
				script: {
							type : "url",
							script_code: ""
				  		},
                add_parameter: add_parameter
			}

			if( req.query.condition != 'init' ) {
				let response_item_set = {"items":[]};
				response_set.forEach(v_item=>{
					v_item.value = [];
				});

				let setData = (v_item,element)=>{
					let rs_item={};
					let v_field = v_item.field;
					let set_value = "";
					for(let in_field in element){
						if(in_field == v_field){
							set_value = element[in_field];
						}
					}
					v_item.value.push(set_value);
				}

				s_result.forEach(element => {
                    response_set.forEach((v_item)=>{
						setData(v_item,element._source);
					});
				});
			}
            //console.check("messageObj:::::::",JSON.stringify(messageObj,null,2));

			res.send(messageObj);
			return resolve();
		});
	}

	await getSendResult();
};


//***********************************************************************************************************
//  Process Logic Area (E)
//***********************************************************************************************************

let _promise_checktime = function(name){
	return new Promise(function(resolve, reject){
        // elapsed time
        end = new Date();
        elapsed[name] = (end - start) + ' ms';
        console.debug('_promise_checktime ! - '+name+' ['+elapsed[name]+']');
        return resolve();
    });
};

let _promise_errhandler = function(req,res,err){
	return new Promise(function(resolve, reject){
		if(typeof(err) != 'undefined'){
			console.error(err,filename);
		    //res.status(500).send(util.res_err(req, 500, err.message));

		    res.status(err.status || 500);
		    res.render('error', {
		    	message: err.message,
		    	error: err
		    });
		    return resolve();
		}else{
			return resolve();
		}
	});
};

module.exports = router;
