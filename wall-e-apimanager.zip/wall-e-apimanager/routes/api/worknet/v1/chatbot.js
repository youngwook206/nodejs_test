var express = require('express');
var router = express.Router();
var path = require('path');
var filename = path.basename(__filename);
var approot = require('app-root-path');
var util = require(approot + '/util/util');
var req_promise = require('request-promise');
var elapsed = {};
var start, end;
var body = {};
var site_id = "worknet";


/* GET users listing. */
router.get('/', function(req, res) {
	promisshandler(req, res);
});

/* POST users listing. */
router.post('/', function(req, res) {
	promisshandler(req, res);
});


//***********************************************************************************************************
//  Process Logic Area (S)
//***********************************************************************************************************
var site_name = 'worknet';
var config = require(approot + '/config/config');

// elasticsearch
var es = require(approot + '/util/es');
// redis
var redis = require(approot + '/util/redis');
var redis_meta = require(approot + '/util/redis_meta');

// uuid
const uuidv1 = require('uuid/v1');
const uuidv4 = require('uuid/v4');

// -- promiss handler
var promisshandler = function(req,res){
	util.req_param('[API] chatbot',req,filename);

	elapsed = {};
	body = {};
	start = new Date();
	if(req.method == "POST") req.query = req.body;

	Promise
	.all([_promise_paramcheck(req,res)])
	.then(function(){return _promise_checktime('paramcheck');})
	.then(function(){return _promise_work(req,res);})
	.catch(function(err){return _promise_errhandler(req,res,err);})
	;

};

var _promise_paramcheck = function(req,res){
	return new Promise(function(resolve, reject){

		req.query.output = req.query.output || '';
		req.query.template = req.query.template || '';
		if(req.query.output == 'sample' && req.query.template != ''){
			//sample일 경우 파라미터 체크 안함.
		}else{
			req.checkQuery('session_id', 'session_id required').notEmpty();
			req.checkQuery('domain_id', 'domain_id required').notEmpty();
			// req.checkQuery('in_str', 'in_str required').notEmpty();
		}
		var err = req.validationErrors();

		if(err) {
			err.status = 400;
			res.status(400).send(util.res_err(req, 400, err[0].msg));
			console.error(err[0].msg,filename);
			return reject();
		}else{
			//init parameter
			req.query = req.query || '{}';
			req.query.output = req.query.output || '';
			req.query.template = req.query.template || '';
			req.query.lang = req.query.lang || '';

			req.query.rediskey = req.query.rediskey || '';
			req.query.body = req.query.body || {};
			req.query.user_id = req.query.user_id || '';
			req.query.domain_id = req.query.domain_id || '';
			req.query.in_str = req.query.in_str || '';
			req.query.meta_before = req.query.meta_before || '{}';
			req.query.response_type = req.query.response_type || '';
			req.query.req_dialogue_id = req.query.dialogue_id || '';//화면에서 강제적으로 dialogue_id 넘어온 경우. ex)뒤로가기
			req.query.debug = req.query.debug || 'false';
			req.query.action = req.query.action || '{}';
			req.query.chatflow_run_check = req.query.chatflow_run_check || undefined;
			req.query.param_like = req.query.param_like || '';

			return resolve();
		}
	});
};


var _promise_work = function(req,res){
	return new Promise(function(resolve, reject){
		var param_like = req.query.param_like;
		var in_str = req.query.in_str;

		if(param_like != "" && in_str == ""){
			var req_parameters = req.query.parameters;
			if(req_parameters != undefined){
				Promise
				.all([_promise_chk_likeYN(req,res)])
				.then(function(){return _promise_sendresult(req,res);})
				.catch(function(err){return _promise_errhandler(req,res,err);})
			}
		}else{
			req.checkQuery('in_str', 'in_str required').notEmpty();
			var err = req.validationErrors();
			if(err) {
				err.status = 400;
				res.status(400).send(util.res_err(req, 400, err[0].msg));
				console.error(err[0].msg,filename);
				return reject();
			}else{
				Promise
				.all([_promise_work_insert(req,res)])
				// .then(function(){return _promise_checktime('work insert');})
				.then(function(){return _promise_checktime('work process');})
				.then(function(){return _promise_dialogue_work_process(req,res);})
				.then(function(){return _promise_checktime('work process');})
				.then(function(){return _promise_work_select(req,res);})
				.then(function(){return _promise_checktime('work select');})
				.then(function(){return _promise_work_meta(req,res);})
				.then(function(){return _promise_checktime('work meta insert');})
				.then(function(){return _promise_sendresult(req,res);})
				.catch(function(err){return _promise_errhandler(req,res,err);})
			}
		}
	});
}

var _promise_chk_likeYN = async(req,res)=>{
	var dialogue_id = req.query.parameters.dialogue_id;
	var like_yn = req.query.param_like;
	var domain_id = req.query.domain_id;
    var user_id = req.query.user_id;
	var intent_id = "";
    var req_in_str = "";
	var ret_obj = {
					"domain_id":domain_id
					,"dialogue_id":dialogue_id
					,"intent_id":intent_id
					,"req_in_str":req_in_str
					,"user_id":user_id
					,"like_yn":like_yn
				   }


	var checkDialogueId = async()=>{
		return new Promise(function(resolve, reject){
			var fs = require('fs');
			var result = fs.readFileSync(approot+'/routes/api/'+site_name+'/sampleoutputparam.json', 'utf8');
			result = JSON.parse(result);
			req.query.body = result;
			var meta_before;

			redis_meta.hgetall(req.query.session_id,function(err, obj){
				if(obj == null) {
					if(err != null) console.error(err);
				}else{
					meta_before = JSON.parse(obj.meta_before);
					intent_id = meta_before.intent_id;
					req_in_str = "";

					ret_obj.intent_id = intent_id;
					ret_obj.req_in_str = req_in_str;
				}
				return resolve();
			});
		});
	}

	var insertLikeYN =()=>{
		var api_url = config.dm_url;
		var domain_id = req.query.domain_id;
		var req_param = {
			method: 'POST',
			uri: api_url,
			body: "",
			headers: {
			  'Content-Type': 'application/json'
			},
			json: false
		};

		var req_obj = ret_obj;
		var req_url = api_url +"/like_yn_log/insert";
		req_param.uri=req_url;
		req_param.body=JSON.stringify(req_obj);
		return req_promise(req_param,function(e,v,item){
			try{
				// console.log("====>SUCCESSS!!!!!!!");
			}catch(e){
				console.error(e);
			}
		});
	}

	await checkDialogueId();
	await insertLikeYN();
}


var _promise_work_insert = function(req,res){
	return new Promise(function(resolve, reject){
		req.query.rediskey = req.query.rediskey || '';
		var fs = require('fs');
		var result = fs.readFileSync(approot+'/routes/api/'+site_name+'/sampleoutputparam.json', 'utf8');
		result = JSON.parse(result);
		req.query.body = result;

		if(req.query.output == 'sample' && req.query.template != ''){
			result = fs.readFileSync(approot+'/routes/api/'+site_name+'/sampleoutputparam.'+req.query.template+'.json', 'utf8');
			result = JSON.parse(result);
			req.query.body = result;
			return resolve();
		}else{
			if(req.method == "GET"){
				var errStatus = 400;
				res.status(errStatus).send(util.res_err(req, errStatus, "Please send to POST"));
				return reject();
			}else if(req.method == "POST"){
				//redis query insert !

				redis_meta.hgetall(req.query.session_id,function(err, obj){
					if(obj == null) {
						if(err != null) console.error(err);
						req.query.meta_before = '{}';
						req.query.action = '{}';
						req.query.dialogue_id = uuidv4();
					}else{
						req.query.action = obj.action;
						req.query.meta_before = obj.meta_before;
						req.query.dialogue_id = obj.dialogue_id;

						// yw - answer와 session_id->chatflow_run_check(??) 로  dialogue_id 아이디 발급
						if(obj.response_type == 'answer' && obj.chatflow_run_check == "false") {
							req.query.meta_before = '{}';
							req.query.action = '{}';
							req.query.dialogue_id = uuidv4();
						}
					}
					var rediskey = redisDataInsert(req);
					req.query.rediskey = rediskey;
					req.query.body = {};
					return resolve();
				});
			}
		}
	});
};


var _promise_dialogue_work_process = function(req,res){

	return new Promise(function(resolve, reject){

		if(req.query.output == 'sample' && req.query.template != ''){
			return resolve();
		}else{
			if(req.query.rediskey != ''){
				console.debug("run datamanager !!");

				let datamanagerUrl = config.datamanager_url;
				datamanagerUrl = datamanagerUrl + '?rediskey='+req.query.rediskey+"&site_id="+site_id;
				console.debug("datamanagerUrl : "+datamanagerUrl);
				let request = require('request');
				let headerVal = {'Content-Type': 'application/json'};

				let options = {
					method: 'GET',
					//headers: headerVal,
					url : datamanagerUrl,
					//body: JSON.stringify({rediskey: req.query.rediskey}),
					//body: 'rediskey='+req.query.rediskey,
					timeout : config.datamanager_timeout
				}

				request(options, function (error, response, body) {
					if(error != null){
						console.error("datamanagerUrl : "+datamanagerUrl);
						console.error(error);
					}else{
						console.trace('statusCode : ' + response.statusCode);
						console.trace('body : ' + body);
					}
					if(error == null){
						req.query.body = (JSON.parse(body)).data;
					}
					return resolve();
				});

			}else{
				console.debug("pass datamanager !!");
				var errStatus = 400;
				res.status(errStatus).send(util.res_err(req, errStatus, "Pass DataManager - empty rediskey !"));
				return reject();
			}
		}

	});
};

var _promise_work_select = function(req,res){
	return new Promise(function(resolve, reject){

		if(req.query.output == 'sample' && req.query.template != ''){
			return resolve();
		}else{
			if(req.query.rediskey != ''){

				console.trace("rediskey : "+ req.query.rediskey);
				redis.hgetall(req.query.rediskey,function(err, obj){

					if(typeof(obj.res_body) == 'undefined'){
						console.warn('redis hgetall res_body value : '+obj.res_body);
						req.query.body = JSON.parse('{}');
					}else{
						req.query.body = JSON.parse(obj.res_body);
						req.query.user_id = obj.user_id;
						req.query.response_type = obj.response_type;
						req.query.dialogue_id = obj.dialogue_id;
						req.query.response = obj.response;
						req.query.lang = obj.lang;
						req.query.action = obj.action;
						req.query.chatflow_run_check = obj.chatflow_run_check;
					}
					return resolve();
				});

			}else{
				console.debug("pass redis data !!");
				var errStatus = 400;
				res.status(errStatus).send(util.res_err(req, errStatus, "Pass DataManager - empty rediskey !"));
				return reject();
			}
		}

	});
};

var _promise_work_meta = function(req,res){
	return new Promise(function(resolve, reject){

		if(req.query.output == 'sample' && req.query.template != ''){
			return resolve();
		}else{
			if(req.query.rediskey != ''){
				redisDataInsertMeta(req);
				return resolve();
			}else{
				console.debug("pass redis data !!");
				var errStatus = 400;
				res.status(errStatus).send(util.res_err(req, errStatus, "empty rediskey !"));
				return reject();
			}
		}

	});
};

var _promise_change_speech_parameters = function(req,res){
	return new Promise(function(resolve, reject){

		if(req.query.output == 'sample' && req.query.template != ''){
			return resolve();
		}else{
			if(req.query.rediskey != ''){
				let parameters = [];
				try{parameters = req.query.body.result.meta.parameters;}catch(err){parameters = [];}

				let speech = '';
				// console.trace(req.query.body.result.fulfillment);
				try{speech = req.query.body.result.fulfillment.speech;}catch(err){speech = '';}

				if(parameters != null){
					for(let i=0;i<Object.keys(parameters).length;i++){
						let key = parameters[i].key;
						let value = parameters[i].value;
						//speech = speech.replace(/\$\{"+key+"\}/g, value);
						if(speech.indexOf("$") != -1){
							speech = speech.replace(new RegExp("\\$\\{"+key+"\\}","g"), value);
							req.query.body.result.fulfillment.speech = speech;
						}
					}
					return resolve();
				}else{
					return resolve();
				}
			}else{
				console.debug("pass redis data !!");
				var errStatus = 400;
				res.status(errStatus).send(util.res_err(req, errStatus, "empty rediskey !"));
				return reject();
			}
		}

	});c
};


var _promise_change_speech_response = function(req,res){
	return new Promise(function(resolve, reject){

		if(req.query.output == 'sample' && req.query.template != ''){
			return resolve();
		}else{
			if(req.query.rediskey != ''){
				let response = [];
				try{response = req.query.response.response.items;}catch(err){response = [];}

				let speech = '';
				console.trace(req.query.body.result.fulfillment);
				try{speech = req.query.body.result.fulfillment.speech;}catch(err){speech = '';}

				if(response != null){
					for(let i=0;i<Object.keys(response).length;i++){
						let key = response[i].name;
						let value = '';
						try{value = response[i].value[0];}catch(err){value = '';}
						//speech = speech.replace(/\$\{"+key+"\}/g, value);
						if(speech.indexOf("@") != -1){
							speech = speech.replace(new RegExp("\\@\\{"+key+"\\}","g"), value);
							req.query.body.result.fulfillment.speech = speech;
						}
					}
					return resolve();
				}else{
					return resolve();
				}
			}else{
				console.debug("pass redis data !!");
				var errStatus = 400;
				res.status(errStatus).send(util.res_err(req, errStatus, "empty rediskey !"));
				return reject();
			}
		}

	});
};


var _promise_change_display_message_parameters = function(req,res){
	return new Promise(function(resolve, reject){

		if(req.query.output == 'sample' && req.query.template != ''){
			return resolve();
		}else{
			if(req.query.rediskey != ''){
				let parameters = [];
				try{parameters = req.query.body.result.meta.parameters;}catch(err){parameters = [];}

				let display_message = '';
				try{display_message = req.query.body.result.fulfillment.display_message;}catch(err){display_message = '';}

				if(parameters != null){
					for(let i=0;i<Object.keys(parameters).length;i++){
						let key = parameters[i].key;
						let value = parameters[i].value;
						//display_message = display_message.replace(/\$\{"+key+"\}/g, value);
						if(display_message.indexOf("$") != -1){
							display_message = display_message.replace(new RegExp("\\$\\{"+key+"\\}","g"), value);
							req.query.body.result.fulfillment.display_message = display_message;
						}
					}
					return resolve();
				}else{
					return resolve();
				}
			}else{
				console.debug("pass redis data !!");
				var errStatus = 400;
				res.status(errStatus).send(util.res_err(req, errStatus, "empty rediskey !"));
				return reject();
			}
		}

	});
};

var _promise_change_display_message_response = function(req,res){
	return new Promise(function(resolve, reject){

		if(req.query.output == 'sample' && req.query.template != ''){
			return resolve();
		}else{
			if(req.query.rediskey != ''){
				let response = [];
				try{response = req.query.response.response.items;}catch(err){response = [];}

				let display_message = '';
				try{display_message = req.query.body.result.fulfillment.display_message;}catch(err){display_message = '';}

				if(response != null){
					for(let i=0;i<Object.keys(response).length;i++){
						let key = response[i].key;
						let value = '';
						try{value = response[i].value[0];}catch(err){value = '';}
						//display_message = display_message.replace(/\$\{"+key+"\}/g, value);
						if(display_message.indexOf("@") != -1){
							display_message = display_message.replace(new RegExp("\\@\\{"+key+"\\}","g"), value);
							req.query.body.result.fulfillment.display_message = display_message;
						}
					}
					return resolve();
				}else{
					return resolve();
				}
			}else{
				console.debug("pass redis data !!");
				var errStatus = 400;
				res.status(errStatus).send(util.res_err(req, errStatus, "empty rediskey !"));
				return reject();
			}
		}

	});
};

var _promise_lang_Translation_speech = function(req,res){
	return new Promise(function(resolve, reject){

		if(req.query.output == 'sample' && req.query.template != ''){
			return resolve();
		}else{
			if(req.query.rediskey != ''){

				let check = /[ㄱ-ㅎ|ㅏ-ㅣ|가-힝]/;
				let speech = req.query.body.result.fulfillment.speech;
				//req.query.lang = 'en';
				if(req.query.lang != 'ko' && check.test(speech)){

					let translation_url = config.translation_url;
					translation_url = translation_url + '?text='+speech;

					let trans_lang = 'ke';
					//ke(한영),ek(영한),kc(한중),ck(중한),kj(한일),jk(일한)
					//한국어(ko), 영어(en), 중국어(zh), 일본어(ja)
					if(req.query.lang == 'en') trans_lang = 'ke';
					if(req.query.lang == 'zh') trans_lang = 'kc';
					if(req.query.lang == 'ja') trans_lang = 'kj';

					translation_url = translation_url + '&target='+trans_lang;
					console.debug("translation_url : "+translation_url);
					let request = require('request');
					let urlencode = require('urlencode');

					let options = {
						method: 'GET',
						uri: config.translation_url,
						body: 'text='+urlencode(speech)+'&target='+trans_lang,
						timeout : config.translation_timeout,
						headers: {
							'content-type': 'application/x-www-form-urlencoded'
						}
					};

					request(options, function (error, response, body) {
						if(error != null){
							console.error("translation_url : "+translation_url);
							console.error(error);
						}else{
							console.trace('statusCode : ' + response.statusCode);
							console.trace('body : ' + body);
						}
						if(error == null){
							//req.query.body = (JSON.parse(body)).data;
							req.query.body.result.fulfillment.speech = (JSON.parse(body)).result;
						}
						return resolve();
					});

				}else{
					return resolve();
				}
			}else{
				console.debug("pass redis data !!");
				var errStatus = 400;
				res.status(errStatus).send(util.res_err(req, errStatus, "empty rediskey !"));
				return reject();
			}
		}

	});
};

var _promise_lang_Translation_display_message = function(req,res){
	return new Promise(function(resolve, reject){

		if(req.query.output == 'sample' && req.query.template != ''){
			return resolve();
		}else{
			if(req.query.rediskey != ''){

				let check = /[ㄱ-ㅎ|ㅏ-ㅣ|가-힝]/;
				let display_message = req.query.body.result.fulfillment.display_message;
				//req.query.lang = 'en';
				if(req.query.lang != 'ko' && check.test(display_message)){

					let translation_url = config.translation_url;
					translation_url = translation_url + '?text='+display_message;

					let trans_lang = 'ke';
					//ke(한영),ek(영한),kc(한중),ck(중한),kj(한일),jk(일한)
					//한국어(ko), 영어(en), 중국어(zh), 일본어(ja)
					if(req.query.lang == 'en') trans_lang = 'ke';
					if(req.query.lang == 'zh') trans_lang = 'kc';
					if(req.query.lang == 'ja') trans_lang = 'kj';

					translation_url = translation_url + '&target='+trans_lang;
					console.debug("translation_url : "+translation_url);
					let request = require('request');
					let urlencode = require('urlencode');

					let options = {
						method: 'GET',
						uri: config.translation_url,
						body: 'text='+urlencode(display_message)+'&target='+trans_lang,
						timeout : config.translation_timeout,
						headers: {
							'content-type': 'application/x-www-form-urlencoded'
						}
					};

					request(options, function (error, response, body) {
						if(error != null){
							console.error("translation_url : "+translation_url);
							console.error(error);
						}else{
							console.trace('statusCode : ' + response.statusCode);
							console.trace('body : ' + body);
						}
						if(error == null){
							//req.query.body = (JSON.parse(body)).data;
							req.query.body.result.fulfillment.display_message = (JSON.parse(body)).result;
						}
						return resolve();
					});

				}else{
					return resolve();
				}
			}else{
				console.debug("pass redis data !!");
				var errStatus = 400;
				res.status(errStatus).send(util.res_err(req, errStatus, "empty rediskey !"));
				return reject();
			}
		}

	});
};


var _promise_debug_check = function(req,res){
	return new Promise(function(resolve, reject){

		if(req.query.debug != 'true'){
			let body = req.query.body;
			try{
				body.result.meta = '{}';
				delete body.result.meta;
				req.query.body = body;
			}catch(err){
				console.error(err);
			}
			return resolve();
		}else{
			return resolve();
		}


	});
};

var _promise_sendresult = function(req,res){
	return new Promise(function(resolve, reject){

		res.set({'Content-Type': 'text/json; charset=utf-8'});
		end = new Date();
		elapsed['sendresult'] = (end - start) + ' ms';
		res.send(util.res_ok(req, {data:req.query.body}, elapsed));

		console.debug('_promise_sendresult !');
		return resolve();
	});
};

function redisDataInsert(req){
	let key = uuidv1();
	let value = [];

	value.push("req_date");
	value.push(util.getDate() || '');

	value.push("channel_id");
	value.push(req.query.channel_id || '');

	value.push("domain_id");
	value.push(req.query.domain_id || '');

	value.push("raw_str");
	value.push(req.query.raw_str || '');

	value.push("in_str");
	value.push(req.query.in_str || '');

	value.push("user_id");
	value.push(req.query.user_id || '');

	value.push("session_id");
	// value.push(req.query.session_id || key);
	// yw 추가 ㄱ
	value.push(req.query.session_id || '');
	// yw 주석처리 ㄱ
	// value.push(req.sessionID);

	//value.push("parameters_lang");
	value.push("lang");
	value.push(req.query.parameters.lang || '');

	//value.push("parameters_dialogue_id");
	value.push("dialogue_id");
	//value.push(req.query.parameters.dialogue_id || uuidv4());
	value.push(req.query.dialogue_id);

	value.push("parameters");
	value.push(JSON.stringify(req.query.parameters) || '{}');

	value.push("req_body");
	value.push(JSON.stringify(req.query) || '{}');

	value.push("dialogue_status");
	value.push('request');

	value.push("meta_before");
	value.push(req.query.meta_before);

	value.push("action");
	value.push(req.query.action);

	value.push("response_type");
	value.push('');


	redis.hmset(key, value);
	redis.expire(key, config.redis_0_session_ttl);

	return key;
}


function redisDataInsertMeta(req){

	console.trace("req.query.user_id : "+ req.query.user_id);
	console.trace("req.query.response_type : "+ req.query.response_type);
	console.trace("req.query.dialogue_id : "+ req.query.dialogue_id);
	console.trace("req.query.body.result.meta : "+ JSON.stringify(req.query.body.result.meta));

	let key = req.query.session_id;
	let value = [];
	value.push("response_type");
	value.push(req.query.response_type);
	value.push("dialogue_id");
	value.push(req.query.dialogue_id);

	let chatflow_run_check = false;
	let step = req.query.body.result.meta.step || {};
	step.current = req.query.body.result.meta.step.current || 0;
	step.total = req.query.body.result.meta.step.total || 0;

	if(req.query.response_type == 'answer' && step.current != step.total){
		chatflow_run_check = true;
	}

	if(req.query.chatflow_run_check != undefined){
		chatflow_run_check = JSON.parse(req.query.chatflow_run_check);
	}

	value.push("chatflow_run_check");
	value.push(chatflow_run_check);
	value.push("step_current");
	value.push(step.current);
	value.push("step_total");
	value.push(step.total);

	if(req.query.response_type == 'prompt' || chatflow_run_check){
		value.push("meta_before");
		value.push(JSON.stringify(req.query.body.result.meta) || '{}');
		value.push("action");
		value.push(req.query.action || '{}');

	}else{
		console.debug("remove!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!meta_before");
		value.push("meta_before");
		value.push('{}');
		value.push("action");
		value.push('{}');
	}

	redis_meta.hmset(key, value);
	redis_meta.expire(key, config.redis_1_session_ttl);
	return key;
}

//***********************************************************************************************************
//  Process Logic Area (E)
//***********************************************************************************************************

var _promise_checktime = function(name){
	return new Promise(function(resolve, reject){
        // elapsed time
        end = new Date();
        elapsed[name] = (end - start) + ' ms';
        console.debug('_promise_checktime ! - '+name+' ['+elapsed[name]+']');
        return resolve();
    });
};

var _promise_errhandler = function(req,res,err){
	return new Promise(function(resolve, reject){
		if(typeof(err) != 'undefined'){
			console.error(err,filename);
		    //res.status(500).send(util.res_err(req, 500, err.message));

		    res.status(err.status || 500);
		    res.render('error', {
		    	message: err.message,
		    	error: err
		    });
		    return resolve();
		}else{
			return resolve();
		}
	});
};

module.exports = router;
