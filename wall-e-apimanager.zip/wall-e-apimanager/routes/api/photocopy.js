const readline = require('readline');
const fs = require('fs');
const http = require('http');

const test_jbt_file = '/mnt/c/TeAnaTextAnalytics-v1.0.0/data/collection/rqr-doc-test/archive/jbt/rqr-doc-test-201907206.json';
const ten_fold_validation_file = '/mnt/c/TeAnaTextAnalytics-v1.0.0/data/HwAvg.txt';

const top_no = 1;
const similarity_size = 10;

let excel_title = '시민번호\t민원제목\t민원내용\t처리부서\t처리부서\t';
for (let i = 1; i <= top_no; i++) {
    excel_title += '추천부서' + i + '\t추천부서' + i + '\t유사도\t';
}
excel_title += '일치여부\n';

const mapping_dept = {
    '6271161':'달성공원관리소',
    '6271159':'관리과'
};

// doc-test collection jbt 파일 로딩
new Promise(function (resolve, reject) {
    let arr_json = [];

    readline.createInterface({
        input: fs.createReadStream(test_jbt_file)
    }).on('line', function (line) {
        arr_json.push(JSON.parse(line));
    }).on('close', function () {
        resolve(arr_json);
    });
}).then(function (arr_json) {
    fs.writeFileSync(ten_fold_validation_file,
        excel_title
    );
    arr_json.forEach(function (json) {
        let cvl_rqr_no = json.cvl_rqr_no;
        let dept_cd = json.dept_cd;

        let response = '';
        http.get('http://127.0.0.1:12900/docToDoc?id=' + dept_cd + '-' + cvl_rqr_no + '&col=rqr-doc-test&t_col=rqr-doc', function (res) {
            res.on('data', function (chunk) {
                response += chunk;
            });

            res.on('end', function () {
                response = JSON.parse(response);

                let group_result = {};
                response.output.slice(0, similarity_size).forEach(function (res) {
                    let category = res.id.substring(0, res.id.indexOf('-'));

                    if (group_result.hasOwnProperty(category)) {
                        group_result[category] = {
                            cnt: group_result[category].cnt + 1,
                            sum_similarity: group_result[category].sum_similarity + res.similarity
                        }
                    } else {
                        group_result[category] = {
                            cnt: 1,
                            sum_similarity: res.similarity
                        };
                    }
                });

                let group_score = [];
                Object.keys(group_result).forEach(function (key) {
                    group_score.push({
                        key: key,
                        score: ib_avg(Object.keys(group_result).length, group_result[key].cnt, 0.7, group_result[key].sum_similarity)
                    });
                });

                group_score.sort(function (a, b) {
                    return a.score > b.score ? -1 : a.score < b.score ? 1 : 0;
                });

                let json_ttl = "";
                if(null != json.ttl){
                    json_ttl = json.ttl.replace(/[\r\n\t]/g, ' ') + '\t';
                } else {
                    json_ttl = ' ' + '\t';
                }



                let result = cvl_rqr_no + '\t' +
                    json_ttl +
                    json.cnts.replace(/[\r\n\t]/g, ' ') + '\t' +
                    mapping_dept[dept_cd] + '\t' +
                    dept_cd + '\t';

                let isInclude = false;
                for (let i = 0; i < top_no; i++) {
                    if (i < group_score.length) {
                        result += mapping_dept[group_score[i].key] + '\t' +
                            group_score[i].key + '\t' +
                            (group_score[i].score).toFixed(2) + '\t';

                        if (dept_cd === group_score[i].key) {
                            isInclude = true;
                        }
                    } else {
                        result += '-\t-\t-\t';
                    }
                }
                result += isInclude + '\n';

                fs.appendFileSync(ten_fold_validation_file, result);
            });
        });
    });
});

function ib_avg(m, n, a, score_sum) {
    return (a * (score_sum / m)) + (((1 - a) * (n / m)) * 100);
}


function softmax(arr) {
    return arr.map(function (value, index) {
        return Math.exp(value) / arr.map(function (y /*value*/) {
            return Math.exp(y)
        }).reduce(function (a, b) {
            return a + b
        })
    })
}
