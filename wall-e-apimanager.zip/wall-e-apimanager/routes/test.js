var express = require('express');
var router = express.Router();
var path = require('path');
var filename = path.basename(__filename);
var approot = require('app-root-path');
var util = require(approot + '/util/util');

// elapsed time
var elapsed = {};
var start, end;

// result
var body = {};

/* GET users listing. */
router.get('/', function(req, res) {
	promisshandler(req, res);
});

/* POST users listing. */
router.post('/', function(req, res) {
	promisshandler(req, res);
});


//***********************************************************************************************************
//  Process Logic Area (S)
//***********************************************************************************************************
var config = require(approot + '/config/config');

// elasticsearch
var es = require(approot + '/util/es');

// redis
var redis = require(approot + '/util/redis');

// -- promiss handler
var promisshandler = function(req,res){
	util.req_param('[TEST] 체크',req,filename);
	
	elapsed = {}; 
	body = {};
	start = new Date();
	if(req.method == "POST") req.query = req.body;

	Promise
	.all([_promise_paramcheck(req,res)])
	.then(function(){return _promise_checktime('paramcheck');})
	.then(function(){return _promise_work(req,res);})
	.then(function(){return _promise_checktime('work');})
	.then(function(){return _promise_scan(req,res);})
	.then(function(){return _promise_checktime('scan');})
	.then(function(){return _promise_sendresult(req,res);})
	.catch(function(err){return _promise_errhandler(req,res,err);})
	;

};

var _promise_paramcheck = function(req,res){
	return new Promise(function(resolve, reject){

		var err = req.validationErrors();
		if(err) {
			err.status = 400;
			res.status(400).send(util.res_err(req, 400, err[0].msg));
			console.error(err[0].msg,filename);
			return reject();
		}else{
			//init parameter
			req.query = req.query || '{}';
			return resolve();
		}

	});
};

var _promise_work = function(req,res){
	return new Promise(function(resolve, reject){
		var fs = require('fs');
		//var result = fs.readFileSync(approot+'/routes/api/sampleoutputparam.json', 'utf8');
		var result = "{}";
		result = JSON.parse(result);
        body = {data:result};
        

		let speech = "문의하신 ${물품보관대}에 대한 안내입니다.";
		let key = "물품보관대";
		let value = "XXX";

		speech = speech.replace(new RegExp("\\$\\{"+key+"\\}","g"), value);
		console.log(speech);

        //redis.set('key', 'value!', 'EX', 200);

		return resolve();
			
	});
};

var _promise_scan = function(req,res){
	return new Promise(function(resolve, reject){
		var fs = require('fs');
		//var result = fs.readFileSync(approot+'/routes/api/sampleoutputparam.json', 'utf8');
		var result = "{}";
		result = JSON.parse(result);
        body = {data:result};
        

        //redis.set('key', 'value!', 'EX', 200);

		//var redis_scanner = require('redis-scanner');
		//redis_scanner.bindScanners(redis);

		//let ip = req.header ( 'x-forwarded-for') || req.connection.remoteAddress;
		//console.log(ip);

		//console.log(req.sessionID);

		return resolve();
	});
};

var _promise_sendresult = function(req,res){
	return new Promise(function(resolve, reject){

		res.set({'Content-Type': 'text/json; charset=utf-8'});
		//res.send('');

		end = new Date();
		elapsed['sendresult'] = (end - start) + ' ms';
		res.send(util.res_ok(req, body, elapsed));

		console.debug('_promise_sendresult !');
		return resolve();
	});
};

//***********************************************************************************************************
//  Process Logic Area (E)
//***********************************************************************************************************

var _promise_checktime = function(name){
	return new Promise(function(resolve, reject){
        // elapsed time
        end = new Date();
        elapsed[name] = (end - start) + ' ms';
        console.debug('_promise_checktime ! - '+name+' ['+elapsed[name]+']');
        return resolve();
    });
};

var _promise_errhandler = function(req,res,err){
	return new Promise(function(resolve, reject){
		if(typeof(err) != 'undefined'){
			console.error(err,filename);
		    //res.status(500).send(util.res_err(req, 500, err.message));

		    res.status(err.status || 500);
		    res.render('error', {
		    	message: err.message,
		    	error: err
		    });
		    return resolve();
		}else{
			return resolve();
		}
	});
};

module.exports = router;