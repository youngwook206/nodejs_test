//config.js

var approot = require('app-root-path');
//var runmode = process.env.RUNMODE || "dev";
var configfile = require(approot + '/config/config.json');
var runmode = configfile.runmode;
var config = configfile[runmode];

console.info("*************** config *****************");
console.info("* runmode [dev/prod] : " + runmode);
console.info("* debug_level : " + config.debug_level);
console.info("* app_server_default_port : " + config.app_server_default_port);
console.info("****************************************");

module.exports = config;