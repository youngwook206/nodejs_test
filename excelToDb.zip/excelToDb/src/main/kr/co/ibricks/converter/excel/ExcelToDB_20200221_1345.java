package main.kr.co.ibricks.converter.excel;

import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.DateUtil;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;


public class ExcelToDB_20200221_1345 {
	/*
	 * @SuppressWarnings -- 컴파일시 컴파일 경고를 사용하지 않도록 설정할 수 있다.
	 * 
	 * resource -- 닫기 가능 유형의 자원 사용에 관련된 경고 억제
	 */
	@SuppressWarnings("resource")
	public String xlsReadExcute(String FilePath, List<Object> list) throws IOException {
		StringBuffer sb = new StringBuffer();
		// 파일을 읽기위해 엑셀파일을 가져온다
		FileInputStream fis = new FileInputStream(FilePath);
		HSSFWorkbook workbook = new HSSFWorkbook(fis);
		int rowindex = 0;
		int columnindex = 0;
		// 시트 수 (첫번째에만 존재하므로 0을 준다)
		// 만약 각 시트를 읽기위해서는 FOR문을 한번더 돌려준다
		HSSFSheet sheet = workbook.getSheetAt(0);
		// 행의 수
		int rows = sheet.getPhysicalNumberOfRows();
		System.out.println("[ xlsReadExcute ] 엑셀 rows : " + rows);
		for (rowindex = 1; rowindex < rows; rowindex++) {
			// 행을 읽는다
			HSSFRow row = sheet.getRow(rowindex);
			if (row != null) {
				// 셀의 수
				int cells = row.getPhysicalNumberOfCells();
				System.out.println("[ xlsReadExcute ] 엑셀 cells : " + cells);
				for (columnindex = 0; columnindex <= cells; columnindex++) {
					// 셀값을 읽는다
					HSSFCell cell = row.getCell(columnindex);
					String value = "";
					
					
					// 셀이 빈값일경우를 위한 널체크
					if (cell == null) {
						continue;
					} else {
						System.out.println("cell.getCellType() ===================? " + cell.getCellType()); 
						
//						switch (cell.getCellType()) {
//						case HSSFCell.CELL_TYPE_FORMULA:
//							value = cell.getCellFormula();
//							break;
//						case HSSFCell.CELL_TYPE_NUMERIC:
//							value = cell.getNumericCellValue() + "";
//							break;
//						case "STRING":
//						case HSSFCell.CELL_TYPE_STRING:
//							value = cell.getStringCellValue() + "";
//							break;
//						case HSSFCell.CELL_TYPE_BLANK:
//							value = cell.getBooleanCellValue() + "";
//							break;
//						case HSSFCell.CELL_TYPE_ERROR:
//							value = cell.getErrorCellValue() + "";
//							break;
//						}
						
						// 타입별로 내용 읽기
						/*
						switch (cell.getCellType()) {
						case HSSFCell.CELL_TYPE_FORMULA:
							value = cell.getCellFormula();
							break;
						case HSSFCell.CELL_TYPE_NUMERIC:
							value = cell.getNumericCellValue() + "";
							break;
						case HSSFCell.CellType.STRING:
//						case HSSFCell.CELL_TYPE_STRING:
							value = cell.getStringCellValue() + "";
							break;
						case HSSFCell.CELL_TYPE_BLANK:
							value = cell.getBooleanCellValue() + "";
							break;
						case HSSFCell.CELL_TYPE_ERROR:
							value = cell.getErrorCellValue() + "";
							break;
						}
						*/
						sb.append(list.get(columnindex)); // DOCID 포맷 세팅
						sb.append(value); // 실제 필드별 value값 세팅
						sb.append(System.getProperty("line.separator")); // 줄바꿈
																			// 처리
					}
				}
			}
		}
		return sb.toString();
	}

	
	/*
	 * 1. 엑셀파일 읽음
	 * 2. 시트데이터 읽음 
	 * 3.   시트 행 iter
	 *        행 -> 열 iter
	 *          열의 cell 의 value get
	 * */       
	@SuppressWarnings("resource")
	public int xlsxToOracle(String FilePath, Map<String, Integer> ntisA, String[] ntisDateA, int dateColumnindex, boolean addDOCID) throws IOException, ClassNotFoundException, SQLException {
		
		FileInputStream fis = new FileInputStream(FilePath);
		XSSFWorkbook workbook = new XSSFWorkbook(fis);
		int rowindex = 0;
		int columnindex = 0;
		/*
		int inc_idx = 0;
		*/
		
		// 시트 수 (첫번째에만 존재하므로 0을 준다)
		// 만약 각 시트를 읽기위해서는 FOR문을 한번더 돌려준다
		XSSFSheet sheet = workbook.getSheetAt(0);
		// 행의 수
		int rows = sheet.getPhysicalNumberOfRows();
		System.out.println("[ xlsReadExcute ] 엑셀 rows : " + rows + ", addDOCID : " + addDOCID);

		/*
		if (addDOCID == true) {
			inc_idx = 1;
		}
		*/

		//- [ STARET ] GET info : ntis fields
		Set<String> keys = ntisA.keySet();
		keys.forEach(key -> System.out.println(key));
		
		String insertFields = "";
		for (String key : keys) {
			if (!insertFields.equals(""))
				insertFields += ",";
			insertFields += key;
		}
		String insertValues = "";
		for (int i = 0; i < keys.size(); i++) {
			if (!insertValues.equals(""))
				insertValues += ",";
			insertValues += "?";
		}
		//- [ END ] GET info : ntis fields

		String sql = "INSERT INTO ntis_sbjt_test" + "(" + insertFields + ") " + "VALUES" + "(" + insertValues + ")";
		
		System.out.println("sql ====> " + sql);
		
		Connection conn = getConnection();
		PreparedStatement pstmt = conn.prepareStatement(sql);
		Class.forName("oracle.jdbc.driver.OracleDriver");

		for (rowindex = 0; rowindex < rows; rowindex++) {
			// 행을읽는다
			XSSFRow row = sheet.getRow(rowindex);
			if (row != null) {
				// 셀의 수
				int cells = row.getPhysicalNumberOfCells();
				System.out.println("[ xlsReadExcute ] 엑셀 cells : " + cells);
				
				
				for (columnindex = 0; columnindex <= cells; columnindex++) {
					XSSFCell cell = row.getCell(columnindex);
					String value = "";

					//--- [ START ] cell type check > set value
					if (cell == null) {
						continue;
					} else {
						value = getXssCellValue(cell, columnindex, ntisDateA);

						// set value 
						int setIndex = columnindex+1;
						
						System.out.println("columnindex+1 : " + setIndex);
						System.out.println("value : " + value);
						if(Arrays.stream(ntisDateA).anyMatch((setIndex+"")::equals)) {
							pstmt.setDate(setIndex, java.sql.Date.valueOf(value));
						} else {
							pstmt.setString(setIndex, value);
						}
					}
					//--- [ END ] cell type check > set value
				}

				pstmt.addBatch();
				pstmt.clearParameters();
			}
		}
		
		int[] testVal = pstmt.executeBatch();
		int returnCnt = testVal.length;
		if(returnCnt<0) {
			conn.rollback();
		}
		
		closeConnection(conn,pstmt);
		return returnCnt;
	}

	
	public String convertStringToDate(String dateString) throws IOException {
		Pattern pattern = Pattern
				.compile("^((19|20)\\d\\d)?([- /.])?(0[1-9]|1[012])([- /.])?(0[1-9]|[12][0-9]|3[01])$");
		Matcher matcher = pattern.matcher(dateString);

		if (matcher.find() == false) // 체크
		{
			System.out.println("matcher false !!!!!!!!!!!!!!!!!");
		} else {
			System.out.println("matcher true !!!!!!!!!!!!!!!!!");
		}

		String retStr = "";
		SimpleDateFormat transFormat1 = new SimpleDateFormat("yyyy-MM-dd");
		SimpleDateFormat transFormat2 = new SimpleDateFormat("yyyy-MM-dd");
		try {
			Date to = transFormat1.parse(dateString);
			System.out.println("to : " + to);

			retStr = transFormat2.format(to);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return retStr;
	}
	
	
	public String getXssCellValue(XSSFCell cell, int columnindex, String[] dateA) {
		String value="";
		
		// 타입별로 내용 읽기
		switch (cell.getCellType()) {
		
			case FORMULA:
				value = cell.getCellFormula();
				break;
				
			case NUMERIC:
				if(Arrays.stream(dateA).anyMatch((dateA+"")::equals)) {
					 
					if (DateUtil.isCellDateFormatted(cell)) {
						SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMddHHmmss");
						value = formatter.format(cell.getDateCellValue());
					} else {
						double ddata = cell.getNumericCellValue();
						value = String.valueOf(ddata);
					}
				} else {
					value = cell.getNumericCellValue() + "";
				}
				break;
				
			case STRING:
				if(Arrays.stream(dateA).anyMatch((dateA+"")::equals)) {
					value = cell.getStringCellValue() + "";
					try {
						System.out.println("columnindex : " + columnindex);
						value = convertStringToDate(value);
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				} else {
					value = cell.getStringCellValue() + "";
				}
				break;
				
			case BLANK:
				value = cell.getBooleanCellValue() + "";
				break;
				
			case ERROR:
				value = cell.getErrorCellValue() + "";
				break;
		}
		
		return value;
	}
	

	public Connection getConnection() throws SQLException {
		Connection conn;

		final String URL = "jdbc:oracle:thin:@192.168.0.102:1521:cola";
		final String ID = "cola"; // 접속 아이디
		final String PW = "cola@2020!"; // 비밀번호

		conn = DriverManager.getConnection(URL, ID, PW);
		conn.setAutoCommit(false);
		return conn;
	}
	
	
	public void closeConnection(Connection conn, PreparedStatement pstmt){
		try{
			//자원 반환
//			rs.close();
			pstmt.close();
			conn.close();
		}catch(Exception e){
			e.printStackTrace();
		}
	}

}
