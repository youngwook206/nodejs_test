package main.kr.co.ibricks.converter.main;

import java.io.IOException;
import java.sql.SQLException;
import java.util.Map;

import main.kr.co.ibricks.converter.excel.ExcelToDB;
import main.kr.co.ibricks.converter.mariadb.DbToDb;
import main.kr.co.ibricks.converter.vo.NtisType;

public class MigMariaDb {
	public static void main(String[] args) throws IOException, SQLException, ClassNotFoundException {
		
		System.out.println("MigMariaDb Start");
		DbToDb dbTodb = new DbToDb();
		dbTodb.insertMariaDb("2016");
			
	}
}
