package main.kr.co.ibricks.converter.vo;

//import java.util.ArrayList;
import java.util.LinkedHashMap;
//import java.util.List;
import java.util.Map;

public class NtisType {
	
	public Object type_2018 =  getTypeA();
	public Object type_2017 =  getTypeB();
	public Object type_2016 =  getTypeC();
	public String[] date_2018 =  getDateA();
	public String[] date_2017 =  getDateB();
	public String[] date_2016 =  getDateC();
	
	public Map<String, Integer> getTypeA() {
		Map <String, Integer> aMap = new LinkedHashMap<> ();
		
		aMap.put("SBMT_YEAR", 1);
		aMap.put("BSNSR_NM", 2);
		aMap.put("BSNSR_ORGN_NM", 3);
		aMap.put("CNTN_SBJT_YN_CD", 4);
		aMap.put("CNTN_SBJT_YN", 5);
		aMap.put("PRV_DTL_SBJT_NO", 6);
		aMap.put("PRV_SBJT_NO", 7);
		aMap.put("HIST_BSNSR_NM", 8);
		aMap.put("DTL_SBJT_NO", 9);
		aMap.put("SBJT_NO", 10);
		aMap.put("MNG_DTL_SBJT_NO", 11);
		aMap.put("MNG_SBJT_NO", 12);
		aMap.put("SBJT_NM", 13);
		aMap.put("TOT_STUDY_TRM_START", 14);
		aMap.put("TOT_STUDY_TRM_END", 15);
		aMap.put("RSCH_EXE_BODY_CD", 16);
		aMap.put("RSCH_EXE_BODY", 17);
		aMap.put("REGION_CD", 18);
		aMap.put("REGION", 19);
		aMap.put("LCL_GVMNT_CD", 20);
		aMap.put("LCL_GVMNT", 21);
		aMap.put("IDST_STDD_CL_CD_1_L", 22);
		aMap.put("IDST_STDD_CL_1_L", 23);
		aMap.put("IDST_STDD_CL_CD_1_M", 24);
		aMap.put("IDST_STDD_CL_1_M", 25);
		aMap.put("IDST_STDD_CL_CD_1_S", 26);
		aMap.put("IDST_STDD_CL_1_S", 27);
		aMap.put("IDST_STDD_CL_WEIT_1", 28);
		aMap.put("IDST_STDD_CL_CD_2_L", 29);
		aMap.put("IDST_STDD_CL_2_L", 30);
		aMap.put("IDST_STDD_CL_CD_2_M", 31);
		aMap.put("IDST_STDD_CL_2_M", 32);
		aMap.put("IDST_STDD_CL_CD_2_S", 33);
		aMap.put("IDST_STDD_CL_2_S", 34);
		aMap.put("IDST_STDD_CL_WEIT_2", 35);
		aMap.put("IDST_STDD_CL_CD_3_L", 36);
		aMap.put("IDST_STDD_CL_3_L", 37);
		aMap.put("IDST_STDD_CL_CD_3_M", 38);
		aMap.put("IDST_STDD_CL_3_M", 39);
		aMap.put("IDST_STDD_CL_CD_3_S", 40);
		aMap.put("IDST_STDD_CL_3_S", 41);
		aMap.put("IDST_STDD_CL_WEIT_3", 42);
		aMap.put("PRRT_IDST_CL_CD_L", 43);
		aMap.put("PRRT_IDST_CL_L", 44);
		aMap.put("PRRT_IDST_CL_CD_M", 45);
		aMap.put("PRRT_IDST_CL_M", 46);
		aMap.put("PRRT_IDST_CL_CD_S", 47);
		aMap.put("PRRT_IDST_CL_S", 48);
		aMap.put("APPL_FILD_CD_1", 49);
		aMap.put("APPL_FILD_1", 50);
		aMap.put("APPL_FILD_WEIT_1", 51);
		aMap.put("APPL_FILD_CD_2", 52);
		aMap.put("APPL_FILD_2", 53);
		aMap.put("APPL_FILD_WEIT_2", 54);
		aMap.put("APPL_FILD_CD_3", 55);
		aMap.put("APPL_FILD_3", 56);
		aMap.put("APPL_FILD_WEIT_3", 57);
		aMap.put("GRN_TCH_CL_CD", 58);
		aMap.put("GRN_TCH_CL", 59);
		aMap.put("TCH_6T_CD_L", 60);
		aMap.put("TCH_6T__L", 61);
		aMap.put("TCH_6T__CD_M", 62);
		aMap.put("TCH_6T__M", 63);
		aMap.put("TCH_6T__CD_S", 64);
		aMap.put("TCH_6T__S", 65);
		aMap.put("ECO_SOC_GOLE_CD", 66);
		aMap.put("ECO_SOC_GOLE", 67);
		aMap.put("CNTRY_STRTG_TCH_CD_L", 68);
		aMap.put("CNTRY_STRTG_TCH_L", 69);
		aMap.put("CNTRY_STRTG_TCH_CD_M", 70);
		aMap.put("CNTRY_STRTG_TCH_M", 71);
		aMap.put("CNTRY_STRTG_TCH_CD_S", 72);
		aMap.put("CNTRY_STRTG_TCH_S", 73);
		aMap.put("SMMR_RSCH_GOLE", 74);
		aMap.put("SMMR_RSCH_CN", 75);
		aMap.put("SMMR_EXPE_EFCT", 76);
		aMap.put("SMMR_HAN_KWD", 77);
		aMap.put("SMMR_ENG_KWD", 78);
		aMap.put("STUDY_TRM_START", 79);
		aMap.put("STUDY_TRM_END", 80);
		aMap.put("RPRSR_SPINS", 81);
		aMap.put("SBJT_SPINS", 82);
		aMap.put("SBJT_EXE_ORGN_NM", 83);
		aMap.put("BSNSR_REG_NO", 84);
		aMap.put("STUDY_DEV_STEP_CD", 85);
		aMap.put("STUDY_DEV_STEP", 86);
		aMap.put("DTL_SBJT_APPL_CD", 87);
		aMap.put("DTL_SBJT_APPL_CL", 88);
		aMap.put("GVMNT_RSCH_FNDS", 89);
		aMap.put("LABOR_COST_CASH", 90);
		aMap.put("LABOR_COST_GOODS", 91);
		aMap.put("DIRECT_COST_CASH", 92);
		aMap.put("DIRECT_COST_GOODS", 93);
		aMap.put("OVRHD_COST", 94);
		aMap.put("RPSL_RSCH_FNDS", 95);
		aMap.put("GOODS_COST", 96);
		aMap.put("MATCH_FUND_LOCAL_CASH", 97);
		aMap.put("MATCH_FUND_LOCAL_GOODS", 98);
		aMap.put("MATCH_FUND_UNIV_CASH", 99);
		aMap.put("MATCH_FUND_UNIV_GOODS", 100);
		aMap.put("MATCH_FUND_ENPR_L_CASH", 101);
		aMap.put("MATCH_FUND_ENPR_L_GOODS", 102);
		aMap.put("MATCH_FUND_ENPR_M_CASH", 103);
		aMap.put("MATCH_FUND_ENPR_M_GOODS", 104);
		aMap.put("MATCH_FUND_ENPR_S_CASH", 105);
		aMap.put("MATCH_FUND_ENPR_S_GOODS", 106);
		aMap.put("MATCH_FUND_ENPR_CASH", 107);
		aMap.put("MATCH_FUND_ENPR_GOODS", 108);
		aMap.put("MATCH_FUND_ETC_CASH", 109);
		aMap.put("MATCH_FUND_ETC_GOODS", 110);
		aMap.put("PRVT_RSCH_FNDS_TOT", 111);
		aMap.put("TOT_RSCH_FNDS_CASH", 112);
		aMap.put("TOT_RSCH_FNDS_GOODS", 113);
		aMap.put("TOT_RSCH_FNDS_SUM", 114);
		aMap.put("JONT_RSCH_YN_ENPR", 115);
		aMap.put("JONT_RSCH_YN_UNIV", 116);
		aMap.put("JONT_RSCH_YN_ORGN", 117);
		aMap.put("JONT_RSCH_YN_FRGN", 118);
		aMap.put("JONT_RSCH_YN_ETC", 119);
		aMap.put("CHF_RSCH_MBR_BLNG_ORGN_NM", 120);
		aMap.put("CHF_RSCH_MBR_BSNSR_REG_NO", 121);
		aMap.put("CHF_RSCH_MBR_SEX", 122);
		aMap.put("CHF_RSCH_MBR_MAJ", 123);
		aMap.put("CHF_RSCH_MBR_DEG", 124);
		
		aMap.put("C_ID", 125);
		
		return aMap; 
	}
	
	public String[] getDateA() {
		String[] dateList = new String[]{"14","15","79","80"};
		
		return dateList; 
	}
	
	
	public Map<String, Integer> getTypeB() {
		Map <String, Integer> aMap = new LinkedHashMap<> ();
		
		aMap.put("sbmt_year", 1);
		aMap.put("bsnsr_nm", 2);
		aMap.put("bsnsr_orgn_nm", 3);
		aMap.put("cntn_sbjt_yn", 4);
		aMap.put("prv_dtl_sbjt_no", 5);
		aMap.put("prv_sbjt_no", 6);
		aMap.put("hist_bsnsr_nm", 7);
		aMap.put("dtl_sbjt_no", 8);
		aMap.put("sbjt_no", 9);
		aMap.put("mng_dtl_sbjt_no", 10);
		aMap.put("mng_sbjt_no", 11);
		aMap.put("sbjt_nm", 12);
		aMap.put("tot_STUDY_TRM_start", 13);
		aMap.put("tot_STUDY_TRM_end", 14);
		aMap.put("rsch_exe_body_cd", 15);
		aMap.put("rsch_exe_body", 16);
		aMap.put("region_cd", 17);
		aMap.put("region", 18);
		aMap.put("lcl_gvmnt_cd", 19);
		aMap.put("lcl_gvmnt", 20);
		aMap.put("idst_stdd_cl_cd_1_l", 21);
		aMap.put("idst_stdd_cl_1_l", 22);
		aMap.put("idst_stdd_cl_cd_1_m", 23);
		aMap.put("idst_stdd_cl_1_m", 24);
		aMap.put("idst_stdd_cl_cd_1_s", 25);
		aMap.put("idst_stdd_cl_1_s", 26);
		aMap.put("idst_stdd_cl_weit_1", 27);
		aMap.put("idst_stdd_cl_cd_2_l", 28);
		aMap.put("idst_stdd_cl_2_l", 29);
		aMap.put("idst_stdd_cl_cd_2_m", 30);
		aMap.put("idst_stdd_cl_2_m", 31);
		aMap.put("idst_stdd_cl_cd_2_s", 32);
		aMap.put("idst_stdd_cl_2_s", 33);
		aMap.put("idst_stdd_cl_weit_2", 34);
		aMap.put("idst_stdd_cl_cd_3_l", 35);
		aMap.put("idst_stdd_cl_3_l", 36);
		aMap.put("idst_stdd_cl_cd_3_m", 37);
		aMap.put("idst_stdd_cl_3_m", 38);
		aMap.put("idst_stdd_cl_cd_3_s", 39);
		aMap.put("idst_stdd_cl_3_s", 40);
		aMap.put("idst_stdd_cl_weit_3", 41);
		aMap.put("appl_fild_cd_1", 42);
		aMap.put("appl_fild_1", 43);
		aMap.put("appl_fild_weit_1", 44);
		aMap.put("appl_fild_cd_2", 45);
		aMap.put("appl_fild_2", 46);
		aMap.put("appl_fild_weit_2", 47);
		aMap.put("appl_fild_cd_3", 48);
		aMap.put("appl_fild_3", 49);
		aMap.put("appl_fild_weit_3", 50);
		aMap.put("tch_6t_cd_l", 51);
		aMap.put("tch_6t__l", 52);
		aMap.put("tch_6t__cd_m", 53);
		aMap.put("tch_6t__m", 54);
		aMap.put("tch_6t__cd_s", 55);
		aMap.put("tch_6t__s", 56);
		aMap.put("eco_soc_gole_cd", 57);
		aMap.put("eco_soc_gole", 58);
		aMap.put("cntry_strtg_tch_cd_l", 59);
		aMap.put("cntry_strtg_tch_l", 60);
		aMap.put("cntry_strtg_tch_cd_m", 61);
		aMap.put("cntry_strtg_tch_m", 62);
		aMap.put("cntry_strtg_tch_cd_s", 63);
		aMap.put("cntry_strtg_tch_s", 64);
		aMap.put("smmr_rsch_gole", 65);
		aMap.put("smmr_rsch_cn", 66);
		aMap.put("smmr_EXPE_EFCT", 67);
		aMap.put("smmr_HAN_KWD", 68);
		aMap.put("smmr_ENG_KWD", 69);
		aMap.put("STUDY_TRM_start", 70);
		aMap.put("STUDY_TRM_end", 71);
		aMap.put("RPRSR_SPINS", 72);
		aMap.put("sbjt_spins", 73);
		aMap.put("SBJT_EXE_orgn_nm", 74);
		aMap.put("BSNSR_REG_NO", 75);
		aMap.put("STUDY_DEV_step_cd", 76);
		aMap.put("STUDY_DEV_step", 77);
		aMap.put("gvmnt_rsch_fnds", 78);
		aMap.put("labor_cost_cash", 79);
		aMap.put("labor_cost_goods", 80);
		aMap.put("direct_cost_cash", 81);
		aMap.put("direct_cost_goods", 82);
		aMap.put("ovrhd_cost", 83);
		aMap.put("rpsl_rsch_fnds", 84);
		aMap.put("goods_cost", 85);
		aMap.put("match_fund_local_cash", 86);
		aMap.put("match_fund_local_goods", 87);
		aMap.put("match_fund_univ_cash", 88);
		aMap.put("match_fund_univ_goods", 89);
		aMap.put("match_fund_enpr_l_cash", 90);
		aMap.put("match_fund_enpr_l_goods", 91);
		aMap.put("match_fund_enpr_m_cash", 92);
		aMap.put("match_fund_enpr_m_goods", 93);
		aMap.put("match_fund_enpr_s_cash", 94);
		aMap.put("match_fund_enpr_s_goods", 95);
		aMap.put("match_fund_etc_cash", 96);
		aMap.put("match_fund_etc_goods", 97);
		aMap.put("prvt_rsch_fnds_tot", 98);
		aMap.put("tot_rsch_fnds_cash", 99);
		aMap.put("tot_rsch_fnds_goods", 100);
		aMap.put("tot_rsch_fnds_sum", 101);
		aMap.put("jont_rsch_yn_enpr", 102);
		aMap.put("jont_rsch_yn_univ", 103);
		aMap.put("jont_rsch_yn_orgn", 104);
		aMap.put("jont_rsch_yn_frgn", 105);
		aMap.put("jont_rsch_yn_etc", 106);
		aMap.put("chf_rsch_mbr_BLNG_ORGN_NM", 107);
//		aMap.put("chf_rsch_mbr_BSNSR_REG_NO", 108);
		aMap.put("chf_rsch_mbr_sex", 108);
		aMap.put("chf_rsch_mbr_maj", 109);
		aMap.put("chf_rsch_mbr_deg", 110);
		
		aMap.put("C_ID", 111);
		
		return aMap; 
	}
	
	public String[] getDateB() {
		String[] dateList = new String[]{"13","14","70","71"};
		
		return dateList; 
	}
	
	
	public Map<String, Integer> getTypeC() {
		Map <String, Integer> aMap = new LinkedHashMap<> ();
		
		aMap.put("sbmt_year", 1);
		aMap.put("sbjt_no", 2);
		aMap.put("cntn_sbjt_yn", 3);
		aMap.put("prv_sbjt_no", 4);
		aMap.put("temp_col", 5);
		aMap.put("bsnsr_orgn_nm", 6);
		aMap.put("bsnsr_nm", 7);
		aMap.put("sbjt_nm", 8);
		aMap.put("study_dev_step", 9);
		aMap.put("region", 10);
		aMap.put("tot_study_trm_start", 11);
		aMap.put("tot_study_trm_end", 12);
		aMap.put("gvmnt_rsch_fnds", 13);
		aMap.put("match_fund_local_cash", 14);
		aMap.put("match_fund_local_goods", 15);
		aMap.put("match_fund_univ_cash", 16);
		aMap.put("match_fund_univ_goods", 17);
		aMap.put("match_fund_enpr_l_cash", 18);
		aMap.put("match_fund_enpr_l_goods", 19);
		aMap.put("match_fund_enpr_m_cash", 20);
		aMap.put("match_fund_enpr_m_goods", 21);
		aMap.put("match_fund_enpr_s_cash", 22);
		aMap.put("match_fund_enpr_s_goods", 23);
		aMap.put("match_fund_etc_cash", 24);
		aMap.put("match_fund_etc_goods", 25);
		aMap.put("smmr_rsch_gole", 26);
		aMap.put("smmr_rsch_cn", 27);
		aMap.put("smmr_expe_efct", 28);
		aMap.put("smmr_han_kwd", 29);
		aMap.put("smmr_eng_kwd", 30);
		
		aMap.put("C_ID", 31);
		
		return aMap; 
	}
	
	public String[] getDateC() {
		String[] dateList = new String[]{"10","11"};
		
		return dateList; 
	}
	
	
}
