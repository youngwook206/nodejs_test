package main.kr.co.ibricks.converter.main;

import java.io.IOException;
import java.sql.SQLException;
import java.util.Map;

import main.kr.co.ibricks.converter.excel.ExcelToDB;
import main.kr.co.ibricks.converter.vo.NtisType;

public class ExcelToOracle {
	public static void main(String[] args) throws IOException, SQLException, ClassNotFoundException {
		
		ExcelToDB RE = new ExcelToDB();					// 엑셀내용 추출 객체
		
//		String inputFilePath = "/mnt/d/011.TEST/data/2018_NTIS_과제_DB.xlsx";
//		String inputFilePath = "D:\\011.TEST\\data\\2018_NTIS_과제_DB_test.xlsx";
//		String inputFilePath = "D:\\011.TEST\\data\\2018_NTIS_과제_DB.xlsx";
//		String inputFilePath = "D:\\011.TEST\\data\\2017_NTIS_과제_DB.xlsx";
//		String inputFilePath = "D:\\011.TEST\\data\\2017_NTIS_과제_DB_ERRORCHECK.xlsx";
		String inputFilePath = "D:\\011.TEST\\data\\2016_NTIS_과제.xlsx";
//		String inputFilePath = "D:\\011.TEST\\data\\2015_사업과제정보_DB.xlsx";
//		String inputFilePath = "D:\\011.TEST\\data\\2014_사업과제정보_DB.xlsx";
//		String inputFilePath = "D:\\011.TEST\\data\\2013_사업과제정보_DB.xlsx";
//		String inputFilePath = "D:\\011.TEST\\data\\2012_사업과제정보_DB.xlsx";
//		String inputFilePath = "D:\\011.TEST\\data\\2011_사업과제정보_DB.xlsx";
//		String inputFilePath = "D:\\011.TEST\\data\\2010_사업과제정보_DB.xlsx";
//		String inputFilePath = "D:\\011.TEST\\data\\2009_사업과제정보_DB.xlsx";
//		String inputFilePath = "D:\\011.TEST\\data\\2000_사업과제정보_DB.xlsx";
//		String inputFilePath = "data/input/2018_NTIS_sbjt_test_1.xlsx";
		String c_id_prefix = args[0];
		
		NtisType ntisT = new NtisType();
//		Map<String, Integer> ntisObj = (Map<String, Integer>) ntisT.type_2018;	//2018
//		String[] ntisDateList = ntisT.date_2018;	//2018

//		Map<String, Integer> ntisObj = (Map<String, Integer>) ntisT.type_2017;	//2017
//		String[] ntisDateList = ntisT.date_2017;	//2017
		
		Map<String, Integer> ntisObj = (Map<String, Integer>) ntisT.type_2016;	//2017
		String[] ntisDateList = ntisT.date_2016;	//2017
		
		System.out.println("ntisA size : " + ntisObj.size());
		
		int xo;
		try {
			xo = RE.xlsxToOracle(inputFilePath, ntisObj, ntisDateList, c_id_prefix);
			System.out.println("insert to oracle : " + xo);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			
	}
}
