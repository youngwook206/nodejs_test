package main.kr.co.ibricks.converter.mariadb;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class DbToDb {
	
	public int insertMariaDb(String sbjt_year) {
		int retCnt=0;
		
		String sql="select * from ntis_sbjt_2016";
		
		Connection conn = null;
		try {
			conn = getConnection();
			ResultSet rs = null;
			PreparedStatement inp_pstmt = conn.prepareStatement(sql);
			rs = inp_pstmt.executeQuery();
			while(rs.next()) {
				String c_id=rs.getString("c_id");
				System.out.println("c_id : " + c_id);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return retCnt;
	}
	
	public Connection getConnection() throws SQLException {
		Connection conn;

		// local mariadb
		final String URL = "jdbc:mariadb://localhost:3306/study_db";	//local cola
		final String ID = "study_user"; 								// 접속 아이디
		final String PW = "study!@"; 									// 비밀번호	- local cola

		conn = DriverManager.getConnection(URL, ID, PW);
		conn.setAutoCommit(true);
		return conn;
	}
	
	
	public void closeConnection(Connection conn, PreparedStatement pstmt){
		try{
			//자원 반환
//			rs.close();
			pstmt.close();
			conn.close();
		}catch(Exception e){
			e.printStackTrace();
		}
	}
}
