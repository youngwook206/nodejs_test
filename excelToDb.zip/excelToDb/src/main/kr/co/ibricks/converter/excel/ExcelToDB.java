package main.kr.co.ibricks.converter.excel;

import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


import org.apache.poi.ss.usermodel.DateUtil;
import org.apache.poi.xssf.usermodel.XSSFCell;

public class ExcelToDB {
	
	
	/*
	 * 1. 엑셀파일 읽음
	 * 2. 시트데이터 읽음 
	 * 3.   시트 행 iter
	 *        행 -> 열 iter
	 *          열의 cell 의 value get
	 * */       
	@SuppressWarnings("resource")
	public int xlsxToOracle(String filePath, Map<String, Integer> ntisA, String[] ntisDateA, String c_id_prefix) {
		
		//- [ STARET ] GET info : ntis fields
		Set<String> keys = ntisA.keySet();
		keys.forEach(key -> System.out.println(key));
		
		String insertFields = "";
		for (String key : keys) {
			if (!insertFields.equals(""))
				insertFields += ",";
			insertFields += key;
		}
		String insertValues = "";
		for (int i = 0; i < keys.size(); i++) {
			if (!insertValues.equals(""))
				insertValues += ",";
			insertValues += "?";
		}
		//- [ END ] GET info : ntis fields

		String sql = "INSERT INTO ntis_sbjt_2016" + "(" + insertFields + ") " + "VALUES" + "(" + insertValues + ")";
		
		System.out.println("sql ====> " + sql);
		
		int returnCnt = 0;
		try {
			Connection conn;
			conn = getConnection();
			
			PreparedStatement pstmt = conn.prepareStatement(sql);
//			Class.forName("oracle.jdbc.driver.OracleDriver");
			
			
			File file = new File(filePath);
			ExcelSheetHandler excelSheetHandler = null;
			try {
				excelSheetHandler = ExcelSheetHandler.readExcel(file);
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			List<List<String>> excelDatas = excelSheetHandler.getRows();
			
			System.out.println("excelDatas => " + excelDatas.size());
			 
			int iCol = 0;    //컬럼 구분값
			int iRow = 0;    //행 구분값
			int[] testVal;
			 
			for(List<String> dataRow : excelDatas){
				String c_id = c_id_prefix + "-" + (iRow+1);
				
			    for(String str : dataRow){
			    	iCol++;
//			    	System.out.println("iCol => " + iCol);
//			    	System.out.println("str => " + str);
			    	// set value 
			    	
			    	//2016 temp
			    	if(iCol>=13 && iCol<=25) {
			    		pstmt.setString(iCol, str.replaceAll("[,]",""));
			    	}else{
			    		pstmt.setString(iCol, str);
			    	}
			    	
			    	//general
//			    	pstmt.setString(iCol, str);
			    	/*
					if(Arrays.stream(ntisDateA).anyMatch((iCol+"")::equals)) {
						try {
							if(null!=str && !"".equals(str)) {
								pstmt.setDate(iCol, java.sql.Date.valueOf(str));
							} else {
								pstmt.setDate(iCol, null);
//								setNull(iCol,java.sql.Types.DATE);
							}
						} catch(SQLException e) {
							System.out.println("exception data => " + str);
							e.printStackTrace();
						}
					} else {
						pstmt.setString(iCol, str);
//						System.out.println("str : " + str);
//						if(null!=str && byteCheck(str, 4000)) {
//							pstmt.setString(iCol, str);
//							System.out.println("iRow: "+iRow);
//							System.out.println("iCol: "+iCol);
//						} else {
//							pstmt.setString(iCol, str);
//						}
					}
					*/
			    }
			    //add C_ID			    
			    pstmt.setString(iCol+1, c_id);
			    
			    pstmt.addBatch();
				pstmt.clearParameters();
			    iCol = 0;
			    iRow++;
			    if(iRow % 1000 == 0) {
			    	System.out.println("iRow : " + iRow);
			    	
			    	System.out.println("a. excuteBatch Run start");
			    	try {
		    			testVal = pstmt.executeBatch();
			    		returnCnt += testVal.length;
						System.out.println("a. returnCnt : " + returnCnt);
			    		
			    	} catch(Exception e3) {
			    		System.out.println("");
			    		e3.printStackTrace();
			    	}
					
					if(returnCnt<0) {
						conn.rollback();
					}
			    }
//			    
//			    if(iRow % 1000 == 0) {
//			    	
//			    }
			}
	
			System.out.println("b. excuteBatch Run start");
			testVal = pstmt.executeBatch();
			returnCnt += testVal.length;
			System.out.println("b. returnCnt : " + returnCnt);
			if(returnCnt<0) {
				conn.rollback();
			}
			
			closeConnection(conn,pstmt);
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		return returnCnt;
	}
	
	

	
	public String convertStringToDate(String dateString) throws IOException {
		Pattern pattern = Pattern
				.compile("^((19|20)\\d\\d)?([- /.])?(0[1-9]|1[012])([- /.])?(0[1-9]|[12][0-9]|3[01])$");
		Matcher matcher = pattern.matcher(dateString);

		if (matcher.find() == false) // 체크
		{
			System.out.println("matcher false !!!!!!!!!!!!!!!!!");
		} else {
			System.out.println("matcher true !!!!!!!!!!!!!!!!!");
		}

		String retStr = "";
		SimpleDateFormat transFormat1 = new SimpleDateFormat("yyyy-MM-dd");
		SimpleDateFormat transFormat2 = new SimpleDateFormat("yyyy-MM-dd");
		try {
			Date to = transFormat1.parse(dateString);
//			System.out.println("to : " + to);

			retStr = transFormat2.format(to);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return retStr;
	}
	
	
	public String getXssCellValue(XSSFCell cell, int columnindex, String[] dateA) {
		String value="";
		
		// 타입별로 내용 읽기
		switch (cell.getCellType()) {
		
			case FORMULA:
				value = cell.getCellFormula();
				break;
				
			case NUMERIC:
				if(Arrays.stream(dateA).anyMatch((dateA+"")::equals)) {
					 
					if (DateUtil.isCellDateFormatted(cell)) {
						SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMddHHmmss");
						value = formatter.format(cell.getDateCellValue());
					} else {
						double ddata = cell.getNumericCellValue();
						value = String.valueOf(ddata);
					}
				} else {
					value = cell.getNumericCellValue() + "";
				}
				break;
				
			case STRING:
				if(Arrays.stream(dateA).anyMatch((dateA+"")::equals)) {
					value = cell.getStringCellValue() + "";
					try {
						System.out.println("columnindex : " + columnindex);
						value = convertStringToDate(value);
					} catch (IOException e) {
						e.printStackTrace();
					}
				} else {
					value = cell.getStringCellValue() + "";
				}
				break;
				
			case BLANK:
				value = cell.getBooleanCellValue() + "";
				break;
				
			case ERROR:
				value = cell.getErrorCellValue() + "";
				break;
		}
		
		return value;
	}
	
	public boolean byteCheck(String txt, int standardByte) {
//        if (TsUtil.empty(txt)) { return true; }
 
        // 바이트 체크 (영문 1, 한글 2, 특문 1)
        int en = 0;
        int ko = 0;
        int etc = 0;
 
        char[] txtChar = txt.toCharArray();
        for (int j = 0; j < txtChar.length; j++) {
            if (txtChar[j] >= 'A' && txtChar[j] <= 'z') {
                en++;
            } else if (txtChar[j] >= '\uAC00' && txtChar[j] <= '\uD7A3') {
                ko++;
                ko++;
            } else {
                etc++;
            }
        }
 
        int txtByte = en + ko + etc;
        if (txtByte > standardByte) {
            return false;
        } else {
            return true;
        }
 
    }
	

	public Connection getConnection() throws SQLException {
		Connection conn;

		// local mariadb
		final String URL = "jdbc:mariadb://localhost:3306/study_db";	//local cola
		final String ID = "study_user"; 								// 접속 아이디
		final String PW = "study!@"; 									// 비밀번호	- local cola
		
		/*
		// local oracle
		final String URL = "jdbc:oracle:thin:@localhost:1521:orcl";	//local cola
//		final String URL = "jdbc:oracle:thin:@192.168.0.102:1521:cola";	//ibricks cola
		final String ID = "cola"; // 접속 아이디
		final String PW = "cola2020"; // 비밀번호	- local cola
		*/
//		final String PW = "cola@2020!"; // 비밀번호	- ibricks cola

		conn = DriverManager.getConnection(URL, ID, PW);
		conn.setAutoCommit(true);
		return conn;
	}
	
	
	public void closeConnection(Connection conn, PreparedStatement pstmt){
		try{
			//자원 반환
//			rs.close();
			pstmt.close();
			conn.close();
		}catch(Exception e){
			e.printStackTrace();
		}
	}

}
