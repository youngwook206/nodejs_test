package main.kr.co.ibricks.util;

import java.sql.Connection;
//import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
//import java.sql.SQLException;
//import java.sql.Statement;

public class DBManager {
	Connection con;
    PreparedStatement pstmt;
    ResultSet rs;
    
    final String URL = "jdbc:oracle:thin:@211.239.150.101:1521:cola";    
    // 데이터베이스 접속 url
    final String ID = "cola";    // 접속 아이디
    final String PW = "cola@2020!";    // 비밀번호
    
    DBManager(){
        try {
            Class.forName("oracle.jdbc.driver.OracleDriver");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }


}
