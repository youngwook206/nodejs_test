package main.kr.co.ibricks.util;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class FileUtil {
	public void ExcuteFileWriter(StringBuffer result, String FilePath) {
        try{
        	BufferedWriter fw = new BufferedWriter(new FileWriter(FilePath, true));
            // BufferedWriter 와 FileWriter를 조합하여 사용 (속도 향상)
            // 파일안에 문자열 쓰기
            fw.write(result.toString());
            fw.flush();
            // 객체 닫기
            fw.close(); 
        }catch(Exception e){
            e.printStackTrace();
        }
	}
	
	public List<Map<String,Object>> ExcuteFileRead(String FilePath, List<Object> list) {
		FileReader fr = null;
		BufferedReader br = null;
		StringBuffer sb = new StringBuffer();
		
		//임의의 VO가 되주는 MAP 객체
		Map<String,Object> map = null;
		List<Map<String,Object>> lists = new ArrayList<Map<String,Object>>();
	 
		try{
			// "ReadFile.txt" 파일을 읽는 FileReader 객체 생성
			// BufferedReader 객체 생성
			fr = new FileReader(FilePath);
			br = new BufferedReader(fr);
			String s = null;
			
			// ReadFile.txt 에서 한줄씩 읽어서 BufferedRaeder에 저장한다.
			int i = 0;
			while((s=br.readLine())!=null){
				if(i == list.size()){
					lists.add(map);
					i = 0;
				}
				
				if( s.indexOf( list.get(0).toString() ) > -1 ){
					map = new HashMap<String,Object>();
				}
				map.put(list.get(i).toString(), s);
				
				// 읽은 데이터(한줄)을 BufferedWriter에 쓴다.
				// 한줄씩 읽으므로, newLine() 메소드로 줄바꿈을 해준다.
				sb.append(s);
				sb.append(System.getProperty("line.separator"));
				i++;
			}
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			// BufferedReader FileReader를 닫아준다.
			if(br != null) try{br.close();}catch(IOException e){}
			if(fr != null) try{fr.close();}catch(IOException e){}
		}
		return lists;
	}

}
