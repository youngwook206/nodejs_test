package com.ibricks.xml.main;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.logging.Logger;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.ibricks.xml.model.Jako;
import com.ibricks.xml.service.AddBatchService;
import com.ibricks.xml.service.JakoHandler;

public class JakoRunner  {
//	@Autowired
	AddBatchService addBatchService = new AddBatchService();
	
	
	public void parseJako(String fromDate, String until) throws ParserConfigurationException, SAXException, IOException, ParseException {
		
		// Date start
		SimpleDateFormat transFormat = new SimpleDateFormat("yyyyMMdd");
		Date callDate = transFormat.parse(fromDate);
		
		while(true) {
			
			Calendar cal = Calendar.getInstance();
			cal.setTime(callDate);
//			cal.add(Calendar.DAY_OF_YEAR, 1);
			
			String callStr =  transFormat.format(cal.getTime());
			System.out.println("callStr : " + callStr);
			// Date end
			
			String jakoUrl="http://stoai.ndsl.kr/servlet/OAIProvider2?";
			String jakoParam="verb=ListRecords&"
							+ "metadataPrefix=oai_dc&"
							+ "set=JAKO&from="+callStr+"&"
							+ "until="+callStr;
			String callUrl = jakoUrl+jakoParam;
			String tokenVal="";
			
			while(true) {
				System.out.println("nowUrl : " + callUrl);
				urlParseAndInsert(callUrl);
				
				try {
					tokenVal=getToekn(callUrl);
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
				if(!"empty".equals(tokenVal)) {
					callUrl=jakoUrl+
							"verb=ListRecords&metadataPrefix=oai_dc&resumptionToken="+
							tokenVal;
					System.out.println("nextUrl : " + callUrl);
				} else {
					System.out.println("while break !!!!!!!!!!!");
					break;
				}
			}
			
			cal.add(Calendar.DAY_OF_YEAR, 1);
			int callInt = Integer.parseInt(callStr); 
			int untilInt = Integer.parseInt(until);
			System.out.println("callInt:"+callInt + " / untilInt:"+untilInt);
			if(callInt >= untilInt){
				System.out.println("date check ==> break !!");
				break;
			}
			callDate=cal.getTime();
			int checkDate=cal.get(cal.DATE);
			System.out.println("cal.DATE : " + cal.get(cal.DATE));
			if(checkDate%10==0) {
				try {
					System.out.println("Thread.sleep 3000");
					Thread.sleep(3000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			
			
			
		}

		
	}
	
	public void urlParseAndInsert(String url) throws ParserConfigurationException, SAXException, IOException {
		SAXParserFactory factory = SAXParserFactory.newInstance();
		SAXParser saxParserJ = factory.newSAXParser();
		
		JakoHandler jakoHandler = new JakoHandler(); 
		System.out.println("[urlParseAndInsert] url : " + url);
//		saxParserJ.parse
		saxParserJ.parse(url, jakoHandler);
		
		//get XML data
		Jako website = new Jako();
		website = jakoHandler.getWebsite();
		
		//put Mysql
		if(null != website.getJakoList()) {
			addBatchService.insertJakoToMysql(website);
		}
		
//	    System.out.println(jakoHandler.getWebsite());
	}
	
	
	public String getToekn(String url) throws Exception {
		String ret="empty";
		
		DocumentBuilderFactory dbFactoty = DocumentBuilderFactory.newInstance();
		DocumentBuilder dBuilder = dbFactoty.newDocumentBuilder();
		Document doc = dBuilder.parse(url);
		doc.getDocumentElement().normalize();
		
		NodeList nList = doc.getElementsByTagName("ListRecords");
		for(int temp = 0; temp < nList.getLength(); temp++){		
			Node nNode = nList.item(temp);
			if(nNode.getNodeType() == Node.ELEMENT_NODE){
				Element eElement = (Element) nNode;
				ret = getTagValue("resumptionToken", eElement);
				
			}
		}
		if(null != ret) {
			System.out.println("��ȯ�� : " + ret);
		} else {
			ret = "empty";
			System.out.println("��ȯ�� : " + ret);
		}
		return ret;
	  }
	
	private String getTagValue(String tag, Element eElement) {
		Node boolNode = eElement.getElementsByTagName(tag).item(0);
		Node nValue = null;
		NodeList nlList=null;
		if(null != boolNode) {
			nlList = boolNode.getChildNodes();
			nValue = (Node) nlList.item(0);
		    if(nValue == null) 
		        return null;
		} else {
		    return null;
		}
	    return nValue.getNodeValue();
	}
}