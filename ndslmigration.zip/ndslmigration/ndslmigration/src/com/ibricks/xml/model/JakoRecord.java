package com.ibricks.xml.model;

public class JakoRecord {
	//header
		private String identifier;
		private String datestamp;
		private String setSpec;
		
		//metadata node
		private String title_h;
		private String title_e;
		private String title_eq;
		private String author;//list
		private String affiliation;//list
		private String publish_date;
		private String publisher;
	    private String journal_title;
	    private String issn;
	    private String volume;
	    private String page;
	    private String subject;
	    private String abstract_h;
	    private String abstract_e;
	    private String toc;
	    private String keyword;
	    private String location_org;
	    private String publication_country;
	    private String language;
	    private String reference;
	    private String data_flag;
	    private String format;
	    private String deep_link;
	    private String contents_flag;
	    private String charge;
	    private String contents_url;
	    
		public String getIdentifier() {
			return identifier;
		}
		public void setIdentifier(String identifier) {
			this.identifier = identifier;
		}
		public String getDatestamp() {
			return datestamp;
		}
		public void setDatestamp(String datestamp) {
			this.datestamp = datestamp;
		}
		public String getSetSpec() {
			return setSpec;
		}
		public void setSetSpec(String setSpec) {
			this.setSpec = setSpec;
		}
		public String getTitle_h() {
			return title_h;
		}
		public void setTitle_h(String title_h) {
			this.title_h = title_h;
		}
		public String getTitle_e() {
			return title_e;
		}
		public void setTitle_e(String title_e) {
			this.title_e = title_e;
		}
		public String getTitle_eq() {
			return title_eq;
		}
		public void setTitle_eq(String title_eq) {
			this.title_eq = title_eq;
		}
		public String getAuthor() {
			return author;
		}
		public void setAuthor(String author) {
			this.author = author;
		}
		public String getAffiliation() {
			return affiliation;
		}
		public void setAffiliation(String affiliation) {
			this.affiliation = affiliation;
		}
		public String getPublish_date() {
			return publish_date;
		}
		public void setPublish_date(String publish_date) {
			this.publish_date = publish_date;
		}
		public String getPublisher() {
			return publisher;
		}
		public void setPublisher(String publisher) {
			this.publisher = publisher;
		}
		public String getJournal_title() {
			return journal_title;
		}
		public void setJournal_title(String journal_title) {
			this.journal_title = journal_title;
		}
		public String getIssn() {
			return issn;
		}
		public void setIssn(String issn) {
			this.issn = issn;
		}
		public String getVolume() {
			return volume;
		}
		public void setVolume(String volume) {
			this.volume = volume;
		}
		public String getPage() {
			return page;
		}
		public void setPage(String page) {
			this.page = page;
		}
		public String getSubject() {
			return subject;
		}
		public void setSubject(String subject) {
			this.subject = subject;
		}
		public String getAbstract_h() {
			return abstract_h;
		}
		public void setAbstract_h(String abstract_h) {
			this.abstract_h = abstract_h;
		}
		public String getAbstract_e() {
			return abstract_e;
		}
		public void setAbstract_e(String abstract_e) {
			this.abstract_e = abstract_e;
		}
		public String getToc() {
			return toc;
		}
		public void setToc(String toc) {
			this.toc = toc;
		}
		public String getKeyword() {
			return keyword;
		}
		public void setKeyword(String keyword) {
			this.keyword = keyword;
		}
		public String getLocation_org() {
			return location_org;
		}
		public void setLocation_org(String location_org) {
			this.location_org = location_org;
		}
		public String getPublication_country() {
			return publication_country;
		}
		public void setPublication_country(String publication_country) {
			this.publication_country = publication_country;
		}
		public String getLanguage() {
			return language;
		}
		public void setLanguage(String language) {
			this.language = language;
		}
		public String getReference() {
			return reference;
		}
		public void setReference(String reference) {
			this.reference = reference;
		}
		public String getData_flag() {
			return data_flag;
		}
		public void setData_flag(String data_flag) {
			this.data_flag = data_flag;
		}
		public String getFormat() {
			return format;
		}
		public void setFormat(String format) {
			this.format = format;
		}
		public String getDeep_link() {
			return deep_link;
		}
		public void setDeep_link(String deep_link) {
			this.deep_link = deep_link;
		}
		public String getContents_flag() {
			return contents_flag;
		}
		public void setContents_flag(String contents_flag) {
			this.contents_flag = contents_flag;
		}
		public String getCharge() {
			return charge;
		}
		public void setCharge(String charge) {
			this.charge = charge;
		}
		public String getContents_url() {
			return contents_url;
		}
		public void setContents_url(String contents_url) {
			this.contents_url = contents_url;
		}
		
		@Override
		public String toString() {
			return "JakoRecord [identifier=" + identifier + ", datestamp=" + datestamp + ", setSpec=" + setSpec
					+ ", title_h=" + title_h + ", title_e=" + title_e + ", title_eq=" + title_eq + ", author=" + author
					+ ", affiliation=" + affiliation + ", publish_date=" + publish_date + ", publisher=" + publisher
					+ ", journal_title=" + journal_title + ", issn=" + issn + ", volume=" + volume + ", page=" + page
					+ ", subject=" + subject + ", abstract_h=" + abstract_h + ", abstract_e=" + abstract_e + ", toc=" + toc
					+ ", keyword=" + keyword + ", location_org=" + location_org + ", publication_country="
					+ publication_country + ", language=" + language + ", reference=" + reference + ", data_flag="
					+ data_flag + ", format=" + format + ", deep_link=" + deep_link + ", contents_flag=" + contents_flag
					+ ", charge=" + charge + ", contents_url=" + contents_url + "]";
		}

}
