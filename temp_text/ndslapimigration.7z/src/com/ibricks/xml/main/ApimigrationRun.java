package com.ibricks.xml.main;

import java.io.IOException;
import java.sql.SQLException;
import java.text.ParseException;

import javax.xml.parsers.ParserConfigurationException;

import org.xml.sax.SAXException;

public class ApimigrationRun {
	public static void main(String[] args) throws IOException, SQLException, ClassNotFoundException {
		System.out.println("main start");
		JakoRunner jakoRunner = new JakoRunner(); 
		try {
			
			jakoRunner.parseJako(args[0], args[1]);
			
		} catch (ParserConfigurationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SAXException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}
