package com.ibricks.xml.service;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import com.ibricks.xml.model.Jako;
import com.ibricks.xml.model.JakoRecord;

public class AddBatchService {
	

	public void insertJakoToMysql(Jako jako) {
//		logger.info(jako.toString());
		System.out.println("[insertJakoToMysql]");
		List<JakoRecord> jarkoList = jako.getJakoList();
//		for(JakoRecord record : jarkoList) {
//			logger.info(record.getDeep_link());
//		}
		System.out.println("[jarkoList]  : " + jarkoList.size());
		
		// JDBC RUN
		Connection conn = null;
		
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			conn = getConnection();
			String sql = "";
			sql = "INSERT INTO thesis_jako" + 
			"( c_id, datestamp, setspec, title_h, title_e, title_eq, author, affiliation, publish_date, publisher, "
			+ "journal_title, issn, volume, page, subject, abstract_h, abstract_e, toc, keyword, location_org, "
			+ "publication_country, language, reference, format, contents_flag, charge, contents_url, data_flag, deep_link ) "
			+"VALUES"
			+	"(?,?,?,?,?,?,?,?,?,?,"
			+ "?,?,?,?,?,?,?,?,?,?,"
			+ "?,?,?,?,?,?,?,?,?) "
			+ "ON DUPLICATE KEY UPDATE "
			+ "c_id=?, "
			+ "datestamp=?, "
			+ "setspec=?, "
			+ "title_h=?, "
			+ "title_e=?, "
			+ "title_eq=?, "
			+ "author=?, "
			+ "affiliation=?, "
			+ "publish_date=?, "
			+ "publisher=?, "
			+ "journal_title=?, "
			+ "issn=?, "
			+ "volume=?, "
			+ "page=?, "
			+ "subject=?, "
			+ "abstract_h=?, "
			+ "abstract_e=?, "
			+ "toc=?, "
			+ "keyword=?, "
			+ "location_org=?, "
			+ "publication_country=?, "
			+ "language=?, "
			+ "reference=?, "
			+ "format=?, "
			+ "contents_flag=?, "
			+ "charge=?, "
			+ "contents_url=?, "
			+ "data_flag=?, "
			+ "deep_link=? "
			;
//					;
			pstmt = conn.prepareStatement(sql);		
			for(JakoRecord record : jarkoList) {
				pstmt.setString(1, record.getIdentifier());	
				pstmt.setString(2, record.getDatestamp());	
				pstmt.setString(3, record.getSetSpec());	
				pstmt.setString(4, record.getTitle_h());	
				pstmt.setString(5, record.getTitle_e());	
				pstmt.setString(6, record.getTitle_eq());	
				pstmt.setString(7, record.getAuthor());	
				pstmt.setString(8, record.getAffiliation());	
				pstmt.setString(9, record.getPublish_date());	
				pstmt.setString(10, record.getPublisher());
				pstmt.setString(11, record.getJournal_title());
				pstmt.setString(12, record.getIssn());
				pstmt.setString(13, record.getVolume());
				pstmt.setString(14, record.getPage());
				pstmt.setString(15, record.getSubject());
				pstmt.setString(16, record.getAbstract_h());
				pstmt.setString(17, record.getAbstract_e());
				pstmt.setString(18, record.getToc());
				pstmt.setString(19, record.getKeyword());
				pstmt.setString(20, record.getLocation_org());
				pstmt.setString(21, record.getPublication_country());
				pstmt.setString(22, record.getLanguage());
				pstmt.setString(23, record.getReference());
				pstmt.setString(24, record.getFormat());
				pstmt.setString(25, record.getContents_flag());
				pstmt.setString(26, record.getCharge());
				pstmt.setString(27, record.getContents_url());
				pstmt.setString(28, record.getData_flag());
				pstmt.setString(29, record.getDeep_link());
				
				pstmt.setString(30, record.getIdentifier());	
				pstmt.setString(31, record.getDatestamp());	
				pstmt.setString(32, record.getSetSpec());	
				pstmt.setString(33, record.getTitle_h());	
				pstmt.setString(34, record.getTitle_e());	
				pstmt.setString(35, record.getTitle_eq());	
				pstmt.setString(36, record.getAuthor());	
				pstmt.setString(37, record.getAffiliation());	
				pstmt.setString(38, record.getPublish_date());	
				pstmt.setString(39, record.getPublisher());
				pstmt.setString(40, record.getJournal_title());
				pstmt.setString(41, record.getIssn());
				pstmt.setString(42, record.getVolume());
				pstmt.setString(43, record.getPage());
				pstmt.setString(44, record.getSubject());
				pstmt.setString(45, record.getAbstract_h());
				pstmt.setString(46, record.getAbstract_e());
				pstmt.setString(47, record.getToc());
				pstmt.setString(48, record.getKeyword());
				pstmt.setString(49, record.getLocation_org());
				pstmt.setString(50, record.getPublication_country());
				pstmt.setString(51, record.getLanguage());
				pstmt.setString(52, record.getReference());
				pstmt.setString(53, record.getFormat());
				pstmt.setString(54, record.getContents_flag());
				pstmt.setString(55, record.getCharge());
				pstmt.setString(56, record.getContents_url());
				pstmt.setString(57, record.getData_flag());
				pstmt.setString(58, record.getDeep_link());
				
//				logger.info(record.getDeep_link());
				pstmt.addBatch();
				pstmt.clearParameters();
			}
			int[] testVal = pstmt.executeBatch();
			System.out.println("testVal : " + testVal);
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			if(rs!=null) {
				try {
					rs.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			if(pstmt!=null) {
				closeConnection(conn, pstmt);
			}
		}
	}
	
	public Connection getConnection() throws SQLException {
		Connection conn;

		final String URL = "jdbc:mariadb://localhost:23306/rome";	//local mysql
		final String ID = "keitrome"; // 
		final String PW = "rome123"; // - local cola

		conn = DriverManager.getConnection(URL, ID, PW);
		conn.setAutoCommit(true);
		return conn;
	}
	
	
	public void closeConnection(Connection conn, PreparedStatement pstmt){
		try{
//			rs.close();
			pstmt.close();
			conn.close();
		}catch(Exception e){
			e.printStackTrace();
		}
	}
}