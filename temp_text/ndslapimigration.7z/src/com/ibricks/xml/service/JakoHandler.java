package com.ibricks.xml.service;

import java.util.ArrayList;
import java.util.List;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

import com.ibricks.xml.model.Jako;
import com.ibricks.xml.model.JakoRecord;

public class JakoHandler extends DefaultHandler {
	
	String delimiter = "|";
//	String deepLinkTmp="";
	String addValue="";
	
	private static final String LISTRECORDS = "ListRecords";
    private static final String RECORD = "record";
//    private static final String RESUMPTIONTOKEN = "resumptionToken";
    
    private static final String IDENTIFIER = "identifier";
    private static final String DATESTAMP = "datestamp";
    private static final String SETSPEC = "setSpec";
    
    private static final String TITLE_H = "title_h";
    private static final String TITLE_E = "title_e";
    private static final String TITLE_EQ = "title_eq";

    private static final String AUTHOR = "author";
    private static final String AFFILIATION = "affiliation";
    private static final String PUBLISH_DATE = "publish_date";
    private static final String PUBLISHER = "publisher";
    private static final String JOURNAL_TITLE = "journal_title";
    private static final String ISSN = "issn";
    private static final String VOLUME = "volume";
    private static final String PAGE = "page";
    private static final String SUBJECT = "subject";
    private static final String ABSTRACT_H = "abstract";
    private static final String ABSTRACT_E = "abstract_e";
    private static final String TOC = "toc";
    private static final String KEYWORD = "keyword";
    
    private static final String LOCATION_ORG = "location_org";
    private static final String PUBLICATION_COUNTRY = "publication_country";
    private static final String LANGUAGE = "language";
    private static final String REFERENCE = "reference";
    private static final String DATA_FLAG = "data_flag";
    private static final String FORMAT = "format";
    private static final String DEEP_LINK = "deep_link";
    private static final String CONTENTS_FLAG = "contents_flag";
    private static final String CHARGE = "charge";
    private static final String CONTENTS_URL = "contents_url";
    
    

    private Jako website;
    private String elementValue;

    public void characters(char[] ch, int start, int length) throws SAXException {
        elementValue = new String(ch, start, length);
//        deepLinkTmp+=elementValue;
        addValue+=elementValue;
//        logger.info("[elementValue] "+elementValue);
    }

    public void startDocument() throws SAXException {
        website = new Jako();
    }
    

    public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {
        switch (qName) {
            case LISTRECORDS:
                website.setJakoList(new ArrayList<>());
                break;
//            case RESUMPTIONTOKEN:
//                logger.info("qName ==========================> " + qName);
            case RECORD:
                website.getJakoList().add(new JakoRecord());
        }
    }
    public void endElement(String uri, String localName, String qName) throws SAXException {
    	String tempValue="";
//    	logger.info("[endElement] qName : "+qName);
        switch (qName) {
        	//header
            case IDENTIFIER:
            	latestJako().setIdentifier(elementValue);
                break;
            case DATESTAMP:
            	latestJako().setDatestamp(elementValue);
            	break;
            case SETSPEC:
            	latestJako().setSetSpec(elementValue);
            	break;
            	
            //metadata
            case TITLE_H:
            	latestJako().setTitle_h(elementValue);
            	break;
            case TITLE_E:
            	latestJako().setTitle_e(elementValue);
            	break;
            case TITLE_EQ:
            	latestJako().setTitle_eq(elementValue);
            	break;
            case AUTHOR:
            	tempValue=latestJako().getAuthor();
            	if(null!=tempValue && !"".equals(tempValue)) tempValue+=delimiter;
            	else tempValue="";
            	latestJako().setAuthor(tempValue + elementValue);
            	tempValue="";
            	break;
            case AFFILIATION:
            	tempValue=latestJako().getAffiliation();
            	if(null!=tempValue && !"".equals(tempValue)) tempValue+=delimiter;
            	else tempValue="";
            	latestJako().setAffiliation(tempValue + elementValue);
            	tempValue="";
            	break;
            case PUBLISH_DATE:
            	latestJako().setPublish_date(elementValue);
            	break;
            case PUBLISHER:
            	latestJako().setPublisher(addValue.trim());
            	break;
            case JOURNAL_TITLE:
            	latestJako().setJournal_title(elementValue);
            	break;
            case ISSN:
            	latestJako().setIssn(elementValue);
            	break;
            case VOLUME:
            	latestJako().setVolume(elementValue);
            	break;
            case PAGE:
            	latestJako().setPage(elementValue);
            	break;
            case SUBJECT:
            	latestJako().setSubject(elementValue);
            	break;
            case ABSTRACT_H:
            	latestJako().setAbstract_h(elementValue);
            	break;
            case ABSTRACT_E:
            	latestJako().setAbstract_e(removeHtmlStr(addValue.trim()));
            	break;
            case TOC:
            	latestJako().setToc(elementValue);
            	break;
            case KEYWORD:
            	tempValue=latestJako().getKeyword();
            	if(null!=tempValue && !"".equals(tempValue)) tempValue+=delimiter;
            	else tempValue="";
            	latestJako().setKeyword(tempValue + elementValue);
            	tempValue="";
            	break;
            	
            case LOCATION_ORG:
            	latestJako().setLocation_org(elementValue);
            	break;
            case PUBLICATION_COUNTRY:
            	latestJako().setPublication_country(elementValue);
            	break;
            case LANGUAGE:
            	latestJako().setLanguage(elementValue);
            	break;
            case REFERENCE:
            	latestJako().setReference(elementValue);
            	break;
            case DATA_FLAG:
            	latestJako().setData_flag(elementValue);
            	break;
            case FORMAT:
            	latestJako().setFormat(elementValue);
            	break;
            case CONTENTS_FLAG:
            	latestJako().setContents_flag(elementValue);
            	break;
            case CHARGE:
            	latestJako().setCharge(elementValue);
            	break;
            case CONTENTS_URL:
            	latestJako().setContents_url(elementValue);
            	break;
            	
            case DEEP_LINK:
//            	logger.info(addValue.trim());
//            	latestJako().setDeep_link(deepLinkTmp);
            	latestJako().setDeep_link(addValue.trim());
                break;
        }
        addValue="";
    }

    private JakoRecord latestJako() {
        List<JakoRecord> jakoList = website.getJakoList();
        int latestArticleIndex = jakoList.size() - 1;
        return jakoList.get(latestArticleIndex);
    }
    
    private String removeHtmlStr(String str) {
    	String output = str.replaceAll("<[^>]*>", " ");
    	return output;
    }

    public Jako getWebsite() {
        return website;
    }
}
