package com.ibricks.xml.model;

import java.util.List;

public class Jako {
	private List<JakoRecord> jakoList;

	public List<JakoRecord> getJakoList() {
		return jakoList;
	}
	public void setJakoList(List<JakoRecord> jakoList) {
		this.jakoList = jakoList;
	}
	public String toString() {
		return "RecordSet [jakoList=" + jakoList + "]";
	}

}
