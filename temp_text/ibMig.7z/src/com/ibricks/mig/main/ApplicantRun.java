package com.ibricks.mig.main;

import com.ibricks.mig.service.MysqlToMysql;
import com.ibricks.mig.service.OraToMysql;

public class ApplicantRun {
	public static void main(String[] args) {
		// case 1 : oracle PATENT_SPECIFICATION => mysql PATENT_SPECIFICATION
		/*
		OraToMysql oraToMysql = new OraToMysql();
		oraToMysql.runMigration();
		*/
		
		// case 2 : mysql ntis_sbjt_2016 => mysql NTIS_SBJT 
		MysqlToMysql mysqlToMysql = new MysqlToMysql();
		mysqlToMysql.runMigration();
	}
}
