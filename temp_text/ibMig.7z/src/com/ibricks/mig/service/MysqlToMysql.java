package com.ibricks.mig.service;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MysqlToMysql {
	
	public void runMigration() {
		System.out.println("runMigration start !");
		
//		PreparedStatement pstmtOra = null;      
        ResultSet rs = null;
//        Connection connOra = null;
        
        PreparedStatement pstmtMy = null;
        PreparedStatement pstmtInMy = null;
        Connection connMy = null;
        
        try {
        	// 1. Oracle conn
        	connMy = getMyConnection();
			String selQuery=
					"SELECT" + 
	        		"	C_ID" + 
	        		"	,SBMT_YEAR" + 
	        		"	,SBJT_NO" + 
	        		"	,CNTN_SBJT_YN" + 
	        		"	,PRV_SBJT_NO" + 
	        		"	,BSNSR_NM" + 
	        		"	,BSNSR_ORGN_NM" + 
	        		"	,SBJT_NM	" + 
	        		"	,STUDY_DEV_STEP" + 
	        		"	,REGION" + 
	        		"	,TOT_STUDY_TRM_START" + 
	        		"	,TOT_STUDY_TRM_END" + 
	        		"	,GVMNT_RSCH_FNDS" + 
	        		"	,MATCH_FUND_LOCAL_CASH" + 
	        		"	,MATCH_FUND_LOCAL_GOODS" + 
	        		"	,MATCH_FUND_UNIV_CASH" + 
	        		"	,MATCH_FUND_UNIV_GOODS" + 
	        		"	,MATCH_FUND_ENPR_L_CASH" + 
	        		"	,MATCH_FUND_ENPR_L_GOODS" + 
	        		"	,MATCH_FUND_ENPR_M_CASH" + 
	        		"	,MATCH_FUND_ENPR_M_GOODS" + 
	        		"	,MATCH_FUND_ENPR_S_CASH" + 
	        		"	,MATCH_FUND_ENPR_S_GOODS" + 
	        		"	,MATCH_FUND_ENPR_CASH" + 
	        		"	,MATCH_FUND_ENPR_GOODS" + 
	        		"	,MATCH_FUND_ETC_CASH" + 
	        		"	,MATCH_FUND_ETC_GOODS" + 
	        		"	,SMMR_RSCH_GOLE" + 
	        		"	,SMMR_RSCH_CN" + 
	        		"	,SMMR_EXPE_EFCT" + 
	        		"	,SMMR_HAN_KWD" + 
	        		"	,SMMR_ENG_KWD" + 
	        		" FROM ntis_sbjt_2016"
				  ;
			System.out.println(selQuery);
			pstmtMy = connMy.prepareStatement(selQuery);
	        rs = pstmtMy.executeQuery();
	        System.out.println("selQuery Execute");
	        
	        // 2. Mysql conn
	        String inQuery = "";
	        inQuery = "INSERT INTO NTIS_SBJT " + 
	    			"( C_ID, SBMT_YEAR, SBJT_NO, CNTN_SBJT_YN, PRV_SBJT_NO, BSNSR_NM, BSNSR_ORGN_NM, SBJT_NM, STUDY_DEV_STEP, REGION, TOT_STUDY_TRM_START, TOT_STUDY_TRM_END, GVMNT_RSCH_FNDS, MATCH_FUND_LOCAL_CASH, MATCH_FUND_LOCAL_GOODS, MATCH_FUND_UNIV_CASH, MATCH_FUND_UNIV_GOODS, MATCH_FUND_ENPR_L_CASH, MATCH_FUND_ENPR_L_GOODS, MATCH_FUND_ENPR_M_CASH, MATCH_FUND_ENPR_M_GOODS, MATCH_FUND_ENPR_S_CASH, MATCH_FUND_ENPR_S_GOODS, MATCH_FUND_ENPR_CASH, MATCH_FUND_ENPR_GOODS, MATCH_FUND_ETC_CASH, MATCH_FUND_ETC_GOODS, SMMR_RSCH_GOLE, SMMR_RSCH_CN, SMMR_EXPE_EFCT, SMMR_HAN_KWD, SMMR_ENG_KWD ) "
	    			+"VALUES "
	    			+	"(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?) "
	    			+ "ON DUPLICATE KEY UPDATE "
	    			+ "C_ID=?, "
	    			+ "SBMT_YEAR=?, "
	    			+ "SBJT_NO=?, "
	    			+ "CNTN_SBJT_YN=?, "
	    			+ "PRV_SBJT_NO=?, "
	    			+ "BSNSR_NM=?, "
	    			+ "BSNSR_ORGN_NM=?, "
	    			+ "SBJT_NM	=?, "
	    			+ "STUDY_DEV_STEP=?, "
	    			+ "REGION=?, "
	    			+ "TOT_STUDY_TRM_START=?, "
	    			+ "TOT_STUDY_TRM_END=?, "
	    			+ "GVMNT_RSCH_FNDS=?, "
	    			+ "MATCH_FUND_LOCAL_CASH=?, "
	    			+ "MATCH_FUND_LOCAL_GOODS=?, "
	    			+ "MATCH_FUND_UNIV_CASH=?, "
	    			+ "MATCH_FUND_UNIV_GOODS=?, "
	    			+ "MATCH_FUND_ENPR_L_CASH=?, "
	    			+ "MATCH_FUND_ENPR_L_GOODS=?, "
	    			+ "MATCH_FUND_ENPR_M_CASH=?, "
	    			+ "MATCH_FUND_ENPR_M_GOODS=?, "
	    			+ "MATCH_FUND_ENPR_S_CASH=?, "
	    			+ "MATCH_FUND_ENPR_S_GOODS=?, "
	    			+ "MATCH_FUND_ENPR_CASH=?, "
	    			+ "MATCH_FUND_ENPR_GOODS=?, "
	    			+ "MATCH_FUND_ETC_CASH=?, "
	    			+ "MATCH_FUND_ETC_GOODS=?, "
	    			+ "SMMR_RSCH_GOLE=?, "
	    			+ "SMMR_RSCH_CN=?, "
	    			+ "SMMR_EXPE_EFCT=?, "
	    			+ "SMMR_HAN_KWD=?, "
	    			+ "SMMR_ENG_KWD=?"
	    			;
	        
	        pstmtInMy = connMy.prepareStatement(inQuery);
	        int checkIdx=0;
	        int[] testVal = null;
	        int exeCount=0;
	        System.out.println("while start ...");
	        
	        while(rs.next()) {
	        	checkIdx++;
	        	String c_id = rs.getString("c_id");
	        	String sbmt_year = rs.getString("sbmt_year");
	        	String sbjt_no = rs.getString("sbjt_no");
	        	String cntn_sbjt_yn = rs.getString("cntn_sbjt_yn");
	        	String prv_sbjt_no = rs.getString("prv_sbjt_no");
	        	String bsnsr_nm = rs.getString("bsnsr_nm");
	        	String bsnsr_orgn_nm = rs.getString("bsnsr_orgn_nm");
	        	String sbjt_nm	 = rs.getString("sbjt_nm");
	        	String study_dev_step = rs.getString("study_dev_step");
	        	String region = rs.getString("region");
	        	String tot_study_trm_start = rs.getString("tot_study_trm_start");
	        	String tot_study_trm_end = rs.getString("tot_study_trm_end");
	        	String gvmnt_rsch_fnds = rs.getString("gvmnt_rsch_fnds");
	        	String match_fund_local_cash = rs.getString("match_fund_local_cash");
	        	String match_fund_local_goods = rs.getString("match_fund_local_goods");
	        	String match_fund_univ_cash = rs.getString("match_fund_univ_cash");
	        	String match_fund_univ_goods = rs.getString("match_fund_univ_goods");
	        	String match_fund_enpr_l_cash = rs.getString("match_fund_enpr_l_cash");
	        	String match_fund_enpr_l_goods = rs.getString("match_fund_enpr_l_goods");
	        	String match_fund_enpr_m_cash = rs.getString("match_fund_enpr_m_cash");
	        	String match_fund_enpr_m_goods = rs.getString("match_fund_enpr_m_goods");
	        	String match_fund_enpr_s_cash = rs.getString("match_fund_enpr_s_cash");
	        	String match_fund_enpr_s_goods = rs.getString("match_fund_enpr_s_goods");
	        	String match_fund_enpr_cash = rs.getString("match_fund_enpr_cash");
	        	String match_fund_enpr_goods = rs.getString("match_fund_enpr_goods");
	        	String match_fund_etc_cash = rs.getString("match_fund_etc_cash");
	        	String match_fund_etc_goods = rs.getString("match_fund_etc_goods");
	        	String smmr_rsch_gole = rs.getString("smmr_rsch_gole");
	        	String smmr_rsch_cn = rs.getString("smmr_rsch_cn");
	        	String smmr_expe_efct = rs.getString("smmr_expe_efct");
	        	String smmr_han_kwd = rs.getString("smmr_han_kwd");
	        	String smmr_eng_kwd = rs.getString("smmr_eng_kwd");
	        	
	        	pstmtInMy.setString(1, c_id);	
	        	pstmtInMy.setString(2, sbmt_year);	
	        	pstmtInMy.setString(3, sbjt_no);	
	        	pstmtInMy.setString(4, cntn_sbjt_yn);	
	        	pstmtInMy.setString(5, prv_sbjt_no);	
	        	pstmtInMy.setString(6, bsnsr_nm);	
	        	pstmtInMy.setString(7, bsnsr_orgn_nm);	
	        	pstmtInMy.setString(8, sbjt_nm);	
	        	pstmtInMy.setString(9, study_dev_step);	
	        	pstmtInMy.setString(10, region);	
	        	pstmtInMy.setString(11, tot_study_trm_start);	
	        	pstmtInMy.setString(12, tot_study_trm_end);	
	        	pstmtInMy.setString(13, gvmnt_rsch_fnds);	
	        	pstmtInMy.setString(14, match_fund_local_cash);	
	        	pstmtInMy.setString(15, match_fund_local_goods);	
	        	pstmtInMy.setString(16, match_fund_univ_cash);	
	        	pstmtInMy.setString(17, match_fund_univ_goods);	
	        	pstmtInMy.setString(18, match_fund_enpr_l_cash);	
	        	pstmtInMy.setString(19, match_fund_enpr_l_goods);	
	        	pstmtInMy.setString(20, match_fund_enpr_m_cash);	
	        	pstmtInMy.setString(21, match_fund_enpr_m_goods);	
	        	pstmtInMy.setString(22, match_fund_enpr_s_cash);	
	        	pstmtInMy.setString(23, match_fund_enpr_s_goods);	
	        	pstmtInMy.setString(24, match_fund_enpr_cash);	
	        	pstmtInMy.setString(25, match_fund_enpr_goods);	
	        	pstmtInMy.setString(26, match_fund_etc_cash);	
	        	pstmtInMy.setString(27, match_fund_etc_goods);	
	        	pstmtInMy.setString(28, smmr_rsch_gole);	
	        	pstmtInMy.setString(29, smmr_rsch_cn);	
	        	pstmtInMy.setString(30, smmr_expe_efct);	
	        	pstmtInMy.setString(31, smmr_han_kwd);	
	        	pstmtInMy.setString(32, smmr_eng_kwd);	
	        	pstmtInMy.setString(33, c_id);	
	        	pstmtInMy.setString(34, sbmt_year);	
	        	pstmtInMy.setString(35, sbjt_no);	
	        	pstmtInMy.setString(36, cntn_sbjt_yn);	
	        	pstmtInMy.setString(37, prv_sbjt_no);	
	        	pstmtInMy.setString(38, bsnsr_nm);	
	        	pstmtInMy.setString(39, bsnsr_orgn_nm);	
	        	pstmtInMy.setString(40, sbjt_nm);	
	        	pstmtInMy.setString(41, study_dev_step);	
	        	pstmtInMy.setString(42, region);	
	        	pstmtInMy.setString(43, tot_study_trm_start);	
	        	pstmtInMy.setString(44, tot_study_trm_end);	
	        	pstmtInMy.setString(45, gvmnt_rsch_fnds);	
	        	pstmtInMy.setString(46, match_fund_local_cash);	
	        	pstmtInMy.setString(47, match_fund_local_goods);	
	        	pstmtInMy.setString(48, match_fund_univ_cash);	
	        	pstmtInMy.setString(49, match_fund_univ_goods);	
	        	pstmtInMy.setString(50, match_fund_enpr_l_cash);	
	        	pstmtInMy.setString(51, match_fund_enpr_l_goods);	
	        	pstmtInMy.setString(52, match_fund_enpr_m_cash);	
	        	pstmtInMy.setString(53, match_fund_enpr_m_goods);	
	        	pstmtInMy.setString(54, match_fund_enpr_s_cash);	
	        	pstmtInMy.setString(55, match_fund_enpr_s_goods);	
	        	pstmtInMy.setString(56, match_fund_enpr_cash);	
	        	pstmtInMy.setString(57, match_fund_enpr_goods);	
	        	pstmtInMy.setString(58, match_fund_etc_cash);	
	        	pstmtInMy.setString(59, match_fund_etc_goods);	
	        	pstmtInMy.setString(60, smmr_rsch_gole);	
	        	pstmtInMy.setString(61, smmr_rsch_cn);	
	        	pstmtInMy.setString(62, smmr_expe_efct);	
	        	pstmtInMy.setString(63, smmr_han_kwd);	
	        	pstmtInMy.setString(64, smmr_eng_kwd);		
	        	
	        	pstmtInMy.addBatch();
	        	pstmtInMy.clearParameters();
	        	
	        	if(checkIdx % 1000 == 0) {
	        		testVal = pstmtInMy.executeBatch();
	        		exeCount += testVal.length;
	        		System.out.println("exeCount : " + exeCount);
	        	}
	        }
	        testVal = pstmtInMy.executeBatch();
	        exeCount += testVal.length;
			System.out.println("exeCount : " + exeCount);
	        
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally{
	         if(rs != null) try{ rs.close();} catch(SQLException e){};
	         if(pstmtMy != null) try{ pstmtMy.close();} catch(SQLException e){};                   
	         if(pstmtInMy != null) try{ pstmtInMy.close();} catch(SQLException e){};                   
	         if(connMy != null) try{ connMy.close();} catch(SQLException e){};
	         
		}
	}
	
	public String removeTag(String str){		
		Matcher mat;
		// memory ������ ��뷮 ������ 
		if(str.getBytes().length > 50000000) {
			System.out.println("str leng : " + str.getBytes().length);
		} else {
			// script ó�� 
			try {
				Pattern script = Pattern.compile("<(no)?script[^>]*>.*?</(no)?script>",Pattern.DOTALL);  
				mat = script.matcher(str);  
				str = mat.replaceAll("");  
			}catch(Exception e) {
				System.out.println(e.getStackTrace());
			}

			// style ó��
			try {
				Pattern style = Pattern.compile("<style[^>]*>.*</style>",Pattern.DOTALL);  
				mat = style.matcher(str);  
				str = mat.replaceAll("");  
			}catch(Exception e) {
				System.out.println(e.getStackTrace());
			}

			// tag ó��
			try {
				Pattern tag = Pattern.compile("<(\"[^\"]*\"|\'[^\']*\'|[^\'\">])*>");  
				mat = tag.matcher(str);  
				str = mat.replaceAll("");  
			}catch(Exception e) {
				System.out.println(e.getStackTrace());
			}

			// ntag ó��
			try {
				Pattern ntag = Pattern.compile("<\\w+\\s+[^<]*\\s*>");  
				mat = ntag.matcher(str);  
				str = mat.replaceAll("");  
			}catch(Exception e) {
				System.out.println(e.getStackTrace());
			}

			// entity ref ó��
			try {
				Pattern Eentity = Pattern.compile("&[^;]+;");  
				mat = Eentity.matcher(str);  
				str = mat.replaceAll("");
			}catch(Exception e) {
				System.out.println(e.getStackTrace());
			}

			// whitespace ó�� 
			try {
				Pattern wspace = Pattern.compile("\\s\\s+");  
				mat = wspace.matcher(str); 
				str = mat.replaceAll(""); 	          
			}catch(Exception e) {
				System.out.println(e.getStackTrace());
			}
		}

		return str;		
	}
	

	public Connection getOraConnection() throws SQLException {
		Connection conn;

		final String URL = "jdbc:oracle:thin:@10.100.103.208:11521:analordb";	//ibricks idc 
		final String ID = "nx_kipris"; // 
		final String PW = "!1p81Sn@4"; // 
		conn = DriverManager.getConnection(URL, ID, PW);
		conn.setAutoCommit(true);
		return conn;
	}
	
	public Connection getMyConnection() throws SQLException {
		Connection conn;

		final String URL = "jdbc:mariadb://114.202.208.195:23306/rome";	//local mysql
		final String ID = "keitrome"; //
		final String PW = "rome123"; // 

		conn = DriverManager.getConnection(URL, ID, PW);
		conn.setAutoCommit(true);
		return conn;
	}
	
	public void closeMyConnection(Connection conn, PreparedStatement pstmt){
		try{
//			rs.close();
			pstmt.close();
			conn.close();
		}catch(Exception e){
			e.printStackTrace();
		}
	}
}
