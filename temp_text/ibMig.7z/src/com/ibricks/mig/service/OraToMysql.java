package com.ibricks.mig.service;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class OraToMysql {
	
	public void runMigration() {
		System.out.println("runMigration start !");
		
		PreparedStatement pstmtOra = null;      
        ResultSet rs = null;
        Connection connOra = null;
        
        PreparedStatement pstmtMy = null;
        Connection connMy = null;
        
        try {
        	// 1. Oracle conn
			connOra = getOraConnection();
			String oraQuery=
	        		"select "
				  + "appl_no"
				  + ",spec_content"
				  + ",cnlk_stt_se"
				  + ",cnlk_trs_dt"
				  + ",cnlk_rcv_dt"
				  + ",cnlk_err_cn"
				  + " from "
				  + "  patent_specification "
				  + "where appl_no > '1020187009930' "
//				  + "where "
//				  + "rownum < 3 "
				  + "order by appl_no asc"
				  ;
			pstmtOra = connOra.prepareStatement(oraQuery);
	        rs = pstmtOra.executeQuery();
	        System.out.println("Oracle Query Execute");
	        
	        // 2. Mysql conn
	        connMy = getMyConnection();
	        String myQuery = "";
	        myQuery = "INSERT INTO PATENT_SPECIFICATION " + 
	    			"( cid, appl_no, spec_content, cnlk_stt_se, cnlk_err_cn ) "
	    			+"VALUES"
	    			+	"(?, ?, ?, ?, ?)"
	    			+ "ON DUPLICATE KEY UPDATE "
	    			+ "cid=?, "
	    			+ "appl_no=?, "
	    			+ "spec_content=?, "
	    			+ "cnlk_stt_se=?, "
	    			+ "cnlk_err_cn=?"
	    			;
	        pstmtMy = connMy.prepareStatement(myQuery);
	        
	        int checkIdx=0;
	        int[] testVal = null;
	        int exeCount=0;
	        System.out.println("while start ...");
	        
	        while(rs.next()) {
	        	checkIdx++;
	        	String appl_no = rs.getString("appl_no");
	        	String spec_content = rs.getString("spec_content");
//	        	System.out.println("appl_no : " + appl_no);
	        	spec_content = removeTag(spec_content);
	        	String cnlk_stt_se = rs.getString("cnlk_stt_se");
	        	String cnlk_err_cn = rs.getString("cnlk_err_cn");
	        	
	        	pstmtMy.setString(1, appl_no);	
	        	pstmtMy.setString(2, appl_no);	
	        	pstmtMy.setString(3, spec_content);	
	        	pstmtMy.setString(4, cnlk_stt_se);	
	        	pstmtMy.setString(5, cnlk_err_cn);	
	        	pstmtMy.setString(6, appl_no);	
	        	pstmtMy.setString(7, appl_no);	
	        	pstmtMy.setString(8, spec_content);	
	        	pstmtMy.setString(9, cnlk_stt_se);	
	        	pstmtMy.setString(10, cnlk_err_cn);	
	        	
	        	pstmtMy.addBatch();
	        	pstmtMy.clearParameters();
	        	
	        	if(checkIdx % 100 == 0) {
	        		testVal = pstmtMy.executeBatch();
	        		exeCount += testVal.length;
	        		System.out.println("exeCount : " + exeCount);
	        	}
	        }
	        testVal = pstmtMy.executeBatch();
	        exeCount += testVal.length;
			System.out.println("exeCount : " + exeCount);
	        
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally{
	         if(pstmtOra != null) try{ pstmtOra.close();} catch(SQLException e){};                   
	         if(rs != null) try{ rs.close();} catch(SQLException e){};
	         if(connOra != null) try{ connOra.close();} catch(SQLException e){};
	         
	         if(pstmtMy != null) try{ pstmtMy.close();} catch(SQLException e){};                   
	         if(connMy != null) try{ connMy.close();} catch(SQLException e){};
	         
		}
	}
	
	public String removeTag(String str){		
		Matcher mat;
		// memory ������ ��뷮 ������ 
		if(str.getBytes().length > 50000000) {
			System.out.println("str leng : " + str.getBytes().length);
		} else {
			// script ó�� 
			try {
				Pattern script = Pattern.compile("<(no)?script[^>]*>.*?</(no)?script>",Pattern.DOTALL);  
				mat = script.matcher(str);  
				str = mat.replaceAll("");  
			}catch(Exception e) {
				System.out.println(e.getStackTrace());
			}

			// style ó��
			try {
				Pattern style = Pattern.compile("<style[^>]*>.*</style>",Pattern.DOTALL);  
				mat = style.matcher(str);  
				str = mat.replaceAll("");  
			}catch(Exception e) {
				System.out.println(e.getStackTrace());
			}

			// tag ó��
			try {
				Pattern tag = Pattern.compile("<(\"[^\"]*\"|\'[^\']*\'|[^\'\">])*>");  
				mat = tag.matcher(str);  
				str = mat.replaceAll("");  
			}catch(Exception e) {
				System.out.println(e.getStackTrace());
			}

			// ntag ó��
			try {
				Pattern ntag = Pattern.compile("<\\w+\\s+[^<]*\\s*>");  
				mat = ntag.matcher(str);  
				str = mat.replaceAll("");  
			}catch(Exception e) {
				System.out.println(e.getStackTrace());
			}

			// entity ref ó��
			try {
				Pattern Eentity = Pattern.compile("&[^;]+;");  
				mat = Eentity.matcher(str);  
				str = mat.replaceAll("");
			}catch(Exception e) {
				System.out.println(e.getStackTrace());
			}

			// whitespace ó�� 
			try {
				Pattern wspace = Pattern.compile("\\s\\s+");  
				mat = wspace.matcher(str); 
				str = mat.replaceAll(""); 	          
			}catch(Exception e) {
				System.out.println(e.getStackTrace());
			}
		}

		return str;		
	}
	

	public Connection getOraConnection() throws SQLException {
		Connection conn;

		final String URL = "jdbc:oracle:thin:@10.100.103.208:11521:analordb";	//ibricks idc 
		final String ID = "nx_kipris"; // 
		final String PW = "!1p81Sn@4"; // 
		conn = DriverManager.getConnection(URL, ID, PW);
		conn.setAutoCommit(true);
		return conn;
	}
	
	public Connection getMyConnection() throws SQLException {
		Connection conn;

		final String URL = "jdbc:mariadb://114.202.208.195:23306/rome";	//local mysql
		final String ID = "keitrome"; //
		final String PW = "rome123"; // 

		conn = DriverManager.getConnection(URL, ID, PW);
		conn.setAutoCommit(true);
		return conn;
	}
	
	public void closeMyConnection(Connection conn, PreparedStatement pstmt){
		try{
//			rs.close();
			pstmt.close();
			conn.close();
		}catch(Exception e){
			e.printStackTrace();
		}
	}
}
