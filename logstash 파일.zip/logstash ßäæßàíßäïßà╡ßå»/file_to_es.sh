#!/usr/bin/env bash
export SYNAP_HOME=/Users/yoon/Desktop/work/ibricks/v4.21.0.1_mac_mojave_64bit_gcc4.2.1
export ATTACH_HOME=/Users/yoon/Desktop/work/ibricks/ib-web-connector/output
export LOGSTASH_HOME=/Users/yoon/Desktop/work/elastic/logstash-6.5.4

SEED=("kiet-publish" "kiet-issue" "kiet-paper" "kiet-publish" "kiet-search" "kistep-report" "koita-publictech" "stepi-etc" "stepi-investigate" "stepi-policy" "stepi-publish-future" "stepi-publish-insight" "stepi-publish-science" "stepi-research-policy" "web-kdi-analysis" "web-kdi-data" "web-kdi-etc" "web-kdi-focus" "web-kdi-forum" "web-kdi-policy" "web-kdi-research" "web-kdi-total" "web-kistep-advisory" "web-kistep-assembly" "web-kistep-committee" "web-kistep-yearbook")

for (( i = 0 ; i < ${#SEED[@]} ; i++ )) ; do
  $LOGSTASH_HOME/bin/logstash -f $LOGSTASH_HOME/config/file.to.es/${SEED[$i]}.yml
done



