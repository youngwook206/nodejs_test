#!/usr/bin/env bash
export LOGSTASH_HOME=/Users/yoon/Desktop/work/elastic/logstash-6.5.4

SEED=("kiet-publish" "kiet-issue" "kiet-paper" "kiet-publish" "kiet-search" "kistep-report" "koita-publictech" "stepi-etc" "stepi-investigate" "stepi-policy" "stepi-publish-future" "stepi-publish-insight" "stepi-publish-science" "stepi-research-policy" "web-kdi-analysis" "web-kdi-data" "web-kdi-etc" "web-kdi-focus" "web-kdi-forum" "web-kdi-policy" "web-kdi-research" "web-kdi-total" "web-kistep-advisory" "web-kistep-assembly" "web-kistep-committee" "web-kistep-yearbook")

for (( i = 0 ; i < ${#SEED[@]} ; i++ )) ; do
  $LOGSTASH_HOME/bin/logstash -f $LOGSTASH_HOME/config/out.jdbc/${SEED[$i]}.yml
done



